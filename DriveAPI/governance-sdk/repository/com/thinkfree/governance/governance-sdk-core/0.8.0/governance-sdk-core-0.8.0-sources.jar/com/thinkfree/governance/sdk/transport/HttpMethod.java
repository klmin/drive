package com.thinkfree.governance.sdk.transport;

/** SDK가 사용하는 HTTP method다. */
public enum HttpMethod {
    GET,
    POST
}
