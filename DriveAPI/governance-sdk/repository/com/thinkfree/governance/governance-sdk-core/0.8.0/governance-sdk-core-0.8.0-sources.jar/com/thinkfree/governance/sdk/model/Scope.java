package com.thinkfree.governance.sdk.model;

/** 연동 서비스 내부의 tenant·workspace·project 범위다. 계약상 필수는 `id`뿐이고 `type`은 선택이다. */
public final class Scope {
    private final String type;
    private final String id;
    private final String name;
    private Scope(Builder builder) {
        type = builder.type;
        id = required(builder.id, "id");
        name = builder.name;
    }
    public static Builder newBuilder() { return new Builder(); }
    public String getType() { return type; }
    public String getId() { return id; }
    public String getName() { return name; }
    private static String required(String value, String name) {
        if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException(name + " must not be blank");
        return value;
    }
    public static final class Builder {
        private String type;
        private String id;
        private String name;
        public Builder setType(String value) { type = value; return this; }
        public Builder setId(String value) { id = value; return this; }
        public Builder setName(String value) { name = value; return this; }
        public Scope build() { return new Scope(this); }
    }
}
