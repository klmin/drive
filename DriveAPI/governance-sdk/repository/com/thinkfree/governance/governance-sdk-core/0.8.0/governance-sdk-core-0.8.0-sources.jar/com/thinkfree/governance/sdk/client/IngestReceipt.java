package com.thinkfree.governance.sdk.client;

/**
 * 비동기 인입 receipt 상태의 래퍼다. <b>완료 판단은 {@code status=STORED} 하나로 한다.</b>
 *
 * <p>⚠ <b>{@link #getSegmentId()}·{@link #getSeqNo()}·{@link #getRecordHash()} 는 언제나 {@code null} 이다.</b>
 * 체인 위치는 <b>계약에서 걷힌 필드</b>다 — 접수증 테이블에 그 컬럼이 없어 서버가 채울 값이 없다.
 * 예전 계약은 {@code STORED} 일 때 이 셋을 required 로 강제했는데, 서버가 주지 않는 값이라 그 명세로 만든
 * 클라이언트가 정상 응답을 거부했고 그래서 필드와 강제를 함께 걷었다.
 *
 * <p>체인 위치가 필요하면 <b>상세 조회</b>를 쓴다 —
 * {@link GovernanceClient#getEvent(String)} 의 {@link EventDetail#getChain()}.
 * 이 셋을 저장 완료 판정에 쓰면 영영 통과하지 못한다.
 *
 * <p>getter 셋은 <b>이미 쓰고 있는 연동 서비스를 깨지 않으려고 남겨 둔다</b>(@Deprecated).
 */
public final class IngestReceipt {
    private final String receiptId;
    private final String eventId;
    private final String status;
    private final String receivedAt;
    private final String acceptedAt;
    private final String storedAt;
    private final String segmentId;
    private final Long seqNo;
    private final String recordHash;
    private final String errorCode;
    public IngestReceipt(String receiptId, String eventId, String status, String receivedAt, String acceptedAt,
                         String storedAt, String segmentId, Long seqNo, String recordHash, String errorCode) {
        this.receiptId = receiptId; this.eventId = eventId; this.status = status; this.receivedAt = receivedAt;
        this.acceptedAt = acceptedAt; this.storedAt = storedAt; this.segmentId = segmentId; this.seqNo = seqNo;
        this.recordHash = recordHash; this.errorCode = errorCode;
    }
    public String getReceiptId() { return receiptId; }
    public String getEventId() { return eventId; }
    public String getStatus() { return status; }
    public String getReceivedAt() { return receivedAt; }
    public String getAcceptedAt() { return acceptedAt; }
    public String getStoredAt() { return storedAt; }
    /** @deprecated 계약에서 걷힌 값이라 <b>항상 {@code null}</b> 이다. 상세 조회의 {@code chain} 을 쓴다. */
    @Deprecated
    public String getSegmentId() { return segmentId; }
    /** @deprecated 계약에서 걷힌 값이라 <b>항상 {@code null}</b> 이다. 상세 조회의 {@code chain} 을 쓴다. */
    @Deprecated
    public Long getSeqNo() { return seqNo; }
    /** @deprecated 계약에서 걷힌 값이라 <b>항상 {@code null}</b> 이다. 상세 조회의 {@code chain} 을 쓴다. */
    @Deprecated
    public String getRecordHash() { return recordHash; }
    public String getErrorCode() { return errorCode; }
}
