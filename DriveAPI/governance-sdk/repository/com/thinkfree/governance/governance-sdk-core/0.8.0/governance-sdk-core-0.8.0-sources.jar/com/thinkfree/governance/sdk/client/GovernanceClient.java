package com.thinkfree.governance.sdk.client;

import com.thinkfree.governance.sdk.model.EventIn;
import com.thinkfree.governance.sdk.model.EventQuery;
import com.thinkfree.governance.sdk.model.EvidenceChangeQuery;
import com.thinkfree.governance.sdk.model.EvidenceGroupQuery;
import com.thinkfree.governance.sdk.model.EvidenceVersionQuery;
import com.thinkfree.governance.sdk.model.GetEventRequest;
import com.thinkfree.governance.sdk.model.GetIngestReceiptRequest;
import com.thinkfree.governance.sdk.model.IngestBatchRequest;

import java.io.Closeable;
import java.io.IOException;
import java.util.List;

/** 거버넌스 서버 API의 사용자 진입점이다. 인입(쓰기)과 조회(읽기)를 같은 client로 제공한다. */
public interface GovernanceClient extends Closeable {
    IngestResult ingestEvent(EventIn event) throws IOException, GovernanceApiException;
    BatchIngestResult ingestBatch(IngestBatchRequest request) throws IOException, GovernanceApiException;
    IngestReceipt getIngestReceipt(GetIngestReceiptRequest request) throws IOException, GovernanceApiException;

    /**
     * 증적 목록을 조회한다({@code GET /v1/events}).
     *
     * <p>쿼리 파라미터는 서명 대상이다 — client가 계약 규칙대로 서명 대상 문자열을 만들고 같은 문자열을 URL에
     * 사용하므로, 연동 서비스가 그 규칙을 다시 구현할 필요가 없다.
     *
     * @param query 조회 조건
     * @return 한 페이지 결과
     * @throws IOException 전송·직렬화 실패
     * @throws GovernanceApiException 서버가 400·401·503 등으로 거부한 경우
     */
    EventListPage listEvents(EventQuery query) throws IOException, GovernanceApiException;

    /**
     * 증적 목록을 CSV로 내려받는다({@code GET /v1/events:export}).
     *
     * <p>{@link #listEvents(EventQuery)} 와 <b>같은 쿼리 객체</b>를 받아 같은 행을 뽑고 모양만 CSV로 바꾼다 —
     * 화면이 걸어 둔 필터를 그대로 넘기면 그 결과가 파일이 된다.
     *
     * <p>⚠ <b>한 페이지만 온다</b>({@code limit} 최대 200). 조건에 맞는 전체가 필요하면 둘 중 하나를 쓴다.
     * <ul>
     *   <li>{@link EventCsvExport#getNextCursor()} 를 이 호출의 {@code cursor} 로 넘기며 한 장씩 이어 부른다.
     *       <b>그 값이 {@code null} 이면 마지막 장이다</b> — 목록 조회를 곁들여 부르지 않아도 된다.</li>
     *   <li>기간이 92일 이내라면 {@link #exportEventsInRange(EventQuery)} 로 한 번에 받는다.</li>
     * </ul>
     *
     * <p>이 경로는 행마다 원본 증적을 복호화하기 때문에 목록 조회보다 무겁고, 동시 실행 상한이 있다.
     * 상한에 걸리면 {@code 429 EXPORT_BUSY} 이며 몇 초 뒤에 다시 보낼지는
     * {@link GovernanceApiException#getRetryAfterSeconds()} 에 담긴다(읽기라 재시도가 안전하다).
     *
     * @param query 조회 조건({@link #listEvents(EventQuery)} 와 같다)
     * @return CSV 원문 바이트와 서버가 정한 파일 이름
     * @throws IOException 전송 실패
     * @throws GovernanceApiException 서버가 400·401·429·503 등으로 거부한 경우
     */
    EventCsvExport exportEvents(EventQuery query) throws IOException, GovernanceApiException;

    /**
     * 기간 안의 증적을 <b>전부</b> CSV로 내려받는다({@code GET /v1/events:export-range}).
     *
     * <p>{@link #exportEvents(EventQuery)} 와 열·모양·파일 이름 규칙이 같고 <b>행 범위와 기간 규칙만 다르다</b>.
     * 한 장씩 이어 부르지 않아도 되지만 그 대신 다음 제약이 붙는다.
     *
     * <ul>
     *   <li>{@code occurredFrom}·{@code occurredTo} 가 <b>둘 다 필수</b>이고, 간격이 <b>92일</b>을 넘으면
     *       {@code 400} 이다(달력 3개월은 89~92일이라 92일이면 어떤 3개월 구간도 담긴다).</li>
     *   <li>{@code limit}·{@code offset}·{@code cursor} 는 <b>보내지 않는다</b> — client 가 알아서 뺀다.
     *       {@link #exportEvents(EventQuery)} 와 같은 {@link EventQuery} 를 그대로 넘겨도 된다.</li>
     *   <li>⚠ <b>응답 전체가 한 시점의 스냅샷은 아니다.</b> 서버가 페이지마다 조회를 나눠 읽기 때문이다.
     *       {@code occurredTo} 로 상한이 고정돼 있어 남는 어긋남은 발생 시각이 구간 안인데 늦게 도착한
     *       증적뿐이고, 받는 쪽에서 {@code eventId} 로 중복을 거를 수 있다.</li>
     *   <li>⚠ <b>받다 끊기면 처음부터 다시 받는다.</b> 서버는 내보낸 파일을 저장하지 않는다. 앞단에
     *       <b>총 시간 상한</b>(AWS API Gateway 29초 · Cloudflare 100초)이 있으면 이 경로가 그 상한을 넘을 수
     *       있으므로, 그때는 기간을 나눠 여러 번 부르거나 {@link #exportEvents(EventQuery)} 를 커서로 이어 부른다.</li>
     * </ul>
     *
     * <p>동시 실행 상한은 {@link #exportEvents(EventQuery)} 와 <b>따로</b> 둔다 — 이 경로가 막혀도 한 페이지짜리
     * 내려받기는 그대로 받는다. 상한에 걸리면 {@code 429 EXPORT_BUSY} 이고 몇 초 뒤에 다시 보낼지는
     * {@link GovernanceApiException#getRetryAfterSeconds()} 에 담긴다.
     *
     * @param query 조회 조건. 기간 둘은 반드시 채운다(페이지 파라미터는 채워도 무시한다)
     * @return 기간 안의 전체 행을 담은 CSV 원문 바이트와 서버가 정한 파일 이름
     * @throws IOException 전송 실패
     * @throws GovernanceApiException 기간을 안 줬거나 92일을 넘은 경우(400), 인증 실패(401),
     *     동시 실행 상한(429) 등
     */
    EventCsvExport exportEventsInRange(EventQuery query) throws IOException, GovernanceApiException;

    /**
     * 증적 상세를 조회한다({@code GET /v1/events/{eventId}}).
     *
     * @param request 상세 조회 요청
     * @return 복호화한 원문 + 관측값 + 체인 위치
     * @throws IOException 전송·직렬화 실패
     * @throws GovernanceApiException 서버가 401·404·503 등으로 거부한 경우
     */
    EventDetail getEvent(GetEventRequest request) throws IOException, GovernanceApiException;

    /**
     * 대상별로 묶은 목록을 조회한다({@code GET /v1/evidence-groups}) — 화면 한 줄이 문서 하나다.
     *
     * <p>⚠ <b>필터는 어떤 대상을 보일지만 정하고, 줄에 보이는 집계값은 필터를 바꿔도 그대로다.</b>
     * 커서는 {@code groupBy=objectId} 에 {@code objectType} 을 함께 준 요청에서만 쓸 수 있고, 다음 페이지를 조회하는
     * 사이에 <b>그룹이 건너뛰거나 겹칠 수 있다</b> — 정렬 키가 "가장 최근 발생 시각"이라 새 이벤트가 들어오면
     * 그 그룹이 앞으로 이동한다.
     *
     * @param query 조회 조건({@code groupBy} 필수)
     * @return 그룹 한 페이지
     * @throws IOException 전송·직렬화 실패
     * @throws GovernanceApiException 서버가 400·401·503 등으로 거부한 경우
     */
    EvidenceGroupPage listEvidenceGroups(EvidenceGroupQuery query) throws IOException, GovernanceApiException;

    /**
     * 한 대상의 버전 타임라인을 조회한다({@code GET /v1/evidence-groups/{groupKey}/versions}).
     *
     * <p>필터와 무관하게 그 대상의 <b>모든</b> 버전이 오고, 버전을 안 보낸 이벤트들도 한 그룹으로 온다.
     * 페이지네이션을 하지 않는다.
     *
     * @param query 조회 조건({@code groupKey}·{@code groupBy} 필수)
     * @return 버전 목록(최근 이벤트 순)
     * @throws IOException 전송·직렬화 실패
     * @throws GovernanceApiException 서버가 400·401·503 등으로 거부한 경우
     */
    List<EvidenceVersion> listEvidenceVersions(EvidenceVersionQuery query)
        throws IOException, GovernanceApiException;

    /**
     * 같은 위치끼리 묶은 변경 내역을 조회한다({@code GET /v1/evidence-groups/{groupKey}/changes}).
     *
     * <p>원문은 <b>최초 {@code before} + 최종 {@code after}</b> 이고, 검토자와 생성자가 따로 온다.
     * ⚠ 여기서 <b>기간은 집계·구간·원문을 모두 그 기간 안으로 좁힌다</b> — 그룹 목록의 기간과 뜻이 다르다.
     *
     * @param query 조회 조건({@code groupKey}·{@code groupBy} 필수)
     * @return 변경 내역 한 페이지
     * @throws IOException 전송·직렬화 실패
     * @throws GovernanceApiException 서버가 400·401·503 등으로 거부한 경우
     */
    EvidenceChangePage listEvidenceChanges(EvidenceChangeQuery query) throws IOException, GovernanceApiException;

    /**
     * 자기 거버넌스 테넌트를 조회한다({@code GET /v1/tenants}) — 관리 플레인 계약
     * ({@code openapi/governance-admin.yaml})이다.
     *
     * <p><b>테넌트 식별자를 받지 않는다.</b> 인증에서 나온 테넌트가 유일한 답이라 쿼리 파라미터도 없다.
     * 화면이 "지금 어느 테넌트로 보고 있나" 를 표시하거나, 연동 팀이 자기 키가 어느 테넌트에 묶였는지
     * 확인하는 데 쓴다.
     *
     * <p>⚠ <b>목록을 돌려주지만 지금은 원소가 하나</b>(자기 테넌트)다. 관리자 인증이 서면 같은 경로가 여러
     * 개를 줄 수 있어 계약이 배열이며, 연동 서비스가 {@code get(0)} 을 전제로 짜지 않도록 그대로 노출한다.
     *
     * @return 인증한 주체가 볼 수 있는 테넌트(수정 불가)
     * @throws IOException 전송·직렬화 실패
     * @throws GovernanceApiException 서버가 400·401·503 등으로 거부한 경우
     */
    List<TenantInfo> listTenants() throws IOException, GovernanceApiException;

    default IngestReceipt getIngestReceipt(String receiptId) throws IOException, GovernanceApiException {
        return getIngestReceipt(GetIngestReceiptRequest.newBuilder().setReceiptId(receiptId).build());
    }

    default EventDetail getEvent(String eventId) throws IOException, GovernanceApiException {
        return getEvent(GetEventRequest.newBuilder().setEventId(eventId).build());
    }

    static GovernanceClient create(GovernanceClientSettings settings) {
        return new DefaultGovernanceClient(settings);
    }
}
