package com.thinkfree.governance.sdk.client;

import com.thinkfree.governance.sdk.model.ContractLimits;

/**
 * 보낼 본문의 바이트 길이만 한 번 재는 안전 장치다.
 *
 * <p>SDK는 필드 길이를 미리 검사하지 않는다(그 판단은 서버가 한다). 본문 전체 크기만 재는 이유는 성격이
 * 다르기 때문이다 — 아주 큰 본문은 업로드 대역폭을 실제로 낭비하고, 중간 프록시가 서버의 400 대신 알아보기
 * 어려운 오류를 출력한다. 직렬화는 이미 끝났으니 바이트 길이를 재는 건 공짜다.
 *
 * <p><b>여기 값은 서버 상한보다 일부러 느슨하다(약 네 배).</b> 서버와 같은 값으로 막으면 서버가 상한을
 * 넓혔을 때 낡은 SDK가 정상 요청을 거부하고, 그러면 요청이 서버에 도달하지 않아 서버 로그에도 안 남는다.
 * 느슨하게 잡으면 SDK가 낡아도 <b>너무 관대해질 뿐 정상 값을 거부하는 일은 생기지 않는다.</b> 관대한 쪽은
 * 안전하다 — 최종 판단은 서버가 하고 서버는 사유를 붙여 준다. 서버 값은
 * {@link ContractLimits#EVENT_MAX_BYTES}·{@link ContractLimits#REQUEST_MAX_BYTES} 에 있다.
 * <b>이 값을 서버 값과 같게 조이지 마라</b> — 그러면 위 이유가 그대로 되살아난다.
 */
public final class RequestSizeGuard {
    /**
     * 단건 인입 본문의 SDK 상한(1 MiB). 서버의 이벤트 하나 상한 256 KiB의 네 배다 —
     * 단건 본문은 EventIn 한 건이라 서버에서 먼저 걸리는 것이 이벤트 하나 상한이다.
     */
    public static final int SINGLE_EVENT_MAX_BYTES = 4 * ContractLimits.EVENT_MAX_BYTES;

    /**
     * 배치 인입 본문의 SDK 상한(32 MiB). 서버의 raw 요청 상한 8 MiB의 네 배다 —
     * 배치는 항목 수만큼 커지므로 요청 전체 상한을 기준으로 잡는다.
     */
    public static final int BATCH_MAX_BYTES = 4 * ContractLimits.REQUEST_MAX_BYTES;

    private RequestSizeGuard() {
    }

    /**
     * 본문 길이가 SDK 상한을 넘으면 보내지 않고 거부한다.
     *
     * @param rawBody 직렬화된 요청 본문
     * @param maxBytes 이 요청 타입의 SDK 상한
     * @param operation 오류 메시지에 쓸 요청 타입
     * @throws IllegalArgumentException 본문이 상한을 넘은 경우. 메시지에는 길이만 넣고 본문은 넣지 않는다
     */
    static void check(byte[] rawBody, int maxBytes, RequestOperation operation) {
        if (rawBody.length > maxBytes) {
            throw new IllegalArgumentException(operation + " body is " + rawBody.length
                + " bytes, which exceeds the SDK limit of " + maxBytes + " bytes");
        }
    }
}
