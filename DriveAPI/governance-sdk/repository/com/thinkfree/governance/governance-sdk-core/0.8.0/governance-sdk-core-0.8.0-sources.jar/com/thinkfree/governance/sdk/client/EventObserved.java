package com.thinkfree.governance.sdk.client;

import java.util.Map;

/**
 * 서버가 관측·확정한 값이다. 연동 서비스가 보낼 수 없고 서버만 채운다.
 *
 * <p>{@link #getAuthenticationMethod()} 는 <b>서명 방식</b>({@code HMAC_SHA256})이고
 * {@link #getIngestAuthMethod()} 는 이 이벤트가 들어온 <b>인증 경로</b>({@code AUTHENTICATED_TENANT_KEY})다 —
 * 이름이 비슷하지만 다른 값이다.
 */
public final class EventObserved {
    private final Map<String, Object> values;

    EventObserved(Map<String, Object> values) {
        this.values = ResponseValues.copyOf(values);
    }

    /** 서버가 keyId로 확정한 거버넌스 고객 식별자. */
    public String getGovernanceTenantId() { return text("governanceTenantId"); }
    /** 이 이벤트가 어떤 인증 키로 들어왔는지. */
    public String getIngestKeyId() { return text("ingestKeyId"); }
    /** 서명 방식(현재는 {@code HMAC_SHA256} 하나). */
    public String getAuthenticationMethod() { return text("authenticationMethod"); }
    /** 이 이벤트가 들어온 인증 경로(현재는 {@code AUTHENTICATED_TENANT_KEY} 하나). */
    public String getIngestAuthMethod() { return text("ingestAuthMethod"); }
    public String getReceivedAt() { return text("receivedAt"); }
    public String getAcceptedAt() { return text("acceptedAt"); }
    public String getStoredAt() { return text("storedAt"); }
    /** 서버가 관측한 요청 출발 주소. 연동 서비스가 신고한 {@code context.clientIp} 와 다른 값이다. */
    public String getObservedIp() { return text("observedIp"); }

    /**
     * 관측값 원문 전부를 돌려준다.
     *
     * @return 계약 필드 이름 → 값(수정 불가)
     */
    public Map<String, Object> asMap() { return values; }

    private String text(String name) { return ResponseValues.text(values, name); }
}
