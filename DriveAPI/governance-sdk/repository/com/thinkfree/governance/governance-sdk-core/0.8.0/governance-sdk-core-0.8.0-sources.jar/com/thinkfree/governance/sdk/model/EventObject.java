package com.thinkfree.governance.sdk.model;

/**
 * 이벤트의 대상(문서·폴더·사용자·설정)이다. EventIn의 `object` 필드로 직렬화된다.
 *
 * `type`은 계약이 네 값(`FILE`·`FOLDER`·`USER`·`SETTING`)으로 잠근 필수값이고, `storage`는 대상이
 * 실제로 저장된 곳(`TFD`·`LOCAL`·`USER_STORAGE`)이다 — 이벤트를 보낸 시스템(`origin.system`)과 다를 수 있다.
 */
public final class EventObject {
    private final String type;
    private final String id;
    private final String name;
    private final String email;
    private final String path;
    private final String version;
    private final String storage;
    private EventObject(Builder builder) {
        type = required(builder.type, "type");
        id = builder.id;
        name = builder.name;
        email = builder.email;
        path = builder.path;
        version = builder.version;
        storage = builder.storage;
    }
    public static Builder newBuilder() { return new Builder(); }
    public String getType() { return type; }
    public String getId() { return id; }
    public String getName() { return name; }
    /**
     * <b>대상이 사람일 때의 이메일</b>({@code type=USER}). 320자 이하.
     *
     * <p>화면이 {@link #getName()} 과 함께 {@code {이름}({이메일})} 로 그려 동명이인을 가른다 —
     * 수행자 쪽 {@code Actor.getEmail()} 의 짝이다. ⚠ <b>개인정보</b>이며 조회 응답에는
     * {@code objectEmail} 로 나간다(검색·필터는 지원하지 않는다).
     */
    public String getEmail() { return email; }
    public String getPath() { return path; }
    public String getVersion() { return version; }
    public String getStorage() { return storage; }
    private static String required(String value, String name) {
        if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException(name + " must not be blank");
        return value;
    }
    public static final class Builder {
        private String type;
        private String id;
        private String name;
        private String email;
        private String path;
        private String version;
        private String storage;
        public Builder setType(String value) { type = value; return this; }
        public Builder setId(String value) { id = value; return this; }
        public Builder setName(String value) { name = value; return this; }
        /** 대상이 사람일 때의 이메일을 지정한다(320자 이하, 개인정보). */
        public Builder setEmail(String value) { email = value; return this; }
        public Builder setPath(String value) { path = value; return this; }
        public Builder setVersion(String value) { version = value; return this; }
        public Builder setStorage(String value) { storage = value; return this; }
        public EventObject build() { return new EventObject(this); }
    }
}
