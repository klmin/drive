package com.thinkfree.governance.sdk.auth;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** HMAC signer가 만든 요청 헤더 그룹이다. */
public final class SignedHeaders {
    private final Map<String, String> values;

    public SignedHeaders(Map<String, String> values) {
        this.values = Collections.unmodifiableMap(new LinkedHashMap<String, String>(values));
    }

    public Map<String, String> asMap() {
        return values;
    }
}
