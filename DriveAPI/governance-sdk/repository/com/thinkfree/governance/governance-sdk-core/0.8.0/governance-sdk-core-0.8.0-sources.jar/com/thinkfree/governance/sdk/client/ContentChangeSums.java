package com.thinkfree.governance.sdk.client;

import java.util.Map;

/**
 * 한 그룹의 누적 변경 집계다. 저장 시점에 세어 둔 개수를 더한 값이다.
 *
 * <p>⚠ <b>{@code null} 은 0이 아니라 "세지 않았다"</b>이고, {@link #getUnknownEventCount()} 가 0이 아니면
 * <b>합은 부분합이다</b> — 개수는 이 기능이 생긴 뒤 저장된 이벤트에만 있다. 화면은 그때 "N건 이상"으로 보여야
 * 한다. 0으로 대신 읽으면 변경이 있었던 옛 이벤트가 "변경 없음"으로 결론난다.
 */
public final class ContentChangeSums {
    private final Map<String, Object> values;

    ContentChangeSums(Map<String, Object> values) {
        this.values = ResponseValues.copyOf(values);
    }

    /** 변경 항목 수 합계. 집계하지 않은 이벤트뿐이면 {@code null}. */
    public Long getTotal() { return ResponseValues.longValue(values, "total"); }
    /** AI이 만든 항목 수({@code producedBy.type=AI}). */
    public Long getAi() { return ResponseValues.longValue(values, "ai"); }
    /** 사람이 만든 항목 수. */
    public Long getHuman() { return ResponseValues.longValue(values, "human"); }
    /** 승인된 항목 수({@code itemStatus=APPROVED_CHANGE}). */
    public Long getApproved() { return ResponseValues.longValue(values, "approved"); }
    /** 거절된 항목 수({@code itemStatus=REJECTED_CHANGE}). */
    public Long getRejected() { return ResponseValues.longValue(values, "rejected"); }
    /**
     * 개수를 집계하지 않은 이벤트 수.
     *
     * <p>0이 아니면 위 합계는 <b>부분합</b>이다 — 그만큼의 이벤트는 집계된 값이 없어 더해지지 않았다.
     */
    public Long getUnknownEventCount() { return ResponseValues.longValue(values, "unknownEventCount"); }

    /** 집계 원문 값 전부(수정 불가). 계약이 늘어 getter가 아직 없는 값을 읽을 때 쓴다. */
    public Map<String, Object> asMap() { return values; }
}
