package com.thinkfree.governance.sdk.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 대상별로 묶은 목록 조회({@code GET /v1/evidence-groups})의 쿼리 파라미터를 조립한다.
 *
 * <p>화면 한 줄이 문서 하나이고, 그 줄에 이벤트 수·누적 변경·가장 최근 이벤트의 표시값이 함께 온다.
 *
 * <p><b>목록 조회({@link EventQuery})의 필터를 물려받지 않는다.</b> 계약이 정한 것은 <b>열 개</b>뿐이다 —
 * {@code groupBy}·{@code aiChanged}·기간 둘·{@code objectType}·{@code objectName}·{@code actorType}·
 * {@code limit}·{@code offset}·{@code cursor}. 목적이 다르기 때문이고, 계약에 없는 이름을 주면 서버가 400이다.
 *
 * <p>⚠ <b>필터는 어떤 대상을 목록에 보일지만 정한다. 줄에 보이는 집계값은 필터를 바꿔도 그대로다.</b>
 * 수행자 유형을 {@code HUMAN} 으로 걸렀다고 누적 변경이 사람이 만든 것만 세어지지는 않는다 — 그 대상의 누적
 * 변경은 대상의 성질이지 조회 조건의 성질이 아니다.
 *
 * <p><b>커서는 {@code groupBy=objectId} 에 {@code objectType} 을 함께 준 요청에서만 쓸 수 있다</b> —
 * 다른 축에 주면 서버가 400이다. 그 축만 정렬 키(문서의 마지막 이벤트 시각·문서 id)가 저장된 컬럼이라 이어 볼
 * 그룹을 정확히 지정할 수 있고, 나머지 축은 그 값을 요청마다 집계로 만든다. <b>이 축 조건은 SDK가 막지 않는다</b>
 * — 서버가 나중에 다른 축까지 넓혔을 때 낡은 SDK가 정상 호출을 거부하면 안 되기 때문이다(서버가 사유를 붙여
 * 400으로 알려준다). 함께 쓸 수 없는 {@code cursor}·양수 {@code offset} 조합만 build 시 막는다.
 *
 * <p>⚠ <b>커서로 이어 봐도 그룹이 건너뛰거나 겹칠 수 있다.</b> 정렬 키가 "그 문서의 마지막 이벤트 시각"이라
 * 보는 사이에 그 문서에 새 증적이 들어오면 그룹이 목록 앞으로 이동한다. 이벤트 목록({@link EventQuery})은 행이
 * 고정이라 그런 일이 없지만 그룹은 그렇지 않다 — <b>감사 결론을 내는 화면이라면 기간을 좁혀 고정된 조회 대상에서
 * 본다.</b>
 */
public final class EvidenceGroupQuery {
    private static final String GROUP_BY = "groupBy";
    private static final String AI_CHANGED = "aiChanged";
    private static final String OCCURRED_FROM = "occurredFrom";
    private static final String OCCURRED_TO = "occurredTo";
    private static final String OBJECT_TYPE = "objectType";
    private static final String OBJECT_NAME = "objectName";
    private static final String ACTOR_TYPE = "actorType";
    private static final String LIMIT = "limit";
    private static final String OFFSET = "offset";
    private static final String CURSOR = "cursor";

    private final Map<String, String> filters;
    private final List<String> actorTypes;
    private final Boolean aiChanged;
    private final Integer limit;
    private final Integer offset;
    private final String cursor;

    private EvidenceGroupQuery(Builder builder) {
        Map<String, String> values = new LinkedHashMap<String, String>();
        for (Map.Entry<String, String> filter : builder.filters.entrySet()) {
            values.put(filter.getKey(), QueryValues.requireNotBlank(filter.getValue(), filter.getKey()));
        }
        // groupBy 는 계약이 필수로 정했다 — 없으면 서버가 400 이므로 여기서 먼저 막는다.
        QueryValues.requireNotBlank(values.get(GROUP_BY), GROUP_BY);
        filters = Collections.unmodifiableMap(values);
        actorTypes = QueryValues.copyOf(builder.actorTypes, ACTOR_TYPE);
        aiChanged = builder.aiChanged;
        limit = QueryValues.checkLimit(builder.limit);
        offset = QueryValues.checkOffset(builder.offset);
        cursor = builder.cursor == null ? null : QueryValues.requireNotBlank(builder.cursor, CURSOR);
        // 커서와 1 이상의 offset 을 함께 주면 페이지 위치가 모호하다 — 서버도 400 이라 여기서 먼저 막는다.
        if (cursor != null && offset != null && offset.intValue() > 0) {
            throw new IllegalArgumentException("cursor must not be combined with a positive offset");
        }
    }

    public static Builder newBuilder() { return new Builder(); }

    public String getGroupBy() { return filters.get(GROUP_BY); }
    public String getOccurredFrom() { return filters.get(OCCURRED_FROM); }
    public String getOccurredTo() { return filters.get(OCCURRED_TO); }
    public String getObjectType() { return filters.get(OBJECT_TYPE); }
    public String getObjectName() { return filters.get(OBJECT_NAME); }
    /** 수행자 유형 조건 전부. 안 걸었으면 빈 목록이다. */
    public List<String> getActorTypes() { return actorTypes; }
    /** AI 변경이 있는 대상만({@code TRUE})·없는 대상만({@code FALSE}). 안 걸었으면 {@code null}. */
    public Boolean getAiChanged() { return aiChanged; }
    public Integer getLimit() { return limit; }
    public Integer getOffset() { return offset; }
    /** 이어 볼 커서. 안 걸었으면 {@code null}. */
    public String getCursor() { return cursor; }

    /**
     * 이 쿼리를 서명·URL에 쓸 파라미터 목록으로 내보낸다.
     *
     * @return 계약 이름 → 값 목록(수정 불가)
     */
    public Map<String, List<String>> toCanonicalParameters() {
        Map<String, List<String>> parameters = new LinkedHashMap<String, List<String>>();
        for (Map.Entry<String, String> filter : filters.entrySet()) {
            parameters.put(filter.getKey(), Collections.singletonList(filter.getValue()));
        }
        if (!actorTypes.isEmpty()) {
            parameters.put(ACTOR_TYPE, actorTypes);
        }
        if (aiChanged != null) {
            parameters.put(AI_CHANGED, Collections.singletonList(aiChanged.booleanValue() ? "true" : "false"));
        }
        if (limit != null) {
            parameters.put(LIMIT, Collections.singletonList(limit.toString()));
        }
        if (offset != null) {
            parameters.put(OFFSET, Collections.singletonList(offset.toString()));
        }
        if (cursor != null) {
            parameters.put(CURSOR, Collections.singletonList(cursor));
        }
        return Collections.unmodifiableMap(parameters);
    }

    /**
     * 같은 조건을 담은 builder를 만든다. 페이지 위치({@code offset}·{@code cursor})만 바꿔 다음 페이지를
     * 조립할 때 쓴다.
     *
     * @return 이 쿼리와 같은 값이 채워진 builder
     */
    public Builder toBuilder() {
        Builder builder = new Builder();
        builder.filters.putAll(filters);
        builder.actorTypes.addAll(actorTypes);
        builder.aiChanged = aiChanged;
        builder.limit = limit;
        builder.offset = offset;
        builder.cursor = cursor;
        return builder;
    }

    /** 그룹 목록 쿼리 builder다. setter에 {@code null} 을 주면 그 파라미터를 보내지 않는다. */
    public static final class Builder {
        private final Map<String, String> filters = new LinkedHashMap<String, String>();
        private final List<String> actorTypes = new ArrayList<String>();
        private Boolean aiChanged;
        private Integer limit;
        private Integer offset;
        private String cursor;

        private Builder put(String name, String value) {
            if (value == null) {
                filters.remove(name);
            } else {
                filters.put(name, value);
            }
            return this;
        }

        /**
         * 무엇으로 묶을지 고른다(필수) — {@link QueryVocabulary#GROUP_BY_OBJECT_ID} 등 네 값.
         * 문서 증적 화면은 {@code objectId}, 로그인 증적 화면은 {@code actorId} 다.
         */
        public Builder setGroupBy(String value) { return put(GROUP_BY, value); }
        /** 기간 하한(이 값 이상). 어떤 대상을 <b>보일지</b>만 정한다 — 줄의 집계값은 안 움직인다. */
        public Builder setOccurredFrom(String value) { return put(OCCURRED_FROM, value); }
        /** 기간 상한(이 값 미만). */
        public Builder setOccurredTo(String value) { return put(OCCURRED_TO, value); }
        /** 대상 유형({@link QueryVocabulary#OBJECT_TYPES}). 문서 증적 화면은 {@code FILE} 이다. */
        public Builder setObjectType(String value) { return put(OBJECT_TYPE, value); }
        /**
         * 문서명 <b>부분 일치</b>. 이벤트마다 그때의 이름이 저장되므로 <b>이름을 바꾼 문서는 옛 이름으로도 걸린다.</b>
         * ⚠ 검색 컬럼이 320자라 그보다 뒤에 있는 글자로는 오류 없이 찾을 수 없다.
         */
        public Builder setObjectName(String value) { return put(OBJECT_NAME, value); }
        /** 수행자 유형 하나를 더한다. 여러 번 부르면 그 유형들 중 하나인 이벤트가 있는 대상을 본다. */
        public Builder addActorType(String value) { actorTypes.add(value); return this; }
        /** 수행자 유형 목록을 통째로 바꾼다. {@code null} 이면 비운다. */
        public Builder setActorTypes(List<String> values) {
            actorTypes.clear();
            if (values != null) {
                actorTypes.addAll(values);
            }
            return this;
        }
        /**
         * AI 변경이 있는 대상만({@code TRUE})·없는 대상만({@code FALSE}) 본다.
         *
         * <p>⚠ {@code FALSE}(없음)에는 <b>개수를 집계하지 않은 이벤트가 하나도 없는 대상만</b> 나온다 — 모르는 것을
         * 없다고 답하지 않기 위해서다.
         */
        public Builder setAiChanged(Boolean value) { aiChanged = value; return this; }
        /** 한 페이지 최대 건수(1~200). 안 주면 서버 기본 50. */
        public Builder setLimit(Integer value) { limit = value; return this; }
        /** 건너뛸 건수(0 이상). {@code cursor} 와 1 이상을 함께 줄 수 없다. */
        public Builder setOffset(Integer value) { offset = value; return this; }
        /**
         * 이어 볼 커서. 직전 응답의 {@link com.thinkfree.governance.sdk.client.EvidenceGroupPage#getNextCursor()}
         * 를 그대로 준다 — <b>값은 불투명하다</b>(안을 해석하거나 만들어 내지 않는다).
         *
         * <p>⚠ {@code groupBy=objectId} 에 {@code objectType} 을 함께 준 요청에서만 쓸 수 있다.
         * 해석할 수 없는 값도 서버가 400이다 — 오류 없이 첫 페이지를 주면 연동 서비스는 다음 페이지를 본다고 믿는데 앞부분을
         * 다시 받기 때문이다.
         */
        public Builder setCursor(String value) { cursor = value; return this; }

        public EvidenceGroupQuery build() { return new EvidenceGroupQuery(this); }
    }
}
