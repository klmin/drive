package com.thinkfree.governance.sdk.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 조회 쿼리 객체들이 함께 쓰는 값 검사다.
 *
 * <p>여기서 막는 것은 <b>요청의 모양을 가르는 계약</b>뿐이다 — 빈 값, 페이지 범위, 경로 세그먼트. 고정 enum 값과
 * 필터 길이 상한은 <b>막지 않는다</b>: 서버가 허용 값을 늘렸을 때 낡은 SDK가 정상 값을 거부하면 안 되기 때문이다.
 */
final class QueryValues {
    /** 한 페이지 최대 건수의 계약 하한·상한. */
    static final int MIN_LIMIT = 1;
    static final int MAX_LIMIT = 200;

    private QueryValues() {
    }

    /**
     * 빈 값을 거부한다.
     *
     * <p>서버가 빈 값을 400으로 막는 이유와 같다 — 빈 값은 "조건 없음"이 아니다. 서명에는 그 파라미터가
     * 들어갔으므로 호출자는 자기가 건 조건이 무시된 결과를 "그 조건의 결과"로 읽는다.
     */
    static String requireNotBlank(String value, String name) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(name + " must not be blank");
        }
        return value;
    }

    /** 반복 파라미터 값들을 검사해 수정 불가 목록으로 만든다. */
    static List<String> copyOf(List<String> values, String name) {
        List<String> copied = new ArrayList<String>();
        for (String value : values) {
            copied.add(requireNotBlank(value, name));
        }
        return Collections.unmodifiableList(copied);
    }

    static Integer checkLimit(Integer limit) {
        if (limit != null && (limit.intValue() < MIN_LIMIT || limit.intValue() > MAX_LIMIT)) {
            throw new IllegalArgumentException("limit must be between " + MIN_LIMIT + " and " + MAX_LIMIT);
        }
        return limit;
    }

    static Integer checkOffset(Integer offset) {
        if (offset != null && offset.intValue() < 0) {
            throw new IllegalArgumentException("offset must not be negative");
        }
        return offset;
    }

    /**
     * 경로에 그대로 들어갈 세그먼트인지 확인한다.
     *
     * <p>{@code /}·{@code ?}·{@code #} 가 들어 있으면 URL의 경로·쿼리·프래그먼트 경계를 넘어 <b>다른 요청</b>이 된다 —
     * 그런데 서명은 우리가 만든 경로 문자열로 하므로 서명과 실제 요청이 갈릴 수 있다.
     */
    static String requirePathSegment(String value, String name) {
        requireNotBlank(value, name);
        if (value.indexOf('/') >= 0 || value.indexOf('?') >= 0 || value.indexOf('#') >= 0) {
            throw new IllegalArgumentException(name + " must be a single path segment");
        }
        return value;
    }
}
