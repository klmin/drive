package com.thinkfree.governance.sdk.client;

/** 오류와 retry 판단에서 사용하는 API operation이다. */
public enum RequestOperation {
    INGEST_EVENT,
    INGEST_BATCH,
    GET_RECEIPT,
    LIST_EVENTS,
    EXPORT_EVENTS,
    EXPORT_EVENTS_IN_RANGE,
    GET_EVENT,
    LIST_EVIDENCE_GROUPS,
    LIST_EVIDENCE_VERSIONS,
    LIST_EVIDENCE_CHANGES,
    LIST_TENANTS
}
