package com.thinkfree.governance.sdk.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 주된 resource 외에 영향을 받는 대상이다.
 *
 * <p>그룹 전체({@code ALL})와 그 안에서 직접 지정한 계정({@code ACCOUNTS}), 그리고 <b>링크 공유처럼 대상이
 * 특정되지 않은 경우</b>({@code ANYONE})를 {@code selection} 으로 가른다.
 *
 * <p><b>{@code ANYONE} 은 {@code type}·{@code entity}·{@code accounts} 를 함께 보낼 수 없다.</b> 대상을
 * 식별하는 값이 하나도 없는 것이 사실이고, 그 필드를 억지로 채우면 <b>없는 사실이 증적에 남는다.</b>
 * 이 조합만은 SDK가 build 시점에 막는다 — 허용 값을 막는 것이 아니라 <b>요청의 모양을 가르는 규칙</b>이고
 * 서버도 400 이다.
 *
 * <p>{@code shareScope}(공유 범위)와 {@code permission}(부여된 권한)은 <b>임의 JSON 값</b>이다. 연동마다 쓰는
 * 이름이 달라 계약이 열거로 잠그지 않았고, SDK도 값으로 거부하지 않는다 — 알려진 값은 상수로만 내보낸다.
 *
 * <p><b>모양도 정하지 않는다.</b> 보통 문자열이지만 원천이 권한을 여러 개로 주면(TFD는
 * {@code {"permissions":["VIEW","DOWNLOAD"]}}) 받은 구조를 그대로 넣으면 된다 — {@code Map} · {@code List} 를
 * 넘겨도 되고 문자열을 넘겨도 된다. 서버는 값을 해석하지 않고 받은 그대로 저장·응답한다.
 * {@code null} 을 넣으면 그 필드를 보내지 않는 것과 같다(서버가 명시적 널을 거부한다).
 */
public final class Target {
    /** 그룹(entity) 전체가 대상이다. */
    public static final String SELECTION_ALL = "ALL";
    /** {@code accounts} 에 열거한 계정만 직접 대상이다. */
    public static final String SELECTION_ACCOUNTS = "ACCOUNTS";
    /**
     * 링크 공유처럼 <b>대상이 특정되지 않은</b> 경우다(Google {@code anyone}, MS {@code anonymous}).
     * 이 값일 때는 {@code type}·{@code entity}·{@code accounts} 를 보낼 수 없다.
     */
    public static final String SELECTION_ANYONE = "ANYONE";

    private final String type;
    private final String selection;
    private final Object shareScope;
    private final Object permission;
    private final String entityId;
    private final String entityName;
    private final List<Account> accounts;
    private Target(Builder builder) {
        selection = required(builder.selection, "selection");
        accounts = Collections.unmodifiableList(new ArrayList<Account>(builder.accounts));
        if (SELECTION_ANYONE.equals(selection)) {
            // 대상을 특정하는 값이 하나도 없는 것이 사실이다 — 하나라도 있으면 연동 서비스가 뜻을 잘못 잡은 것이다.
            rejectWithAnyone(builder.type, "type");
            rejectWithAnyone(builder.entityId, "entity.id");
            rejectWithAnyone(builder.entityName, "entity.name");
            if (!accounts.isEmpty()) {
                throw new IllegalArgumentException("accounts must not be used with selection=" + SELECTION_ANYONE);
            }
            type = null;
        } else {
            type = required(builder.type, "type");
        }
        shareScope = builder.shareScope;
        permission = builder.permission;
        entityId = builder.entityId;
        entityName = builder.entityName;
    }
    public static Builder newBuilder() { return new Builder(); }
    /**
     * 대상 그룹의 타입({@code USER}·{@code GROUP}·{@code TENANT}·{@code ORGANIZATION} 등. 새 문자열도 받는다).
     * {@code selection=ANYONE} 이면 {@code null} 이다.
     */
    public String getType() { return type; }
    public String getSelection() { return selection; }
    /**
     * 이 공유 항목의 <b>공유 범위</b>({@code SPECIFIED_USERS}·{@code ORGANIZATION}·{@code ANYONE_WITH_LINK} 등).
     * 계정이 아니라 <b>공유 항목의 속성</b>이다 — 범위가 다르면 별개의 공유 항목이다.
     */
    public Object getShareScope() { return shareScope; }
    /**
     * 이 공유 항목에 부여된 권한({@code READ}·{@code EDIT} 등). {@code ALL}·{@code ANYONE} 은 계정 배열이
     * 없으므로 <b>권한을 적을 유일한 필드</b>다.
     *
     * <p>⚠ {@link Account#getPermission()} 과 값이 달라도 서버는 거부하지 않고 둘 다 그대로 저장한다 —
     * 어느 쪽이 유효한지는 그 서비스의 권한 모델이 안다. 없으면 기본값을 채우지 않는다("권한 정보를 안 보냈다"와
     * "권한이 없다"는 다른 사실이다).
     */
    public Object getPermission() { return permission; }
    public String getEntityId() { return entityId; }
    public String getEntityName() { return entityName; }
    public List<Account> getAccounts() { return accounts; }
    private static String required(String value, String name) {
        if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException(name + " must not be blank");
        return value;
    }
    private static void rejectWithAnyone(String value, String name) {
        if (value != null) {
            throw new IllegalArgumentException(name + " must not be used with selection=" + SELECTION_ANYONE);
        }
    }
    public static final class Builder {
        private String type;
        private String selection;
        private Object shareScope;
        private Object permission;
        private String entityId;
        private String entityName;
        private final List<Account> accounts = new ArrayList<Account>();
        public Builder setType(String value) { type = value; return this; }
        public Builder setSelection(String value) { selection = value; return this; }
        /** 공유 범위를 지정한다. 연동이 쓰는 이름을 그대로 넣는다(자유 문자열). */
        public Builder setShareScope(Object value) { shareScope = value; return this; }
        /** 이 공유 항목에 부여된 권한을 지정한다(자유 문자열). */
        public Builder setPermission(Object value) { permission = value; return this; }
        public Builder setEntityId(String value) { entityId = value; return this; }
        public Builder setEntityName(String value) { entityName = value; return this; }
        public Builder addAccount(Account value) { accounts.add(value); return this; }
        public Target build() { return new Target(this); }
    }
}
