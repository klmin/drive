package com.thinkfree.governance.sdk.model;

/** 이벤트 처리 결과다. */
public final class Outcome {
    private final String status;
    private final String code;
    private final String message;
    private Outcome(Builder builder) { status = builder.status; code = builder.code; message = builder.message; }
    public static Builder newBuilder() { return new Builder(); }
    public String getStatus() { return status; }
    public String getCode() { return code; }
    public String getMessage() { return message; }
    public static final class Builder {
        private String status;
        private String code;
        private String message;
        public Builder setStatus(String value) { status = value; return this; }
        public Builder setCode(String value) { code = value; return this; }
        public Builder setMessage(String value) { message = value; return this; }
        public Outcome build() { return new Outcome(this); }
    }
}
