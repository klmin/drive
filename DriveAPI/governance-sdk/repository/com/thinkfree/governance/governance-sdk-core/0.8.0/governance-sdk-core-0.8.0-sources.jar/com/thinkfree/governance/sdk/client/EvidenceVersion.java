package com.thinkfree.governance.sdk.client;

import java.util.Map;

/**
 * 버전 타임라인의 한 줄이다.
 *
 * <p>{@link #getVersion()} 이 {@code null} 이면 <b>버전을 보내지 않은 이벤트들</b>의 그룹이다(로컬 파일처럼
 * 버전이 없는 연동). 정렬은 버전 문자열이 아니라 <b>마지막 발생 시각</b> 기준이다.
 */
public final class EvidenceVersion {
    private final Map<String, Object> values;

    EvidenceVersion(Map<String, Object> values) {
        this.values = ResponseValues.copyOf(values);
    }

    /** 버전 값. 버전을 안 보낸 이벤트 그룹이면 {@code null}. */
    public String getVersion() { return text("version"); }
    public Long getEventCount() { return ResponseValues.longValue(values, "eventCount"); }
    public String getFirstOccurredAt() { return text("firstOccurredAt"); }
    /** 그 버전의 마지막 이벤트 시각. 정렬 기준이다. */
    public String getLastOccurredAt() { return text("lastOccurredAt"); }
    /** 그 버전 마지막 이벤트의 수행자 유형. */
    public String getActorType() { return text("actorType"); }
    public String getActorName() { return text("actorName"); }
    /** 그 버전을 저장한 수행자의 이메일. */
    public String getActorEmail() { return text("actorEmail"); }

    /**
     * 그 버전의 누적 변경 집계.
     *
     * @return 집계. 서버가 안 주면 {@code null}
     */
    public ContentChangeSums getContentChange() {
        Map<String, Object> sums = ResponseValues.object(values, "contentChange");
        return sums == null ? null : new ContentChangeSums(sums);
    }

    /** 응답 한 줄의 원문 값 전부(수정 불가). */
    public Map<String, Object> asMap() { return values; }

    private String text(String name) { return ResponseValues.text(values, name); }
}
