package com.thinkfree.governance.sdk.client;

import com.thinkfree.governance.sdk.auth.DefaultUuidV7Generator;
import com.thinkfree.governance.sdk.auth.DefaultHmacSigner;
import com.thinkfree.governance.sdk.auth.GovernanceCredentials;
import com.thinkfree.governance.sdk.auth.HmacSigner;
import com.thinkfree.governance.sdk.auth.NonceGenerator;
import com.thinkfree.governance.sdk.auth.UuidV7Generator;
import com.thinkfree.governance.sdk.json.JsonCodec;
import com.thinkfree.governance.sdk.transport.HttpTransport;

import java.net.URI;
import java.time.Clock;
import java.util.UUID;

/** 거버넌스 client 생성에 필요한 설정 그룹이다. */
public final class GovernanceClientSettings {
    private final URI endpoint;
    private final GovernanceCredentials credentials;
    private final HttpTransport httpTransport;
    private final JsonCodec jsonCodec;
    private final Clock clock;
    private final NonceGenerator nonceGenerator;
    private final UuidV7Generator uuidV7Generator;
    private final HmacSigner hmacSigner;
    private final RetryPolicy retryPolicy;

    private GovernanceClientSettings(Builder builder) {
        endpoint = normalizeEndpoint(builder.endpoint);
        credentials = require(builder.credentials, "credentials");
        httpTransport = builder.httpTransport;
        jsonCodec = builder.jsonCodec;
        clock = builder.clock;
        nonceGenerator = builder.nonceGenerator;
        uuidV7Generator = builder.uuidV7Generator;
        hmacSigner = builder.hmacSigner;
        retryPolicy = builder.retryPolicy;
    }

    public static Builder newBuilder() { return new Builder(); }
    public URI getEndpoint() { return endpoint; }
    public GovernanceCredentials getCredentials() { return credentials; }
    public HttpTransport getHttpTransport() { return httpTransport; }
    public JsonCodec getJsonCodec() { return jsonCodec; }
    public Clock getClock() { return clock; }
    public NonceGenerator getNonceGenerator() { return nonceGenerator; }
    public UuidV7Generator getUuidV7Generator() { return uuidV7Generator; }
    public HmacSigner getHmacSigner() { return hmacSigner; }
    public RetryPolicy getRetryPolicy() { return retryPolicy; }

    private static URI normalizeEndpoint(URI value) {
        URI endpoint = require(value, "endpoint");
        if (endpoint.getQuery() != null || endpoint.getFragment() != null) throw new IllegalArgumentException("endpoint must not have query or fragment");
        String text = endpoint.toString();
        while (text.endsWith("/") && text.length() > 1) text = text.substring(0, text.length() - 1);
        return URI.create(text);
    }

    private static <T> T require(T value, String name) {
        if (value == null) throw new NullPointerException(name + " must not be null");
        return value;
    }

    /** client 설정 builder다. */
    public static final class Builder {
        private URI endpoint;
        private GovernanceCredentials credentials;
        private HttpTransport httpTransport;
        private JsonCodec jsonCodec;
        private Clock clock = Clock.systemUTC();
        private NonceGenerator nonceGenerator = new NonceGenerator() {
            @Override public String nextNonce() { return UUID.randomUUID().toString(); }
        };
        private UuidV7Generator uuidV7Generator = new DefaultUuidV7Generator();
        private HmacSigner hmacSigner = new DefaultHmacSigner();
        private RetryPolicy retryPolicy = RetryPolicy.noRetry();
        public Builder setEndpoint(URI value) { endpoint = value; return this; }
        public Builder setCredentials(GovernanceCredentials value) { credentials = value; return this; }
        public Builder setHttpTransport(HttpTransport value) { httpTransport = value; return this; }
        public Builder setJsonCodec(JsonCodec value) { jsonCodec = value; return this; }
        public Builder setClock(Clock value) { clock = require(value, "clock"); return this; }
        public Builder setNonceGenerator(NonceGenerator value) { nonceGenerator = require(value, "nonceGenerator"); return this; }
        public Builder setUuidV7Generator(UuidV7Generator value) { uuidV7Generator = require(value, "uuidV7Generator"); return this; }
        public Builder setHmacSigner(HmacSigner value) { hmacSigner = require(value, "hmacSigner"); return this; }
        public Builder setRetryPolicy(RetryPolicy value) { retryPolicy = require(value, "retryPolicy"); return this; }
        public GovernanceClientSettings build() { return new GovernanceClientSettings(this); }
    }
}
