package com.thinkfree.governance.sdk.client;

import com.thinkfree.governance.sdk.model.EventQuery;

import java.io.IOException;

/**
 * 목록 조회를 페이지 단위로 순회한다. 커서 방식과 오프셋 방식을 같은 모양으로 감싼다.
 *
 * <pre>{@code
 * EventPageReader reader = EventPageReader.byOffset(client, query);
 * while (reader.hasNextPage()) {
 *     for (EventSummary event : reader.nextPage().getItems()) {
 *         // 한 건 처리
 *     }
 * }
 * }</pre>
 *
 * <p><b>전체 읽기를 보장해야 하는 용도에는 오프셋 순회({@link #byOffset})를 쓴다.</b> 지금 서버에는 알려진
 * 한계가 있다 — 조회용 프로젝션의 발생 시각이 비어 있는 행은 커서 조건으로 판정할 수 없어 <b>커서로 도달하지
 * 못한다</b>. 그래서 커서 순회는 그런 행을 오류 없이 빠뜨린다(세 데이터베이스 벤더 실측에서 전체 10건 중
 * 커서 8건 / 오프셋 10건). 서버 쪽에서 발생 시각을 필수로 닫는 작업이 진행 중이지만, 그 전까지는 감사
 * 전체 대조처럼 하나도 빠뜨리면 안 되는 곳에 커서를 쓰지 않는다.
 *
 * <p>SDK는 로그를 남기지 않으므로 이 사실을 반환값으로 드러낸다 — 순회가 끝난 뒤
 * {@link #isFullReadGuaranteed()} 와 {@link #getUnreadCount()} 를 확인한다. 서버가 전체 건수를 알려준
 * 경우에는 못 읽은 건수가 {@link #getUnreadCount()} 로 그대로 드러난다.
 *
 * <p>이 객체는 스레드 안전하지 않다. 순회 하나마다 하나를 만든다.
 */
public final class EventPageReader {

    /** 페이지네이션 방식이다. */
    public enum Mode {
        /** {@code offset} 을 늘려 넘긴다. 전 건에 도달한다. */
        OFFSET,
        /** 서버가 준 {@code nextCursor} 로 넘긴다. 발생 시각이 빈 행에는 도달하지 못한다. */
        CURSOR
    }

    private final GovernanceClient client;
    private final EventQuery baseQuery;
    private final Mode mode;
    private final Integer pageLimit;

    private int nextOffset;
    private String nextCursor;
    private boolean finished;
    private long readCount;
    private Long reportedTotalCount;

    private EventPageReader(GovernanceClient client, EventQuery query, Mode mode) {
        if (client == null) {
            throw new NullPointerException("client must not be null");
        }
        if (query == null) {
            throw new NullPointerException("query must not be null");
        }
        this.client = client;
        this.mode = mode;
        this.pageLimit = query.getLimit();
        if (mode == Mode.OFFSET) {
            if (query.getCursor() != null) {
                throw new IllegalArgumentException("offset traversal must not start from a cursor");
            }
            this.baseQuery = query.toBuilder().setOffset(null).build();
            this.nextOffset = query.getOffset() == null ? 0 : query.getOffset().intValue();
        } else {
            if (query.getOffset() != null && query.getOffset().intValue() > 0) {
                throw new IllegalArgumentException("cursor traversal must not start from a positive offset");
            }
            this.baseQuery = query.toBuilder().setOffset(null).build();
            this.nextCursor = query.getCursor();
        }
    }

    /**
     * 오프셋 방식 순회를 만든다. 전 건에 도달하므로 전체 읽기가 필요한 곳에 쓴다.
     *
     * @param client 조회 client
     * @param query 조회 조건. {@code cursor} 가 들어 있으면 거부한다. {@code offset} 은 시작 위치로 쓴다
     * @return 순회 도우미
     */
    public static EventPageReader byOffset(GovernanceClient client, EventQuery query) {
        return new EventPageReader(client, query, Mode.OFFSET);
    }

    /**
     * 커서 방식 순회를 만든다. 큰 목록을 스캔하는 데 값싸지만 <b>전체 읽기를 보장하지 않는다</b>
     * (클래스 설명의 서버 한계 참고).
     *
     * @param client 조회 client
     * @param query 조회 조건. 1 이상의 {@code offset} 이 들어 있으면 거부한다. {@code cursor} 가 있으면 그 지점에서 이어 읽는다
     * @return 순회 도우미
     */
    public static EventPageReader byCursor(GovernanceClient client, EventQuery query) {
        return new EventPageReader(client, query, Mode.CURSOR);
    }

    /** 이 순회가 쓰는 페이지 방식. */
    public Mode getMode() { return mode; }

    /** 아직 읽을 페이지가 남았는지. */
    public boolean hasNextPage() { return !finished; }

    /**
     * 다음 페이지를 조회한다.
     *
     * @return 한 페이지 결과
     * @throws IllegalStateException 순회가 이미 끝난 경우
     * @throws IOException 전송·직렬화 실패
     * @throws GovernanceApiException 서버가 거부한 경우
     */
    public EventListPage nextPage() throws IOException, GovernanceApiException {
        if (finished) {
            throw new IllegalStateException("traversal is finished");
        }
        EventQuery.Builder builder = baseQuery.toBuilder();
        if (mode == Mode.OFFSET) {
            builder.setOffset(Integer.valueOf(nextOffset));
        } else if (nextCursor != null) {
            builder.setCursor(nextCursor);
        }
        EventListPage page = client.listEvents(builder.build());
        int pageSize = page.getItems().size();
        readCount += pageSize;
        if (page.getTotalCount() != null) {
            reportedTotalCount = page.getTotalCount();
        }
        if (mode == Mode.OFFSET) {
            nextOffset += pageSize;
            // 요청한 건수보다 적게 왔으면 마지막 페이지다. 건수를 지정하지 않았으면 서버 기본값을 추측하지 않고
            // 빈 페이지가 올 때까지 읽는다(요청 한 번을 더 쓰더라도 결과가 틀리지 않는다).
            finished = pageSize == 0
                || (pageLimit != null && pageSize < pageLimit.intValue())
                || (reportedTotalCount != null && readCount >= reportedTotalCount.longValue());
        } else {
            // 서버가 커서를 주지 않으면 끝낸다. 이때 남은 건이 있을 수 있다 — getUnreadCount() 로 드러난다.
            nextCursor = page.getNextCursor();
            finished = nextCursor == null;
        }
        return page;
    }

    /** 지금까지 읽은 건수. */
    public long getReadCount() { return readCount; }

    /** 서버가 알려준 전체 건수(가장 최근 응답 기준). 서버가 생략했으면 {@code null}. */
    public Long getReportedTotalCount() { return reportedTotalCount; }

    /**
     * 오프셋 순회는 전 건에 도달한다. 커서 순회는 발생 시각이 빈 행에 도달하지 못해 보장하지 못한다.
     *
     * @return 전체 읽기를 보장하는 방식이면 {@code true}
     */
    public boolean isFullReadGuaranteed() { return mode == Mode.OFFSET; }

    /**
     * 순회가 끝난 뒤 읽지 못한 건수다. 커서 순회가 오류 없이 빠뜨린 건수를 확인하는 메서드다.
     *
     * @return 순회가 끝났고 서버가 전체 건수를 알려준 경우 그 차이(전 건을 읽었으면 0).
     *         아직 순회 중이거나 서버가 전체 건수를 생략했으면 {@code null}
     */
    public Long getUnreadCount() {
        if (!finished || reportedTotalCount == null) {
            return null;
        }
        long remaining = reportedTotalCount.longValue() - readCount;
        return Long.valueOf(remaining > 0 ? remaining : 0L);
    }
}
