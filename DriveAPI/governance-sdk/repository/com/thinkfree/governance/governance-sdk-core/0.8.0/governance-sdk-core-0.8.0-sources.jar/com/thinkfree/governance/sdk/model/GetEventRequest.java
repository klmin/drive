package com.thinkfree.governance.sdk.model;

/**
 * 증적 상세 조회({@code GET /v1/events/{eventId}}) 요청이다.
 *
 * <p>상세 조회는 <b>쿼리 파라미터를 하나도 받지 않는다</b> — 목록 필터를 붙여 보내면 서버가 400으로 거부한다.
 * 그래서 이 요청은 경로 변수 하나만 갖는다. 다른 거버넌스 테넌트의 {@code eventId} 는 404로 돌아온다
 * (증적의 존재 자체를 드러내지 않는다).
 */
public final class GetEventRequest {
    private final String eventId;

    private GetEventRequest(Builder builder) {
        if (builder.eventId == null || builder.eventId.trim().isEmpty()) {
            throw new IllegalArgumentException("eventId must not be blank");
        }
        // 경로 변수는 서명 대상 경로에 그대로 들어간다. 경로를 가르는 문자가 섞이면 서명한 경로와 실제 경로가
        // 달라져 원인 표시 없는 401이 되므로, 계약(UUIDv7)을 벗어난 값은 여기서 막는다.
        if (builder.eventId.indexOf('/') >= 0
            || builder.eventId.indexOf('?') >= 0
            || builder.eventId.indexOf('#') >= 0) {
            throw new IllegalArgumentException("eventId must be a single path segment");
        }
        eventId = builder.eventId;
    }

    public static Builder newBuilder() { return new Builder(); }
    public String getEventId() { return eventId; }

    /** 상세 조회 요청 builder다. */
    public static final class Builder {
        private String eventId;
        public Builder setEventId(String value) { eventId = value; return this; }
        public GetEventRequest build() { return new GetEventRequest(this); }
    }
}
