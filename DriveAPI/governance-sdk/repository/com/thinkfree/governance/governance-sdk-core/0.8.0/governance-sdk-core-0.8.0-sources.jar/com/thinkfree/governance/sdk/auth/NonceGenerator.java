package com.thinkfree.governance.sdk.auth;

/** 요청마다 새로운 HMAC nonce를 만드는 포트다. */
public interface NonceGenerator {
    String nextNonce();
}
