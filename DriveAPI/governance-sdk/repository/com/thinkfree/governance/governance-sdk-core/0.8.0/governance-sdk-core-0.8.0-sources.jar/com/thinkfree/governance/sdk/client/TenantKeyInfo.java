package com.thinkfree.governance.sdk.client;

import java.util.Map;

/**
 * <b>이 요청을 인증한 키</b>의 정보다. 다른 키는 담기지 않고, secret 은 어떤 형태로도 내려오지 않는다.
 */
public final class TenantKeyInfo {
    private final Map<String, Object> values;

    TenantKeyInfo(Map<String, Object> values) {
        this.values = ResponseValues.copyOf(values);
    }

    /** 요청 헤더 {@code X-Gov-Key-Id} 로 보낸 값과 같다. */
    public String getKeyId() { return ResponseValues.text(values, "keyId"); }

    /**
     * 키 상태. {@code ACTIVE} 또는 {@code DEPRECATED} 다.
     *
     * <p>{@code DEPRECATED} 는 <b>회전 중인 과거 키</b>다 — 인증은 통과하지만 새 키로 옮겨야 한다.
     * {@code REVOKED} 는 인증에서 거절되므로 이 응답에 나오지 않는다.
     */
    public String getStatus() { return ResponseValues.text(values, "status"); }

    /** 조회 경로를 쓸 수 있는지. 이 경로가 읽기 권한을 요구하므로 응답에서는 항상 {@code true} 다. */
    public Boolean getCanRead() { return ResponseValues.booleanValue(values, "canRead"); }

    /** 인입 경로를 쓸 수 있는지. 화면이 이 값으로 기능을 가릴 수 있다. */
    public Boolean getCanWrite() { return ResponseValues.booleanValue(values, "canWrite"); }

    /** 키 만료 시각(UTC). <b>{@code null} 이면 만료가 없다</b> — 서버가 필드를 아예 보내지 않는다. */
    public String getExpiresAt() { return ResponseValues.text(values, "expiresAt"); }

    /** 응답 한 항목의 원문 값 전부(수정 불가). */
    public Map<String, Object> asMap() { return values; }
}
