package com.thinkfree.governance.sdk.auth;

import com.thinkfree.governance.sdk.transport.HttpMethod;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;

/** 서버 계약의 HMAC-SHA256 서명을 생성하는 기본 signer다. */
public final class DefaultHmacSigner implements HmacSigner {
    private static final String KEY_ID_HEADER = "X-Gov-Key-Id";
    private static final String TIMESTAMP_HEADER = "X-Gov-Timestamp";
    private static final String NONCE_HEADER = "X-Gov-Nonce";
    private static final String SIGNATURE_HEADER = "X-Gov-Signature";

    /**
     * 서버 HMAC 계약에 맞는 서명 헤더를 생성한다.
     *
     * @param method HTTP 메서드
     * @param path 공개 API 전체 경로
     * @param canonicalQuery 정규화된 query 문자열
     * @param rawBody 서명할 raw body
     * @param timestamp 요청 시각
     * @param nonce 요청별 nonce
     * @param credentials HMAC 자격증명
     * @return `X-Gov-*` 헤더 그룹
     * @throws IllegalArgumentException secret이 유효하지 않은 Base64이거나 입력이 잘못된 경우
     */
    @Override
    public SignedHeaders sign(
        HttpMethod method,
        String path,
        String canonicalQuery,
        byte[] rawBody,
        Instant timestamp,
        String nonce,
        GovernanceCredentials credentials) {
        require(method, "method");
        requireText(path, "path");
        requireText(timestamp == null ? null : timestamp.toString(), "timestamp");
        requireText(nonce, "nonce");
        require(credentials, "credentials");
        byte[] body = rawBody == null ? new byte[0] : rawBody;
        String query = canonicalQuery == null ? "" : canonicalQuery;
        String timestampValue = timestamp.toString();
        String signingInput = "v1\n"
            + credentials.getKeyId() + "\n"
            + credentials.getTenantId() + "\n"
            + timestampValue + "\n"
            + nonce + "\n"
            + method.name() + "\n"
            + path + "\n"
            + query + "\n"
            + sha256Hex(body);

        byte[] secret;
        try {
            secret = Base64.getDecoder().decode(credentials.getBase64Secret());
        } catch (IllegalArgumentException exception) {
            throw new IllegalArgumentException("base64Secret must be valid Base64", exception);
        }

        byte[] signature = hmacSha256(secret, signingInput.getBytes(StandardCharsets.UTF_8));
        Map<String, String> headers = new LinkedHashMap<String, String>();
        headers.put(KEY_ID_HEADER, credentials.getKeyId());
        headers.put(TIMESTAMP_HEADER, timestampValue);
        headers.put(NONCE_HEADER, nonce);
        headers.put(SIGNATURE_HEADER, Base64.getEncoder().encodeToString(signature));
        return new SignedHeaders(headers);
    }

    private static byte[] hmacSha256(byte[] secret, byte[] input) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret, "HmacSHA256"));
            return mac.doFinal(input);
        } catch (Exception exception) {
            throw new IllegalStateException("HmacSHA256 is not available", exception);
        }
    }

    private static String sha256Hex(byte[] value) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(value);
            StringBuilder result = new StringBuilder(digest.length * 2);
            for (byte item : digest) {
                result.append(String.format("%02x", item & 0xff));
            }
            return result.toString();
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException("SHA-256 is not available", exception);
        }
    }

    private static <T> T require(T value, String name) {
        if (value == null) {
            throw new NullPointerException(name + " must not be null");
        }
        return value;
    }

    private static String requireText(String value, String name) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(name + " must not be blank");
        }
        return value;
    }
}
