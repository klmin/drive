package com.thinkfree.governance.sdk.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 증적 목록 조회({@code GET /v1/events})의 쿼리 파라미터를 형 안전하게 조립한다.
 *
 * <p><b>계약에 없는 파라미터 이름은 서버가 400으로 거부한다</b> — 오류 없이 무시하면 오타가 걸러진 필터로
 * 읽혀 "조건에 맞는 이벤트 전부"라는 잘못된 결론이 나오기 때문이다. 그래서 이 객체의 값은 이름을 문자열로
 * 넘기지 않게 하는 것이다. 계약이 정한 파라미터는 28종이고 여기 setter도 그만큼이다.
 *
 * <p>build 시 검증하는 것은 <b>요청의 모양을 가르는 계약</b>뿐이다.
 * <ul>
 *   <li>{@code limit} 은 1 이상 200 이하(기본 50).</li>
 *   <li>{@code offset} 은 0 이상(기본 0).</li>
 *   <li>{@code cursor} 와 <b>1 이상의</b> {@code offset} 은 함께 쓸 수 없다(페이지 위치가 모호해 서버가 400).</li>
 *   <li>{@code objectVersion} 과 {@code hasObjectVersion} 은 함께 쓸 수 없다 — "v3인 이벤트"과
 *       "버전이 없는 이벤트"은 같은 이벤트일 수 없어 서버가 400이다.</li>
 *   <li>{@code search} 조건은 {@code <searchFieldId>:<값>} 모양이어야 한다(첫 콜론에서만 자른다).</li>
 *   <li>값에 빈 문자열을 넣을 수 없다 — 서버는 빈 값을 400으로 거부한다.</li>
 * </ul>
 *
 * <p>{@code eventType} 개수에는 <b>상한이 없다</b>(서버가 2026-08-04에 20개 제한을 없앴다). 실질 상한은
 * 요청 라인 길이(웹 서버 기본 8KB)에서 온다 — 값이 너무 많으면 이 API의 400이 아니라 웹 서버가 414/431로 끊는다.
 *
 * <p>고정 enum 값({@code actorType}·{@code outcomeStatus}·{@code objectType}·{@code objectStorage})와 필터 길이
 * 상한은 <b>SDK가 막지 않는다</b> — 서버가 허용 값을 늘렸을 때 낡은 SDK가 정상 값을 거부하면 안 되기 때문이다.
 * 오타만 막으려면 {@link QueryVocabulary} 의 상수를 쓴다. 어긋난 값은 서버가 400 + 사유 메시지로 알려준다.
 *
 * <p>정렬은 서버가 발생 시각 내림차순 + {@code eventId} 내림차순으로 고정한다 — 정렬 파라미터는 없다.
 *
 * <p><b>이름 검색 넷({@code actor}·{@code actorName}·{@code actorEmail}·{@code objectName})은 부분 일치다.</b>
 * 값에 든 {@code %}·{@code _} 는 와일드카드가 아니라 글자로 찾는다.
 * ⚠ <b>이 넷은 기간({@code occurredFrom}·{@code occurredTo})과 함께 쓴다.</b> 부분 일치는 앞이 열려 있어
 * 인덱스로 시작 지점을 잡을 수 없고 좁히는 일을 기간이 대신한다 — 서버는 기본 기간을 채워 주지 않으므로
 * (호출자가 걸지 않은 조건이 결과를 바꾸면 감사 조회에서 조용한 왜곡이 된다) <b>연동 서비스가 걸어야 한다.</b>
 *
 * <p>{@code eventType}·{@code actorType}·{@code originSystem}·{@code search} 는 <b>여러 개</b>를 줄 수 있고
 * 같은 이름을 반복해 나간다({@code ?actorType=HUMAN&actorType=AI}).
 */
public final class EventQuery {
    /** 계약이 정한 쿼리 파라미터 이름. 이 이름들만 서버가 받는다(그 밖은 400). */
    private static final String OCCURRED_FROM = "occurredFrom";
    private static final String OCCURRED_TO = "occurredTo";
    private static final String EVENT_TYPE = "eventType";
    private static final String EVENT_CATEGORY = "eventCategory";
    private static final String ACTOR_TYPE = "actorType";
    private static final String ACTOR = "actor";
    private static final String ACTOR_EMAIL = "actorEmail";
    private static final String ACTOR_NAME = "actorName";
    private static final String ORIGIN_SYSTEM = "originSystem";
    private static final String CHANNEL = "channel";
    private static final String OUTCOME_STATUS = "outcomeStatus";
    private static final String OBJECT_TYPE = "objectType";
    private static final String OBJECT_ID = "objectId";
    private static final String OBJECT_NAME = "objectName";
    private static final String OBJECT_VERSION = "objectVersion";
    private static final String HAS_OBJECT_VERSION = "hasObjectVersion";
    private static final String OBJECT_STORAGE = "objectStorage";
    private static final String CORRELATION_ID = "correlationId";
    private static final String SESSION_ID = "sessionId";
    private static final String SCOPE_TYPE = "scopeType";
    private static final String SCOPE_ID = "scopeId";
    private static final String SCOPE_NAME = "scopeName";
    private static final String CLIENT_IP = "clientIp";
    private static final String OBSERVED_IP = "observedIp";
    private static final String SEARCH = "search";
    private static final String LIMIT = "limit";
    private static final String OFFSET = "offset";
    private static final String CURSOR = "cursor";

    /** 한 페이지 최대 건수의 계약 하한·상한. */
    public static final int MIN_LIMIT = 1;
    public static final int MAX_LIMIT = 200;

    /**
     * {@code eventType} 을 한 번에 줄 수 있는 최대 개수.
     *
     * @deprecated 서버가 개수 상한을 없앴다(2026-08-04). SDK도 더 이상 강제하지 않으며 이 상수는 참고 값으로만
     *     남는다 — 상한을 강제하면 서버가 받는 정상 요청을 낡은 SDK가 거부한다.
     */
    @Deprecated
    public static final int MAX_EVENT_TYPES = 20;

    private final Map<String, String> filters;
    private final List<String> eventTypes;
    private final List<String> actorTypes;
    private final List<String> originSystems;
    private final List<String> searchConditions;
    private final Boolean hasObjectVersion;
    private final Integer limit;
    private final Integer offset;
    private final String cursor;

    private EventQuery(Builder builder) {
        Map<String, String> values = new LinkedHashMap<String, String>();
        for (Map.Entry<String, String> filter : builder.filters.entrySet()) {
            values.put(filter.getKey(), requireNotBlank(filter.getValue(), filter.getKey()));
        }
        filters = Collections.unmodifiableMap(values);
        List<String> types = new ArrayList<String>();
        for (String eventType : builder.eventTypes) {
            types.add(requireNotBlank(eventType, EVENT_TYPE));
        }
        eventTypes = Collections.unmodifiableList(types);
        actorTypes = copyOf(builder.actorTypes, ACTOR_TYPE);
        originSystems = copyOf(builder.originSystems, ORIGIN_SYSTEM);
        List<String> conditions = new ArrayList<String>();
        for (String condition : builder.searchConditions) {
            conditions.add(requireSearchCondition(condition));
        }
        searchConditions = Collections.unmodifiableList(conditions);
        hasObjectVersion = builder.hasObjectVersion;
        // 둘을 함께 주면 뜻이 갈린다 — 서버도 400으로 거부한다.
        if (hasObjectVersion != null && filters.containsKey(OBJECT_VERSION)) {
            throw new IllegalArgumentException("objectVersion must not be combined with hasObjectVersion");
        }
        limit = builder.limit;
        offset = builder.offset;
        cursor = builder.cursor == null ? null : requireNotBlank(builder.cursor, CURSOR);
        if (limit != null && (limit.intValue() < MIN_LIMIT || limit.intValue() > MAX_LIMIT)) {
            throw new IllegalArgumentException("limit must be between " + MIN_LIMIT + " and " + MAX_LIMIT);
        }
        if (offset != null && offset.intValue() < 0) {
            throw new IllegalArgumentException("offset must not be negative");
        }
        if (cursor != null && offset != null && offset.intValue() > 0) {
            throw new IllegalArgumentException("cursor must not be combined with a positive offset");
        }
    }

    public static Builder newBuilder() { return new Builder(); }

    public String getOccurredFrom() { return filters.get(OCCURRED_FROM); }
    public String getOccurredTo() { return filters.get(OCCURRED_TO); }
    public List<String> getEventTypes() { return eventTypes; }
    public String getEventCategory() { return filters.get(EVENT_CATEGORY); }
    /**
     * 수행자 유형 조건 전부. 안 걸었으면 빈 목록이다.
     *
     * @return 수정할 수 없는 목록
     */
    public List<String> getActorTypes() { return actorTypes; }
    /**
     * 수행자 유형 조건 하나를 돌려준다.
     *
     * @return 조건이 없으면 {@code null}, 하나면 그 값
     * @throws IllegalStateException 조건이 둘 이상일 때 — <b>첫 값을 오류 없이 돌려주지 않는다.</b> 그러면
     *     "사람 또는 AI" 를 건 조회 결과를 "사람" 의 결과로 읽는 경우가 생긴다
     * @deprecated 여러 개를 줄 수 있게 넓어졌다({@link #getActorTypes()}).
     */
    @Deprecated
    public String getActorType() { return single(actorTypes, ACTOR_TYPE); }
    /**
     * 사용자 한 입력 검색값(이름 <b>또는</b> 이메일).
     *
     * @return 안 걸었으면 {@code null}
     */
    public String getActor() { return filters.get(ACTOR); }
    public String getActorEmail() { return filters.get(ACTOR_EMAIL); }
    public String getActorName() { return filters.get(ACTOR_NAME); }
    /**
     * 연동 시스템 조건 전부. 안 걸었으면 빈 목록이다.
     *
     * @return 수정할 수 없는 목록
     */
    public List<String> getOriginSystems() { return originSystems; }
    /**
     * 연동 시스템 조건 하나를 돌려준다.
     *
     * @return 조건이 없으면 {@code null}, 하나면 그 값
     * @throws IllegalStateException 조건이 둘 이상일 때({@link #getActorType()} 과 같은 이유)
     * @deprecated 여러 개를 줄 수 있게 넓어졌다({@link #getOriginSystems()}).
     */
    @Deprecated
    public String getOriginSystem() { return single(originSystems, ORIGIN_SYSTEM); }
    public String getChannel() { return filters.get(CHANNEL); }
    public String getOutcomeStatus() { return filters.get(OUTCOME_STATUS); }
    public String getObjectType() { return filters.get(OBJECT_TYPE); }
    public String getObjectId() { return filters.get(OBJECT_ID); }
    public String getObjectName() { return filters.get(OBJECT_NAME); }
    public String getObjectVersion() { return filters.get(OBJECT_VERSION); }
    /** 대상 버전이 있는 이벤트만({@code TRUE})·없는 이벤트만({@code FALSE}). 안 걸었으면 {@code null}. */
    public Boolean getHasObjectVersion() { return hasObjectVersion; }
    public String getObjectStorage() { return filters.get(OBJECT_STORAGE); }
    public String getCorrelationId() { return filters.get(CORRELATION_ID); }
    /** 한 세션에서 일어난 이벤트만 보는 조건({@code context.sessionId}). 안 걸었으면 {@code null}. */
    public String getSessionId() { return filters.get(SESSION_ID); }
    public String getScopeType() { return filters.get(SCOPE_TYPE); }
    public String getScopeId() { return filters.get(SCOPE_ID); }
    public String getScopeName() { return filters.get(SCOPE_NAME); }
    public String getClientIp() { return filters.get(CLIENT_IP); }
    public String getObservedIp() { return filters.get(OBSERVED_IP); }
    /** 자유 형식 값 검색 조건을 {@code <searchFieldId>:<값>} 모양 그대로 돌려준다(수정 불가). */
    public List<String> getSearchConditions() { return searchConditions; }
    public Integer getLimit() { return limit; }
    public Integer getOffset() { return offset; }
    public String getCursor() { return cursor; }

    /**
     * 이 쿼리를 서명·URL에 쓸 파라미터 목록으로 내보낸다.
     *
     * <p>설정하지 않은 파라미터는 들어 있지 않다 — 서버 기본값(`limit` 50·`offset` 0)을 SDK가 대신
     * 채워 보내면 연동 서비스가 고르지 않은 조건이 서명 대상에 섞인다.
     * 그대로 {@code com.thinkfree.governance.sdk.auth.CanonicalQuery#of} 에 넘겨 서명 대상 문자열을 만들 수 있다.
     *
     * @return 계약 이름 → 값 목록(수정 불가)
     */
    public Map<String, List<String>> toCanonicalParameters() {
        Map<String, List<String>> parameters = new LinkedHashMap<String, List<String>>();
        for (Map.Entry<String, String> filter : filters.entrySet()) {
            parameters.put(filter.getKey(), Collections.singletonList(filter.getValue()));
        }
        if (!eventTypes.isEmpty()) {
            parameters.put(EVENT_TYPE, eventTypes);
        }
        // 값이 여럿이면 **같은 이름을 반복**해 나간다(계약의 explode: true). 쉼표로 이어 붙이면 서버가 한 값으로
        // 읽어 actorType 은 400, originSystem 은 그 문자열을 찾아 0건이 된다.
        if (!actorTypes.isEmpty()) {
            parameters.put(ACTOR_TYPE, actorTypes);
        }
        if (!originSystems.isEmpty()) {
            parameters.put(ORIGIN_SYSTEM, originSystems);
        }
        if (hasObjectVersion != null) {
            parameters.put(HAS_OBJECT_VERSION,
                Collections.singletonList(hasObjectVersion.booleanValue() ? "true" : "false"));
        }
        if (!searchConditions.isEmpty()) {
            parameters.put(SEARCH, searchConditions);
        }
        if (limit != null) {
            parameters.put(LIMIT, Collections.singletonList(limit.toString()));
        }
        if (offset != null) {
            parameters.put(OFFSET, Collections.singletonList(offset.toString()));
        }
        if (cursor != null) {
            parameters.put(CURSOR, Collections.singletonList(cursor));
        }
        return Collections.unmodifiableMap(parameters);
    }

    /**
     * 페이지 파라미터({@code limit}·{@code offset}·{@code cursor})를 <b>뺀</b> 정규화 파라미터다.
     *
     * <p>기간 전체 내려받기({@code GET /v1/events:export-range})가 쓴다. 그 경로는 전체를 주므로 페이지
     * 파라미터를 <b>받지 않고</b>, 붙여 보내면 "계약에 없는 이름" 이라 400 이다. 같은 {@link EventQuery} 로
     * 목록·한 페이지 CSV·기간 전체 CSV 를 모두 부를 수 있게 하려고 여기서 걸러 낸다.
     *
     * @return 필터만 담은 정규화 파라미터
     */
    public Map<String, List<String>> toCanonicalParametersWithoutPaging() {
        Map<String, List<String>> parameters = new LinkedHashMap<String, List<String>>(toCanonicalParameters());
        parameters.remove(LIMIT);
        parameters.remove(OFFSET);
        parameters.remove(CURSOR);
        return Collections.unmodifiableMap(parameters);
    }

    /**
     * 같은 조건을 담은 builder를 만든다. 페이지 위치({@code offset}·{@code cursor})만 바꿔 다음 페이지를
     * 조립할 때 사용한다.
     *
     * @return 이 쿼리와 같은 값이 채워진 builder
     */
    public Builder toBuilder() {
        Builder builder = new Builder();
        builder.filters.putAll(filters);
        builder.eventTypes.addAll(eventTypes);
        builder.actorTypes.addAll(actorTypes);
        builder.originSystems.addAll(originSystems);
        builder.searchConditions.addAll(searchConditions);
        builder.hasObjectVersion = hasObjectVersion;
        builder.limit = limit;
        builder.offset = offset;
        builder.cursor = cursor;
        return builder;
    }

    /** 반복 파라미터 값들을 검사해 수정 불가 목록으로 만든다. */
    private static List<String> copyOf(List<String> values, String name) {
        List<String> copied = new ArrayList<String>();
        for (String value : values) {
            copied.add(requireNotBlank(value, name));
        }
        return Collections.unmodifiableList(copied);
    }

    /** 값이 하나뿐일 때만 그 값을 준다. 여럿이면 오류 없이 하나를 고르지 않고 실패한다. */
    private static String single(List<String> values, String name) {
        if (values.isEmpty()) {
            return null;
        }
        if (values.size() > 1) {
            throw new IllegalStateException(name + " has " + values.size() + " values; use the list getter");
        }
        return values.get(0);
    }

    private static String requireNotBlank(String value, String name) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(name + " must not be blank");
        }
        return value;
    }

    /**
     * 자유 형식 검색 조건이 {@code <searchFieldId>:<값>} 모양인지 본다.
     *
     * <p>키와 값을 <b>첫 콜론에서만</b> 가른다 — 값에는 콜론이 들어갈 수 있고(URL·시각) 서버가 만드는
     * {@code searchFieldId} 에는 없기 때문이다. 서버도 같은 규칙으로 자르고 어긋나면 400이다.
     */
    private static String requireSearchCondition(String condition) {
        requireNotBlank(condition, SEARCH);
        int separator = condition.indexOf(':');
        if (separator <= 0 || separator == condition.length() - 1) {
            throw new IllegalArgumentException("search must look like <searchFieldId>:<value>: " + condition);
        }
        return condition;
    }

    /**
     * 목록 조회 쿼리 builder다. setter에 {@code null} 을 주면 그 파라미터를 보내지 않는다.
     * 빈 문자열은 build 시 거부한다.
     */
    public static final class Builder {
        private final Map<String, String> filters = new LinkedHashMap<String, String>();
        private final List<String> eventTypes = new ArrayList<String>();
        private final List<String> actorTypes = new ArrayList<String>();
        private final List<String> originSystems = new ArrayList<String>();
        private final List<String> searchConditions = new ArrayList<String>();
        private Boolean hasObjectVersion;
        private Integer limit;
        private Integer offset;
        private String cursor;

        /** 반복 파라미터 목록을 통째로 갈아 끼운다. */
        private Builder replace(List<String> target, List<String> values) {
            target.clear();
            if (values != null) {
                target.addAll(values);
            }
            return this;
        }

        private Builder put(String name, String value) {
            if (value == null) {
                filters.remove(name);
            } else {
                filters.put(name, value);
            }
            return this;
        }

        /** 이벤트 발생 시각 하한(이 값 이상). RFC 3339 offset 표기. */
        public Builder setOccurredFrom(String value) { return put(OCCURRED_FROM, value); }
        /** 이벤트 발생 시각 상한(이 값 미만). RFC 3339 offset 표기. */
        public Builder setOccurredTo(String value) { return put(OCCURRED_TO, value); }
        /** 이벤트 타입 하나를 더한다. 여러 번 부르면 그 타입들 중 하나인 이벤트를 모두 본다(개수 상한 없음). */
        public Builder addEventType(String value) { eventTypes.add(value); return this; }
        /** 이벤트 타입 목록을 통째로 바꾼다. {@code null} 이면 비운다. */
        public Builder setEventTypes(List<String> values) {
            eventTypes.clear();
            if (values != null) {
                eventTypes.addAll(values);
            }
            return this;
        }
        /** 표시·필터용 상위 분류 정확 일치. */
        public Builder setEventCategory(String value) { return put(EVENT_CATEGORY, value); }
        /**
         * 수행자 유형 하나를 더한다({@link QueryVocabulary#ACTOR_TYPES}). 여러 번 부르면 <b>그 유형들 중
         * 하나인</b> 이벤트를 모두 본다(화면의 체크박스 다중 선택).
         */
        public Builder addActorType(String value) { actorTypes.add(value); return this; }
        /** 수행자 유형 목록을 통째로 바꾼다. {@code null} 이면 비운다. */
        public Builder setActorTypes(List<String> values) { return replace(actorTypes, values); }
        /**
         * 수행자 유형 하나만 건다.
         *
         * @deprecated 여러 개를 줄 수 있게 넓어졌다 — {@link #addActorType(String)}·
         *     {@link #setActorTypes(List)} 를 쓴다. 이 메서드는 값 하나짜리 목록과 같다.
         */
        @Deprecated
        public Builder setActorType(String value) {
            actorTypes.clear();
            if (value != null) {
                actorTypes.add(value);
            }
            return this;
        }
        /**
         * 수행자 이메일. 서버가 소문자·앞뒤 공백을 정규화한 뒤 <b>부분 일치</b>로 찾는다 —
         * {@code @acme.example} 로 그 회사 계정을 모아 볼 수 있다. 값에 든 {@code %}·{@code _} 는
         * 와일드카드가 아니라 글자로 찾는다.
         */
        public Builder setActorEmail(String value) { return put(ACTOR_EMAIL, value); }
        /**
         * 수행자 이름. 서버가 대소문자·앞뒤 공백을 정규화한 뒤 <b>부분 일치</b>로 찾는다 —
         * {@code 홍길} 로 {@code 홍길동} 이 걸린다.
         */
        public Builder setActorName(String value) { return put(ACTOR_NAME, value); }
        /**
         * <b>사용자 한 입력 검색</b> — 이름 <b>또는</b> 이메일 어느 쪽에 걸려도 나온다(OR). 어느 쪽인지
         * 모르고 한 칸으로 찾을 때 쓴다. 정규화 후 부분 일치다.
         *
         * <p>{@link #setActorName(String)}·{@link #setActorEmail(String)} 는 그대로 남아 있다 — 어느 쪽인지
         * 아는 검색은 그 둘이 더 좁고, "이름에 홍길 <b>그리고</b> 메일이 acme" 같은 AND 조건은 이 파라미터로
         * 표현할 수 없다. 함께 주면 서로 AND 다.
         */
        public Builder setActor(String value) { return put(ACTOR, value); }
        /**
         * 연동 시스템 하나를 더한다(예 {@code TFD}·{@code MS_WORD}). 여러 번 부르면 그 시스템들 중 하나에서
         * 들어온 이벤트를 모두 본다.
         */
        public Builder addOriginSystem(String value) { originSystems.add(value); return this; }
        /** 연동 시스템 목록을 통째로 바꾼다. {@code null} 이면 비운다. */
        public Builder setOriginSystems(List<String> values) { return replace(originSystems, values); }
        /**
         * 연동 시스템 하나만 건다.
         *
         * @deprecated 여러 개를 줄 수 있게 넓어졌다 — {@link #addOriginSystem(String)}·
         *     {@link #setOriginSystems(List)} 를 쓴다.
         */
        @Deprecated
        public Builder setOriginSystem(String value) {
            originSystems.clear();
            if (value != null) {
                originSystems.add(value);
            }
            return this;
        }
        /** 이벤트가 들어온 경로 정확 일치. */
        public Builder setChannel(String value) { return put(CHANNEL, value); }
        /** 결과 상태 정확 일치({@link QueryVocabulary#OUTCOME_STATUSES}). */
        public Builder setOutcomeStatus(String value) { return put(OUTCOME_STATUS, value); }
        /** 대상 유형 정확 일치({@link QueryVocabulary#OBJECT_TYPES}). */
        public Builder setObjectType(String value) { return put(OBJECT_TYPE, value); }
        /** 대상 식별자 정확 일치. {@code objectVersion} 과 함께 주면 그 버전만 본다. */
        public Builder setObjectId(String value) { return put(OBJECT_ID, value); }
        /**
         * 대상 이름. 서버가 정규화한 뒤 <b>부분 일치</b>로 찾는다 — {@code 보고서} 로
         * {@code 2026_보고서_최종.docx} 가 걸린다. 값에 든 {@code %}·{@code _} 는 글자로 찾는다.
         *
         * <p>⚠ 검색 컬럼 길이 때문에 <b>앞 320자까지만</b> 비교한다. 그보다 뒤에 있는 글자로는 오류 없이
         * 찾을 수 없다(이름·이메일은 인입이 320자에서 막아 잘리지 않는다).
         */
        public Builder setObjectName(String value) { return put(OBJECT_NAME, value); }
        /** 문서 버전 정확 일치. {@code hasObjectVersion} 과 함께 쓸 수 없다. */
        public Builder setObjectVersion(String value) { return put(OBJECT_VERSION, value); }
        /**
         * 대상 버전이 <b>있는 이벤트만</b>({@code TRUE}) 또는 <b>없는 이벤트만</b>({@code FALSE}) 본다.
         * {@code null} 이면 버전으로 거르지 않는다.
         *
         * <p>{@code objectVersion} 은 값이 같은 것만 찾으므로 "버전을 안 보낸 이벤트"을 표현할 수 없다 —
         * 로컬 파일처럼 버전을 안 보내는 연동의 이벤트만 보려면 이 조건이 필요하다.
         * 둘을 <b>함께 줄 수 없다</b>(build에서 거부, 서버도 400).
         */
        public Builder setHasObjectVersion(Boolean value) { hasObjectVersion = value; return this; }
        /** 대상이 저장된 곳 정확 일치({@link QueryVocabulary#OBJECT_STORAGES}). */
        public Builder setObjectStorage(String value) { return put(OBJECT_STORAGE, value); }
        /**
         * 같은 업무 절차의 이벤트를 묶는 값({@code context.correlationId}) 정확 일치.
         * 기계가 만든 식별자라 서버가 정규화하지 않고 보낸 값 그대로 맞춘다.
         */
        public Builder setCorrelationId(String value) { return put(CORRELATION_ID, value); }
        /**
         * 한 세션에서 일어난 이벤트만 본다({@code context.sessionId}) — 정확 일치.
         *
         * <p>기계가 만든 식별자라 서버가 정규화하지 않고 <b>보낸 값 그대로</b> 맞춘다. 문서 편집 계열에서는
         * 이 값이 <b>편집기 세션</b>이라, 한 번 문서를 열어 편집한 과정을 통째로 볼 수 있다.
         */
        public Builder setSessionId(String value) { return put(SESSION_ID, value); }
        /**
         * 고객사 내부 업무 범위의 타입({@code scope.type}) 정확 일치. 알려진 값은 {@code TENANT}·{@code WORKSPACE}
         * 이지만 고정 enum 값이 아니라 새 문자열도 받는다.
         *
         * <p>⚠ {@code scope} 는 <b>격리 경계가 아니라 업무 필터</b>다 — 격리는 인증한 키의 거버넌스 테넌트가 한다.
         */
        public Builder setScopeType(String value) { return put(SCOPE_TYPE, value); }
        /** 업무 범위 식별자({@code scope.id}) 정확 일치. 거버넌스 테넌트와 다른 값이다. */
        public Builder setScopeId(String value) { return put(SCOPE_ID, value); }
        /** 업무 범위 표시 이름({@code scope.name}). 서버가 대소문자·앞뒤 공백을 정규화한 뒤 일치시킨다. */
        public Builder setScopeName(String value) { return put(SCOPE_NAME, value); }
        /** 연동 서비스가 신고한 클라이언트 주소. 서버가 관측한 {@code observedIp} 와 다른 값이라 필터도 따로다. */
        public Builder setClientIp(String value) { return put(CLIENT_IP, value); }
        /** 서버가 관측한 요청 출발 주소. 연동 서비스 신고값은 {@code clientIp} 로 따로 거른다. */
        public Builder setObservedIp(String value) { return put(OBSERVED_IP, value); }
        /**
         * 자유 형식 값 검색 조건 하나를 더한다 — 미리 등록한 경로({@code sourceMetadata}·{@code targets})의 값으로
         * 이벤트를 찾는다. 여러 번 부르면 <b>그 조건들을 모두 만족하는</b> 이벤트만 나온다(AND).
         *
         * <p>키는 {@code filterKey} 가 아니라 서버가 만든 {@code searchFieldId} 다 — {@code filterKey} 는 고객이
         * 바꿀 수 있는 표시 이름라 이름이 바뀌면 저장해 둔 쿼리가 오류 없이 안 걸린다.
         * 등록되지 않은 식별자·꺼 둔 필드·타입이 안 맞는 값은 빈 목록이 아니라 서버 400이다.
         *
         * @param searchFieldId {@code GET /v1/search-fields} 가 알려 주는 등록 식별자
         * @param value 찾을 값. 콜론이 들어가도 된다 — 서버는 첫 콜론에서만 자른다
         */
        public Builder addSearch(String searchFieldId, String value) {
            requireNotBlank(searchFieldId, "searchFieldId");
            requireNotBlank(value, "search value");
            searchConditions.add(searchFieldId + ":" + value);
            return this;
        }
        /** 이미 {@code <searchFieldId>:<값>} 으로 조립된 조건을 그대로 더한다. */
        public Builder addSearchCondition(String condition) { searchConditions.add(condition); return this; }
        /** 검색 조건 목록을 통째로 바꾼다. {@code null} 이면 비운다. */
        public Builder setSearchConditions(List<String> values) {
            searchConditions.clear();
            if (values != null) {
                searchConditions.addAll(values);
            }
            return this;
        }
        /** 한 페이지 최대 건수(1~200). 안 주면 서버 기본 50. */
        public Builder setLimit(Integer value) { limit = value; return this; }
        /** 오프셋 방식에서 건너뛸 건수(0 이상). {@code cursor} 와 1 이상을 함께 줄 수 없다. */
        public Builder setOffset(Integer value) { offset = value; return this; }
        /** 커서 방식에서 이전 응답의 {@code nextCursor} 를 그대로 준다. */
        public Builder setCursor(String value) { cursor = value; return this; }

        public EventQuery build() { return new EventQuery(this); }
    }
}
