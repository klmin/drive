package com.thinkfree.governance.sdk.http;

import com.thinkfree.governance.sdk.transport.HttpRequest;
import com.thinkfree.governance.sdk.transport.HttpResponse;
import com.thinkfree.governance.sdk.transport.HttpTransport;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.time.Duration;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/** Java 8 HttpURLConnection 기반의 기본 transport다. */
public final class JdkHttpTransport implements HttpTransport {
    private final int connectTimeoutMillis;
    private final int readTimeoutMillis;

    private JdkHttpTransport(Builder builder) {
        this.connectTimeoutMillis = toMillis(builder.connectTimeout, "connectTimeout");
        this.readTimeoutMillis = toMillis(builder.readTimeout, "readTimeout");
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    @Override
    public HttpResponse execute(HttpRequest request) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) request.getUri().toURL().openConnection();
        try {
            connection.setRequestMethod(request.getMethod().name());
            connection.setConnectTimeout(connectTimeoutMillis);
            connection.setReadTimeout(readTimeoutMillis);
            connection.setUseCaches(false);
            connection.setInstanceFollowRedirects(false);

            for (Map.Entry<String, String> header : request.getHeaders().entrySet()) {
                connection.setRequestProperty(header.getKey(), header.getValue());
            }

            byte[] requestBody = request.getBody();
            if (requestBody.length > 0) {
                connection.setDoOutput(true);
                connection.setFixedLengthStreamingMode(requestBody.length);
                try (OutputStream output = connection.getOutputStream()) {
                    output.write(requestBody);
                }
            }

            int statusCode = connection.getResponseCode();
            InputStream responseStream = statusCode >= 400
                ? connection.getErrorStream()
                : connection.getInputStream();
            byte[] responseBody = readBytes(responseStream);
            Map<String, List<String>> responseHeaders = connection.getHeaderFields();
            if (responseHeaders == null) {
                responseHeaders = Collections.emptyMap();
            }
            return new HttpResponse(statusCode, responseHeaders, responseBody);
        } finally {
            connection.disconnect();
        }
    }

    @Override
    public void close() throws IOException {
        // 현재는 보유 자원이 없다.
    }

    private static int toMillis(Duration duration, String name) {
        long millis = duration.toMillis();
        if (millis < 0 || millis > Integer.MAX_VALUE) {
            throw new IllegalArgumentException(name + " is outside HttpURLConnection range");
        }
        return (int) millis;
    }

    private static byte[] readBytes(InputStream input) throws IOException {
        if (input == null) {
            return new byte[0];
        }
        try (InputStream source = input; ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = source.read(buffer)) != -1) {
                output.write(buffer, 0, count);
            }
            return output.toByteArray();
        }
    }

    /** JDK transport 설정 builder다. */
    public static final class Builder {
        private Duration connectTimeout = Duration.ofSeconds(5);
        private Duration readTimeout = Duration.ofSeconds(30);

        public Builder setConnectTimeout(Duration timeout) {
            connectTimeout = timeout;
            return this;
        }

        public Builder setReadTimeout(Duration timeout) {
            readTimeout = timeout;
            return this;
        }

        public JdkHttpTransport build() {
            return new JdkHttpTransport(this);
        }
    }
}
