package com.thinkfree.governance.sdk.client;

/** 배치 항목 하나의 처리 결과 래퍼다. */
public final class BatchItemResult {
    private final String eventId;
    private final String status;
    private final String reason;
    private final String receiptId;
    private final String receivedAt;
    private final String acceptedAt;
    private final String message;

    public BatchItemResult(String eventId, String status, String reason, String receiptId) {
        this(eventId, status, reason, receiptId, null, null, null);
    }

    public BatchItemResult(String eventId, String status, String reason, String receiptId,
                           String receivedAt, String acceptedAt, String message) {
        this.eventId = eventId;
        this.status = status;
        this.reason = reason;
        this.receiptId = receiptId;
        this.receivedAt = receivedAt;
        this.acceptedAt = acceptedAt;
        this.message = message;
    }
    public String getEventId() { return eventId; }
    public String getStatus() { return status; }
    public String getReason() { return reason; }
    public String getReceiptId() { return receiptId; }
    public String getReceivedAt() { return receivedAt; }
    public String getAcceptedAt() { return acceptedAt; }
    public String getMessage() { return message; }
}
