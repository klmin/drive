package com.thinkfree.governance.sdk.client;

import java.util.Map;

/**
 * 변경 내역의 한 줄 — <b>같은 위치에 일어난 변경을 모은 것</b>이다.
 *
 * <p>자동 저장이 한 문단을 열 번 건드렸으면 한 줄이고 {@link #getItemCount()} 가 10이다. 원문은
 * <b>최초 {@code before} + 최종 {@code after}</b> 라 "처음에 뭐였고 지금 뭐가 됐는지"가 한 줄에 보인다.
 *
 * <p><b>검토자와 생성자는 다른 사람일 수 있다.</b> {@link #getActorName()} 은 그 위치의 <b>최종 변경이 실려 온
 * 이벤트의 수행자</b>(승인·거절한 주체, 화면의 "검토자")이고, {@link #getProducedByName()} 은 그 콘텐츠를
 * <b>만든 쪽</b>(사람 또는 AI)이다. AI 제안을 사람이 승인한 이벤트에서 둘이 갈린다.
 *
 * <p>시각도 둘이다 — {@link #getLastOccurredAt()} 은 이벤트가 일어난 시각(화면의 "검토 시각", 정렬 기준),
 * {@link #getProducedAt()} 은 그 항목이 만들어진 시각이다. 편집 중 쌓아 뒀다 저장하는 연동에서 갈린다.
 */
public final class EvidenceChange {
    private final Map<String, Object> values;

    EvidenceChange(Map<String, Object> values) {
        this.values = ResponseValues.copyOf(values);
    }

    /** 그룹 식별자. <b>서버가 계산한 값</b>이라 연동 서비스가 만들지 않는다. */
    public String getGroupKey() { return text("groupKey"); }
    /** 이 위치에서 일어난 변경 항목 수(합침 수). */
    public Long getItemCount() { return ResponseValues.longValue(values, "itemCount"); }
    /** 이 위치의 첫 이벤트 시각(구간 시작). */
    public String getFirstOccurredAt() { return text("firstOccurredAt"); }
    /** 이 위치의 마지막 이벤트 시각. <b>정렬 기준</b>이고 화면의 "검토 시각"이다. */
    public String getLastOccurredAt() { return text("lastOccurredAt"); }

    /** 검토자(최종 변경이 실려 온 이벤트의 수행자) 유형. */
    public String getActorType() { return text("actorType"); }
    /** 검토자 이름. */
    public String getActorName() { return text("actorName"); }
    /** 검토자 이메일. */
    public String getActorEmail() { return text("actorEmail"); }

    /**
     * AI이 만든 항목 수.
     *
     * <p>⚠ {@code aiCount} + {@code humanCount} 가 {@link #getItemCount()} 보다 작을 수 있다 —
     * 생산자를 안 보낸 항목은 어느 쪽으로도 안 세기 때문이다.
     */
    public Long getAiCount() { return ResponseValues.longValue(values, "aiCount"); }
    /** 사람이 만든 항목 수. */
    public Long getHumanCount() { return ResponseValues.longValue(values, "humanCount"); }
    /** 승인된 항목 수. */
    public Long getApprovedCount() { return ResponseValues.longValue(values, "approvedCount"); }
    /** 거절된 항목 수. */
    public Long getRejectedCount() { return ResponseValues.longValue(values, "rejectedCount"); }

    /** 이 위치의 식별자. <b>묶는 기준</b>이며 연동 서비스가 보낸 값 그대로다. */
    public String getTargetId() { return text("targetId"); }
    /** 표시용 위치 문자열(`문단3`). ⚠ 묶는 기준이 아니다 — 최종 항목이 준 값이다. */
    public String getTargetRange() { return text("targetRange"); }
    public String getTargetType() { return text("targetType"); }
    public String getItemType() { return text("itemType"); }
    /** 최종 항목의 검토 상태. */
    public String getItemStatus() { return text("itemStatus"); }
    public String getActionType() { return text("actionType"); }

    /** 최종 항목의 콘텐츠가 만들어진 시각. 이벤트 시각과 다른 값이다. */
    public String getProducedAt() { return text("producedAt"); }
    /** 생성자 유형({@code HUMAN}·{@code AI}). */
    public String getProducedByType() { return text("producedByType"); }
    public String getProducedByProvider() { return text("producedByProvider"); }
    public String getProducedByModel() { return text("producedByModel"); }
    /** 생성자 이름. 사람이면 사람 이름, AI이면 에이전트 이름이다. */
    public String getProducedByName() { return text("producedByName"); }
    /** 생성자 이메일. 사람일 때만 있다. */
    public String getProducedByEmail() { return text("producedByEmail"); }

    /** 최초 항목이 속한 이벤트. 감사 로그로 건너갈 때 쓴다. */
    public String getFirstEventId() { return text("firstEventId"); }
    /** 최종 항목이 속한 이벤트. */
    public String getLastEventId() { return text("lastEventId"); }

    /**
     * <b>최초</b> 항목의 원문. 원본 증적을 복호화한 값이라 연동 서비스가 보낸 구조 그대로다.
     *
     * @return 원문 구조. 없으면 {@code null}
     */
    public Map<String, Object> getBeforeContent() { return ResponseValues.object(values, "beforeContent"); }
    /**
     * <b>최종</b> 항목의 원문.
     *
     * @return 원문 구조. 없으면 {@code null}
     */
    public Map<String, Object> getAfterContent() { return ResponseValues.object(values, "afterContent"); }

    /** 응답 한 줄의 원문 값 전부(수정 불가). */
    public Map<String, Object> asMap() { return values; }

    private String text(String name) { return ResponseValues.text(values, name); }
}
