package com.thinkfree.governance.sdk.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** 배치 인입 결과 래퍼다. */
public final class BatchIngestResult {
    private final List<BatchItemResult> results;
    public BatchIngestResult(List<BatchItemResult> results) {
        this.results = Collections.unmodifiableList(new ArrayList<BatchItemResult>(results));
    }
    public List<BatchItemResult> getResults() { return results; }
}
