package com.thinkfree.governance.sdk.client;

/** 단건 인입 결과의 래퍼다. */
public final class IngestResult {
    private final String eventId;
    private final String status;
    private final String receiptId;
    private final String receivedAt;
    private final String acceptedAt;
    public IngestResult(String eventId, String status, String receiptId, String receivedAt, String acceptedAt) {
        this.eventId = eventId; this.status = status; this.receiptId = receiptId; this.receivedAt = receivedAt; this.acceptedAt = acceptedAt;
    }
    public String getEventId() { return eventId; }
    public String getStatus() { return status; }
    public String getReceiptId() { return receiptId; }
    public String getReceivedAt() { return receivedAt; }
    public String getAcceptedAt() { return acceptedAt; }
}
