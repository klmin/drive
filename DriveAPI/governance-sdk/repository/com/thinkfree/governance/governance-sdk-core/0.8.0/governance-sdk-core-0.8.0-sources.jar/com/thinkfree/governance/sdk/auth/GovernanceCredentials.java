package com.thinkfree.governance.sdk.auth;

import java.util.Objects;

/** 거버넌스 서버 HMAC 인증에 필요한 자격증명이다. */
public final class GovernanceCredentials {
    private final String tenantId;
    private final String keyId;
    private final String base64Secret;

    private GovernanceCredentials(Builder builder) {
        this.tenantId = requireText(builder.tenantId, "tenantId");
        this.keyId = requireText(builder.keyId, "keyId");
        this.base64Secret = requireText(builder.base64Secret, "base64Secret");
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public String getTenantId() {
        return tenantId;
    }

    public String getKeyId() {
        return keyId;
    }

    public String getBase64Secret() {
        return base64Secret;
    }

    @Override
    public String toString() {
        return "GovernanceCredentials{" +
            "tenantId='" + tenantId + '\'' +
            ", keyId='" + keyId + '\'' +
            ", base64Secret='[REDACTED]'" +
            '}';
    }

    private static String requireText(String value, String name) {
        return Objects.requireNonNull(value, name + " must not be null").trim().isEmpty()
            ? fail(name)
            : value;
    }

    private static String fail(String name) {
        throw new IllegalArgumentException(name + " must not be blank");
    }

    /** 자격증명 builder다. */
    public static final class Builder {
        private String tenantId;
        private String keyId;
        private String base64Secret;

        public Builder setTenantId(String tenantId) {
            this.tenantId = tenantId;
            return this;
        }

        public Builder setKeyId(String keyId) {
            this.keyId = keyId;
            return this;
        }

        public Builder setBase64Secret(String base64Secret) {
            this.base64Secret = base64Secret;
            return this;
        }

        public GovernanceCredentials build() {
            return new GovernanceCredentials(this);
        }
    }
}
