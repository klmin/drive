package com.thinkfree.governance.sdk.client;

/** retry policy의 판단 결과다. */
public final class RetryDecision {
    private final boolean retry;
    private final long delayMillis;
    private RetryDecision(boolean retry, long delayMillis) { this.retry = retry; this.delayMillis = delayMillis; }
    public static RetryDecision noRetry() { return new RetryDecision(false, 0L); }
    public static RetryDecision retryAfter(long delayMillis) { return new RetryDecision(true, delayMillis); }
    public boolean isRetry() { return retry; }
    public long getDelayMillis() { return delayMillis; }
}
