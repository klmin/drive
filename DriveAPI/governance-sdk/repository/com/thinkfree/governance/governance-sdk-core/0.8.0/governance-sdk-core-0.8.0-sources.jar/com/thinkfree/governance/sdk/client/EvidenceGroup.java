package com.thinkfree.governance.sdk.client;

import java.util.Map;

/**
 * 대상별로 묶은 목록의 한 줄이다(문서 증적 화면의 문서 하나).
 *
 * <p>표시값(이름·경로·최신 버전·마지막 수행자)은 모두 <b>가장 최근 이벤트의 값</b>이다 — 계산한 값이 아니다.
 * 특히 {@link #getObjectVersion()} 은 <b>버전 문자열의 최대값이 아니다.</b>
 *
 * <p>⚠ 목록 필터를 바꿔도 이 줄의 집계·표시값은 움직이지 않는다. 필터는 <b>어떤 대상을 보일지</b>만 정한다.
 */
public final class EvidenceGroup {
    private final Map<String, Object> values;

    EvidenceGroup(Map<String, Object> values) {
        this.values = ResponseValues.copyOf(values);
    }

    /** 묶은 축의 값. 버전 타임라인·변경 내역을 부를 때 경로에 그대로 넣는다. */
    public String getGroupKey() { return text("groupKey"); }
    /** 그 그룹의 이벤트 수. */
    public Long getEventCount() { return ResponseValues.longValue(values, "eventCount"); }
    /** 가장 이른 발생 시각. */
    public String getFirstOccurredAt() { return text("firstOccurredAt"); }
    /** 가장 늦은 발생 시각. 목록 정렬 기준이다. */
    public String getLastOccurredAt() { return text("lastOccurredAt"); }
    public String getObjectType() { return text("objectType"); }
    public String getObjectId() { return text("objectId"); }
    /** 대상 이름. 가장 최근 이벤트의 값이라 이름을 바꿨으면 새 이름이다. */
    public String getObjectName() { return text("objectName"); }
    public String getObjectPath() { return text("objectPath"); }
    /** 최신 버전. <b>버전 문자열의 최대값이 아니라</b> 가장 최근 이벤트의 값이다. */
    public String getObjectVersion() { return text("objectVersion"); }
    public String getObjectStorage() { return text("objectStorage"); }
    public String getOriginSystem() { return text("originSystem"); }
    /** 마지막 수행자의 유형. */
    public String getActorType() { return text("actorType"); }
    /** 마지막 수행자 이름(개인정보). */
    public String getActorName() { return text("actorName"); }
    /** 마지막 수행자 이메일. 화면이 이름과 함께 표시한다. */
    public String getActorEmail() { return text("actorEmail"); }
    /** 가장 최근 이벤트의 타입. */
    public String getLastEventType() { return text("lastEventType"); }

    /**
     * 누적 변경 집계.
     *
     * @return 집계. 서버가 안 주면 {@code null}
     */
    public ContentChangeSums getContentChange() {
        Map<String, Object> sums = ResponseValues.object(values, "contentChange");
        return sums == null ? null : new ContentChangeSums(sums);
    }

    /** 응답 한 줄의 원문 값 전부(수정 불가). */
    public Map<String, Object> asMap() { return values; }

    private String text(String name) { return ResponseValues.text(values, name); }
}
