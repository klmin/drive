package com.thinkfree.governance.sdk.model;

/** target 계정의 식별 정보다. */
public final class Account {
    private final String id;
    private final String name;
    private final String email;
    private final Object permission;
    private Account(Builder builder) {
        id = builder.id;
        name = builder.name;
        email = builder.email;
        permission = builder.permission;
    }
    public static Builder newBuilder() { return new Builder(); }
    public String getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    /**
     * 이 계정에 부여된 권한({@code READ}·{@code EDIT} 등. 자유 문자열).
     *
     * <p>없으면 보내지 않는다 — <b>기본값을 채우지 않는다.</b> "권한 정보를 안 보냈다"와 "권한이 없다"는
     * 다른 사실이고, 서버도 채우지 않는다. 공유 항목 전체의 권한은 {@link Target#getPermission()} 이며
     * 둘이 함께 와도, 값이 달라도 서버는 거부하지 않는다.
     */
    public Object getPermission() { return permission; }
    public static final class Builder {
        private String id;
        private String name;
        private String email;
        private Object permission;
        public Builder setId(String value) { id = value; return this; }
        public Builder setName(String value) { name = value; return this; }
        public Builder setEmail(String value) { email = value; return this; }
        /** 이 계정에 부여된 권한을 지정한다(자유 문자열). */
        public Builder setPermission(Object value) { permission = value; return this; }
        public Account build() {
            if (id == null && name == null && email == null) throw new IllegalArgumentException("account needs an identifier");
            return new Account(this);
        }
    }
}
