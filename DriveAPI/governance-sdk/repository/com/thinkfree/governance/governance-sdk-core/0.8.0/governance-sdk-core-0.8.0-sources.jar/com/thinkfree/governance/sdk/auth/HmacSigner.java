package com.thinkfree.governance.sdk.auth;

import com.thinkfree.governance.sdk.transport.HttpMethod;

import java.time.Instant;

/** 최종 raw body를 거버넌스 HMAC 헤더로 바꾸는 포트다. */
public interface HmacSigner {
    SignedHeaders sign(
        HttpMethod method,
        String path,
        String canonicalQuery,
        byte[] rawBody,
        Instant timestamp,
        String nonce,
        GovernanceCredentials credentials);
}
