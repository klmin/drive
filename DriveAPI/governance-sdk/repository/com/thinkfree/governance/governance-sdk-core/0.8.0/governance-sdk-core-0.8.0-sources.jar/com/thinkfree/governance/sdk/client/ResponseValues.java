package com.thinkfree.governance.sdk.client;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** JSON 응답 map에서 값을 꺼내는 내부 도우미다. 연동 서비스가 보낸 구조를 바꾸지 않고 그대로 돌려준다. */
final class ResponseValues {
    private ResponseValues() {
    }

    static Map<String, Object> copyOf(Map<String, Object> values) {
        return Collections.unmodifiableMap(new LinkedHashMap<String, Object>(
            values == null ? Collections.<String, Object>emptyMap() : values));
    }

    static String text(Map<String, Object> values, String name) {
        Object value = values.get(name);
        return value == null ? null : String.valueOf(value);
    }

    static Long longValue(Map<String, Object> values, String name) {
        Object value = values.get(name);
        if (value == null) {
            return null;
        }
        if (value instanceof Number) {
            return Long.valueOf(((Number) value).longValue());
        }
        try {
            return Long.valueOf(String.valueOf(value));
        } catch (NumberFormatException exception) {
            throw new IllegalArgumentException(name + " must be an integer", exception);
        }
    }

    /**
     * JSON boolean 을 읽는다. <b>없으면 {@code false} 가 아니라 {@code null}</b> 이다 — "안 왔다" 와
     * "거짓이다" 는 다른 사실이라 하나로 접지 않는다.
     */
    static Boolean booleanValue(Map<String, Object> values, String name) {
        Object value = values.get(name);
        if (value == null) {
            return null;
        }
        if (value instanceof Boolean) {
            return (Boolean) value;
        }
        String text = String.valueOf(value);
        if ("true".equalsIgnoreCase(text)) {
            return Boolean.TRUE;
        }
        if ("false".equalsIgnoreCase(text)) {
            return Boolean.FALSE;
        }
        throw new IllegalArgumentException(name + " must be a boolean");
    }

    /** JSON 객체를 구조 그대로 돌려준다(없으면 null). 중첩 값은 codec이 읽은 모양 그대로다. */
    static Map<String, Object> object(Map<String, Object> values, String name) {
        Object value = values.get(name);
        if (value == null) {
            return null;
        }
        if (!(value instanceof Map)) {
            throw new IllegalArgumentException(name + " must be a JSON object");
        }
        @SuppressWarnings("unchecked")
        Map<String, Object> typed = (Map<String, Object>) value;
        return Collections.unmodifiableMap(typed);
    }

    /** JSON 배열을 구조 그대로 돌려준다(없으면 null). 항목을 펼치거나 이어 붙이지 않는다. */
    static List<Object> array(Map<String, Object> values, String name) {
        Object value = values.get(name);
        if (value == null) {
            return null;
        }
        if (!(value instanceof List)) {
            throw new IllegalArgumentException(name + " must be a JSON array");
        }
        @SuppressWarnings("unchecked")
        List<Object> typed = (List<Object>) value;
        return Collections.unmodifiableList(typed);
    }
}
