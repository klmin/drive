package com.thinkfree.governance.sdk.model;

/** receipt 조회 요청의 래퍼다. */
public final class GetIngestReceiptRequest {
    private final String receiptId;
    private GetIngestReceiptRequest(Builder builder) {
        if (builder.receiptId == null || builder.receiptId.trim().isEmpty()) throw new IllegalArgumentException("receiptId must not be blank");
        receiptId = builder.receiptId;
    }
    public static Builder newBuilder() { return new Builder(); }
    public String getReceiptId() { return receiptId; }
    public static final class Builder {
        private String receiptId;
        public Builder setReceiptId(String value) { receiptId = value; return this; }
        public GetIngestReceiptRequest build() { return new GetIngestReceiptRequest(this); }
    }
}
