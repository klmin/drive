package com.thinkfree.governance.sdk.auth;

/** 키 교체나 외부 secret 저장소 연계를 위한 자격증명 공급 포트다. */
public interface CredentialsProvider {
    GovernanceCredentials getCredentials();
}
