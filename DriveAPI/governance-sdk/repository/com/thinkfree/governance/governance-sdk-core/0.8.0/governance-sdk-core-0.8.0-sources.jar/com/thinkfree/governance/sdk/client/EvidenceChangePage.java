package com.thinkfree.governance.sdk.client;

import java.util.Collections;
import java.util.List;

/**
 * 변경 내역 한 페이지다.
 *
 * <p>⚠ {@link #isPartiallyLoaded()} 가 참이면 <b>이 응답이 그 위치의 변경을 다 담지 못했다</b>는 뜻이다 —
 * 복호화하는 적재가 아직 안 끝났거나 옛 이벤트가 섞였을 때다. 화면은 그때 "일부만 불러왔다"를 알려야 한다.
 * 다 온 것처럼 보이면 감사 결론이 틀린다.
 */
public final class EvidenceChangePage {
    private final List<EvidenceChange> items;
    private final Long totalCount;
    private final boolean partiallyLoaded;
    private final String nextCursor;

    EvidenceChangePage(List<EvidenceChange> items, Long totalCount, boolean partiallyLoaded, String nextCursor) {
        this.items = Collections.unmodifiableList(items);
        this.totalCount = totalCount;
        this.partiallyLoaded = partiallyLoaded;
        this.nextCursor = nextCursor;
    }

    public List<EvidenceChange> getItems() { return items; }
    /** 조건에 맞는 그룹(위치) 수. */
    public Long getTotalCount() { return totalCount; }
    /** 이 응답이 일부만 담았는지. 참이면 화면이 그 사실을 알려야 한다. */
    public boolean isPartiallyLoaded() { return partiallyLoaded; }
    /** 다음 페이지 커서. 마지막 페이지면 {@code null}. */
    public String getNextCursor() { return nextCursor; }
}
