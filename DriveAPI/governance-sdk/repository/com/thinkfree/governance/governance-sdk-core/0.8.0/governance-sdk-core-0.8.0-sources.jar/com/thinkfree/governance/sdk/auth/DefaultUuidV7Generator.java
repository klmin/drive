package com.thinkfree.governance.sdk.auth;

import java.security.SecureRandom;
import java.util.UUID;

/** Java 8에서 동작하는 최소 UUIDv7 생성기다. */
public final class DefaultUuidV7Generator implements UuidV7Generator {
    private static final long RANDOM_LOW_MASK = 0x3fffffffffffffffL;
    private final SecureRandom random;

    public DefaultUuidV7Generator() {
        this.random = new SecureRandom();
    }

    @Override
    public String nextUuid() {
        long timestamp = System.currentTimeMillis() & 0x0000ffffffffffffL;
        long mostSignificantBits = (timestamp << 16)
            | 0x7000L
            | (random.nextInt(0x1000) & 0x0fffL);
        long leastSignificantBits = 0x8000000000000000L
            | (random.nextLong() & RANDOM_LOW_MASK);
        return new UUID(mostSignificantBits, leastSignificantBits).toString();
    }
}
