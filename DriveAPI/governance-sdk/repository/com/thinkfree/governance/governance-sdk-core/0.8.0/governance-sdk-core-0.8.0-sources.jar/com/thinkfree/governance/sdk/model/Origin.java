package com.thinkfree.governance.sdk.model;

/** 이벤트가 최초로 발생한 시스템 정보다. */
public final class Origin {
    private final String system;
    private final String component;
    private final String instanceId;

    private Origin(Builder builder) {
        this.system = required(builder.system, "system");
        this.component = builder.component;
        this.instanceId = builder.instanceId;
    }

    public static Builder newBuilder() { return new Builder(); }
    public String getSystem() { return system; }
    public String getComponent() { return component; }
    public String getInstanceId() { return instanceId; }
    private static String required(String value, String name) {
        if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException(name + " must not be blank");
        return value;
    }
    public static final class Builder {
        private String system;
        private String component;
        private String instanceId;
        public Builder setSystem(String value) { system = value; return this; }
        public Builder setComponent(String value) { component = value; return this; }
        public Builder setInstanceId(String value) { instanceId = value; return this; }
        public Origin build() { return new Origin(this); }
    }
}
