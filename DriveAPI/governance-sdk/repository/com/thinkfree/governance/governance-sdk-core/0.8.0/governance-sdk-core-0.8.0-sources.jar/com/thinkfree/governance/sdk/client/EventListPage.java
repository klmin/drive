package com.thinkfree.governance.sdk.client;

import java.util.Collections;
import java.util.List;

/**
 * 목록 조회 한 페이지다.
 *
 * <p>{@link #getNextCursor()} 는 다음 페이지가 있을 때만 있다. {@link #getTotalCount()} 는 오프셋 방식에서
 * 채워지고 커서 방식에서는 비용 때문에 생략될 수 있다 — 없으면 {@code null} 이다.
 *
 * <p>페이지를 직접 넘기는 대신 {@link EventPageReader} 로 순회할 수 있다.
 */
public final class EventListPage {
    private final List<EventSummary> items;
    private final String nextCursor;
    private final Long totalCount;

    EventListPage(List<EventSummary> items, String nextCursor, Long totalCount) {
        this.items = Collections.unmodifiableList(items);
        this.nextCursor = nextCursor;
        this.totalCount = totalCount;
    }

    public List<EventSummary> getItems() { return items; }
    /** 다음 페이지 커서. 마지막 페이지면 {@code null}. */
    public String getNextCursor() { return nextCursor; }
    /** 조건에 맞는 전체 건수. 서버가 생략하면 {@code null}. */
    public Long getTotalCount() { return totalCount; }
}
