package com.thinkfree.governance.sdk.json;

import java.io.IOException;

/** JSON 라이브러리 의존성을 SDK core에서 분리하는 포트다. */
public interface JsonCodec {
    byte[] write(Object value) throws IOException;

    <T> T read(byte[] body, Class<T> type) throws IOException;
}
