package com.thinkfree.governance.sdk.model;

import com.thinkfree.governance.sdk.auth.DefaultUuidV7Generator;
import com.thinkfree.governance.sdk.auth.UuidV7Generator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 서버로 보내는 EventIn 1.0 reported 값의 immutable model이다.
 *
 * 계약이 필수로 요구하는 상자(`schemaVersion`·`eventId`·`eventType`·`occurredAt`·`origin`·`scope`·
 * `actor`·`outcome`)는 build 시 검증한다. `occurredAt`은 이벤트가 실제로 일어난 시각이므로 SDK가
 * 대신 만들어 넣지 않는다 — 호출자가 원천 시각을 RFC 3339 offset 문자열로 제공해야 한다.
 * 콘텐츠가 만들어진 시각은 최상위가 아니라 {@link ContentChangeItem#getProducedAt()}로 항목마다 보낸다.
 */
public final class EventIn {
    private final String schemaVersion;
    private final String eventId;
    private final String eventType;
    private final String sourceEventType;
    private final String sourceEventCategory;
    private final String occurredAt;
    private final Origin origin;
    private final Actor actor;
    private final Scope scope;
    private final EventObject object;
    private final List<Target> targets;
    private final Change change;
    private final Outcome outcome;
    private final Context context;
    private final List<ContentChangeItem> contentChange;
    private final Map<String, Object> sourceMetadata;

    private EventIn(Builder builder) {
        schemaVersion = "1.0";
        eventId = builder.eventId == null ? builder.uuidV7Generator.nextUuid() : builder.eventId;
        eventType = required(builder.eventType, "eventType");
        sourceEventType = builder.sourceEventType;
        sourceEventCategory = builder.sourceEventCategory;
        occurredAt = required(builder.occurredAt, "occurredAt");
        origin = builder.origin;
        actor = builder.actor;
        scope = builder.scope;
        object = builder.object;
        targets = Collections.unmodifiableList(new ArrayList<Target>(builder.targets));
        change = builder.change;
        outcome = builder.outcome;
        context = builder.context;
        contentChange = Collections.unmodifiableList(new ArrayList<ContentChangeItem>(builder.contentChange));
        sourceMetadata = Collections.unmodifiableMap(new LinkedHashMap<String, Object>(builder.sourceMetadata));
        if (origin == null) throw new IllegalArgumentException("origin must not be null");
        if (scope == null) throw new IllegalArgumentException("scope must not be null");
        if (actor == null) throw new IllegalArgumentException("actor must not be null");
        if (outcome == null) throw new IllegalArgumentException("outcome must not be null");
    }

    public static Builder newBuilder() { return new Builder(); }
    public String getSchemaVersion() { return schemaVersion; }
    public String getEventId() { return eventId; }
    public String getEventType() { return eventType; }
    public String getSourceEventType() { return sourceEventType; }
    /**
     * 보낸 서비스의 <b>상위 분류</b>({@code FILE_FOLDER}·{@code LOGIN}·{@code SHARE} 등). 128자 이하.
     *
     * <p>{@link #getSourceEventType()} 의 짝이다 — 그쪽이 이벤트 이름, 이쪽이 그 위의 그룹이다.
     * <b>허용 값은 연동이 정한다</b>: 서버는 받은 값을 그대로 저장하고 조회에서 정확 일치로 찾을 뿐,
     * 유추해서 채우지 않는다.
     *
     * <p>⚠ <b>조회에서는 이름이 {@code eventCategory} 다</b>({@code ?eventCategory=…}). 안 보내면 그 이벤트는
     * 분류 필터로 찾히지 않는다.
     */
    public String getSourceEventCategory() { return sourceEventCategory; }
    public String getOccurredAt() { return occurredAt; }
    public Origin getOrigin() { return origin; }
    public Actor getActor() { return actor; }
    public Scope getScope() { return scope; }
    public EventObject getObject() { return object; }
    public List<Target> getTargets() { return targets; }
    public Change getChange() { return change; }
    public Outcome getOutcome() { return outcome; }
    public Context getContext() { return context; }
    public List<ContentChangeItem> getContentChange() { return contentChange; }
    public Map<String, Object> getSourceMetadata() { return sourceMetadata; }

    private static String required(String value, String name) {
        if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException(name + " must not be blank");
        return value;
    }

    /** EventIn builder다. */
    public static final class Builder {
        private String eventId;
        private String eventType;
        private String sourceEventType;
        private String sourceEventCategory;
        private String occurredAt;
        private Origin origin;
        private Actor actor;
        private Scope scope;
        private EventObject object;
        private final List<Target> targets = new ArrayList<Target>();
        private Change change;
        private Outcome outcome;
        private Context context;
        private final List<ContentChangeItem> contentChange = new ArrayList<ContentChangeItem>();
        private final Map<String, Object> sourceMetadata = new LinkedHashMap<String, Object>();
        private UuidV7Generator uuidV7Generator = new DefaultUuidV7Generator();

        public Builder setEventId(String value) { eventId = value; return this; }
        public Builder setEventType(String value) { eventType = value; return this; }
        public Builder setSourceEventType(String value) { sourceEventType = value; return this; }
        /** 연동이 정한 상위 분류를 지정한다(128자 이하). 조회 필터 이름은 {@code eventCategory} 다. */
        public Builder setSourceEventCategory(String value) { sourceEventCategory = value; return this; }
        public Builder setOccurredAt(String value) { occurredAt = value; return this; }
        public Builder setOrigin(Origin value) { origin = value; return this; }
        public Builder setActor(Actor value) { actor = value; return this; }
        public Builder setScope(Scope value) { scope = value; return this; }
        public Builder setObject(EventObject value) { object = value; return this; }
        public Builder addTarget(Target value) { targets.add(value); return this; }
        public Builder setChange(Change value) { change = value; return this; }
        public Builder setOutcome(Outcome value) { outcome = value; return this; }
        public Builder setContext(Context value) { context = value; return this; }
        public Builder addContentChangeItem(ContentChangeItem value) { contentChange.add(value); return this; }
        public Builder putSourceMetadata(String name, Object value) { sourceMetadata.put(name, value); return this; }
        public Builder setUuidV7Generator(UuidV7Generator value) { uuidV7Generator = value; return this; }
        public EventIn build() { return new EventIn(this); }
    }
}
