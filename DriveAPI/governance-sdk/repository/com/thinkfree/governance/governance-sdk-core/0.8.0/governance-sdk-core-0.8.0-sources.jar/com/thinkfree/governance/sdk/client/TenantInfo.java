package com.thinkfree.governance.sdk.client;

import java.util.Map;

/**
 * 거버넌스 테넌트 한 건이다({@code GET /v1/tenants}).
 *
 * <p><b>운영 정보는 담기지 않는다</b> — 만든 운영자 계정·키 발급 경로·마지막 사용 시각은 관리 콘솔이
 * 관리자에게 보여 줄 값이라 이 경로에서 열지 않는다.
 */
public final class TenantInfo {
    private final Map<String, Object> values;

    TenantInfo(Map<String, Object> values) {
        this.values = ResponseValues.copyOf(values);
    }

    /** 거버넌스 테넌트 식별자(UUIDv7). 서명 세 번째 줄에 넣는 값과 같다. */
    public String getTenantId() { return ResponseValues.text(values, "tenantId"); }

    /** 사람이 읽는 테넌트 이름. */
    public String getDisplayName() { return ResponseValues.text(values, "displayName"); }

    /**
     * 테넌트 상태. <b>이 경로에서는 항상 {@code ACTIVE}</b> 다 — 비활성({@code SUSPENDED}·{@code CLOSED})
     * 테넌트는 인증이 먼저 거절한다.
     */
    public String getStatus() { return ResponseValues.text(values, "status"); }

    /** 고객사 쪽 식별자. 설치할 때 운영자가 넣는 값이며, 안 넣었으면 {@code null} 이다. */
    public String getExternalReference() { return ResponseValues.text(values, "externalReference"); }

    /** 테넌트를 만든 시각(UTC). */
    public String getCreatedAt() { return ResponseValues.text(values, "createdAt"); }

    /**
     * 이 요청을 인증한 키.
     *
     * @return 키 정보. 서버가 안 주면 {@code null}
     */
    public TenantKeyInfo getKey() {
        Map<String, Object> key = ResponseValues.object(values, "key");
        return key == null ? null : new TenantKeyInfo(key);
    }

    /** 응답 한 줄의 원문 값 전부(수정 불가). */
    public Map<String, Object> asMap() { return values; }
}
