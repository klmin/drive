package com.thinkfree.governance.sdk.client;

import java.util.Collections;
import java.util.List;

/**
 * 그룹 목록 한 페이지다.
 *
 * <p>페이지는 {@code offset} 이나 {@link #getNextCursor()} 로 넘긴다. ⚠ <b>커서로 이어 봐도 그룹이 건너뛰거나
 * 겹칠 수 있다</b> — 정렬 키가 "그 문서의 마지막 이벤트 시각"이라 보는 사이에 새 증적이 들어오면 그 그룹이
 * 목록 앞으로 이동한다. 감사 결론을 내는 화면이라면 기간을 좁혀 고정된 조회 대상에서 본다.
 *
 * <p>한 페이지 안의 집계와 표시값은 <b>같은 시점</b>의 것이다. 서버가 이 조회를 여러 쿼리로 나눠 하지만 한
 * 스냅샷에서 읽으므로 "이벤트 수는 5건인데 최신 버전은 6번째 것"이 되지 않는다.
 */
public final class EvidenceGroupPage {
    private final List<EvidenceGroup> items;
    private final Long totalCount;
    private final String nextCursor;

    EvidenceGroupPage(List<EvidenceGroup> items, Long totalCount, String nextCursor) {
        this.items = Collections.unmodifiableList(items);
        this.totalCount = totalCount;
        this.nextCursor = nextCursor;
    }

    public List<EvidenceGroup> getItems() { return items; }
    /** 조건에 맞는 그룹 전체 수. 서버가 생략하면 {@code null}. */
    public Long getTotalCount() { return totalCount; }

    /**
     * 다음 페이지 커서.
     *
     * <p><b>{@code null} 이 "마지막 페이지"를 뜻하지 않는다.</b> 서버는 <b>첫 페이지(offset 없이 부른 요청)와
     * 커서로 부른 요청</b>에만 이 값을 담고, {@code groupBy=objectId} + {@code objectType} 조합이 아니면
     * 아예 커서를 쓸 수 없다 — 깊은 오프셋으로 건너뛴 페이지에는 값이 없다. 오프셋으로 넘기던 순회를
     * 이 값의 유무로 끝내면 남은 페이지를 오류 없이 버린다.
     */
    public String getNextCursor() { return nextCursor; }
}
