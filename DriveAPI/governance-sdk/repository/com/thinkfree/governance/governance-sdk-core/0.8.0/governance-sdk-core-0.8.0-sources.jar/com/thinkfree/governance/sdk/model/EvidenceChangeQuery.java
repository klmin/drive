package com.thinkfree.governance.sdk.model;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 같은 위치끼리 묶어 보는 변경 내역 조회({@code GET /v1/evidence-groups/{groupKey}/changes})다.
 *
 * <p>같은 문서·버전·세션의 <b>같은 위치</b>({@code contentChange[].targetId})에 일어난 변경을 한 줄로 모은다 —
 * 자동 저장이 한 문단을 열 번 건드렸으면 한 줄이고 {@code itemCount} 가 10이다. 원문은
 * <b>최초 {@code before} + 최종 {@code after}</b> 다. {@code targetId} 를 안 보낸 항목은 묶이지 않는다.
 *
 * <p>⚠ <b>여기서 기간은 그룹 목록의 기간과 뜻이 반대다.</b> 목록의 기간은 "어떤 대상을 보일지"만 정하지만,
 * 여기서는 <b>집계도 구간도 원문도 전부 그 기간 안의 항목에서 나온다.</b> 그러지 않으면 "3건 합침"이 기간 밖
 * 편집까지 센 숫자가 된다. 기간의 축은 <b>이벤트 발생 시각</b>(화면의 "검토 시각")이고 정렬 기준과 같다 —
 * 항목이 만들어진 시각은 같은 줄의 {@code producedAt} 으로 따로 온다.
 *
 * <p>서버는 기본 기간을 걸지 않는다. 문서를 눌러 들어왔는데 마지막 편집이 오래 전이면 화면이 빈 채로 열리기
 * 때문이다.
 */
public final class EvidenceChangeQuery {
    private static final String GROUP_BY = "groupBy";
    private static final String OBJECT_TYPE = "objectType";
    private static final String OBJECT_VERSION = "objectVersion";
    private static final String HAS_OBJECT_VERSION = "hasObjectVersion";
    private static final String OCCURRED_FROM = "occurredFrom";
    private static final String OCCURRED_TO = "occurredTo";
    private static final String LIMIT = "limit";
    private static final String OFFSET = "offset";
    private static final String CURSOR = "cursor";

    private final String groupKey;
    private final Map<String, String> filters;
    private final Boolean hasObjectVersion;
    private final Integer limit;
    private final Integer offset;
    private final String cursor;

    private EvidenceChangeQuery(Builder builder) {
        groupKey = QueryValues.requirePathSegment(builder.groupKey, "groupKey");
        Map<String, String> values = new LinkedHashMap<String, String>();
        for (Map.Entry<String, String> filter : builder.filters.entrySet()) {
            values.put(filter.getKey(), QueryValues.requireNotBlank(filter.getValue(), filter.getKey()));
        }
        QueryValues.requireNotBlank(values.get(GROUP_BY), GROUP_BY);
        filters = Collections.unmodifiableMap(values);
        hasObjectVersion = builder.hasObjectVersion;
        // "v3인 것"과 "버전이 없는 것"은 같은 이벤트일 수 없다 — 서버도 400이다.
        if (hasObjectVersion != null && filters.containsKey(OBJECT_VERSION)) {
            throw new IllegalArgumentException("objectVersion must not be combined with hasObjectVersion");
        }
        limit = QueryValues.checkLimit(builder.limit);
        offset = QueryValues.checkOffset(builder.offset);
        cursor = builder.cursor == null ? null : QueryValues.requireNotBlank(builder.cursor, CURSOR);
        if (cursor != null && offset != null && offset.intValue() > 0) {
            throw new IllegalArgumentException("cursor must not be combined with a positive offset");
        }
    }

    public static Builder newBuilder() { return new Builder(); }

    /** 그룹 목록이 돌려준 {@code groupKey}. */
    public String getGroupKey() { return groupKey; }
    public String getGroupBy() { return filters.get(GROUP_BY); }
    public String getObjectType() { return filters.get(OBJECT_TYPE); }
    public String getObjectVersion() { return filters.get(OBJECT_VERSION); }
    /** 버전이 있는 이벤트만({@code TRUE})·없는 이벤트만({@code FALSE}). 안 걸었으면 {@code null}. */
    public Boolean getHasObjectVersion() { return hasObjectVersion; }
    public String getOccurredFrom() { return filters.get(OCCURRED_FROM); }
    public String getOccurredTo() { return filters.get(OCCURRED_TO); }
    public Integer getLimit() { return limit; }
    public Integer getOffset() { return offset; }
    public String getCursor() { return cursor; }

    /**
     * 이 쿼리를 서명·URL에 쓸 파라미터 목록으로 내보낸다({@code groupKey} 는 경로라 여기 없다).
     *
     * @return 계약 이름 → 값 목록(수정 불가)
     */
    public Map<String, List<String>> toCanonicalParameters() {
        Map<String, List<String>> parameters = new LinkedHashMap<String, List<String>>();
        for (Map.Entry<String, String> filter : filters.entrySet()) {
            parameters.put(filter.getKey(), Collections.singletonList(filter.getValue()));
        }
        if (hasObjectVersion != null) {
            parameters.put(HAS_OBJECT_VERSION,
                Collections.singletonList(hasObjectVersion.booleanValue() ? "true" : "false"));
        }
        if (limit != null) {
            parameters.put(LIMIT, Collections.singletonList(limit.toString()));
        }
        if (offset != null) {
            parameters.put(OFFSET, Collections.singletonList(offset.toString()));
        }
        if (cursor != null) {
            parameters.put(CURSOR, Collections.singletonList(cursor));
        }
        return Collections.unmodifiableMap(parameters);
    }

    /**
     * 같은 조건을 담은 builder를 만든다. 페이지 위치만 바꿔 다음 페이지를 조립할 때 쓴다.
     *
     * @return 이 쿼리와 같은 값이 채워진 builder
     */
    public Builder toBuilder() {
        Builder builder = new Builder();
        builder.groupKey = groupKey;
        builder.filters.putAll(filters);
        builder.hasObjectVersion = hasObjectVersion;
        builder.limit = limit;
        builder.offset = offset;
        builder.cursor = cursor;
        return builder;
    }

    /** 변경 내역 쿼리 builder다. */
    public static final class Builder {
        private String groupKey;
        private final Map<String, String> filters = new LinkedHashMap<String, String>();
        private Boolean hasObjectVersion;
        private Integer limit;
        private Integer offset;
        private String cursor;

        private Builder put(String name, String value) {
            if (value == null) {
                filters.remove(name);
            } else {
                filters.put(name, value);
            }
            return this;
        }

        /** 그룹 목록이 돌려준 {@code groupKey}(필수). */
        public Builder setGroupKey(String value) { groupKey = value; return this; }
        /** 목록을 만들 때 쓴 것과 같은 축(필수). */
        public Builder setGroupBy(String value) { return put(GROUP_BY, value); }
        /** 그룹의 대상 유형. 경로가 못 싣는 그룹 키의 일부다. */
        public Builder setObjectType(String value) { return put(OBJECT_TYPE, value); }
        /** 그 버전의 변경만 본다. {@code hasObjectVersion} 과 함께 쓸 수 없다. */
        public Builder setObjectVersion(String value) { return put(OBJECT_VERSION, value); }
        /** 버전이 있는 이벤트만({@code TRUE})·없는 이벤트만({@code FALSE}). */
        public Builder setHasObjectVersion(Boolean value) { hasObjectVersion = value; return this; }
        /**
         * 기간 하한(이 값 이상). ⚠ <b>집계·구간·원문이 모두 이 기간 안에서 나온다</b> — 목록의 기간과 뜻이 다르다.
         */
        public Builder setOccurredFrom(String value) { return put(OCCURRED_FROM, value); }
        /** 기간 상한(이 값 <b>미만</b>). */
        public Builder setOccurredTo(String value) { return put(OCCURRED_TO, value); }
        /** 한 페이지 최대 건수(1~200). 안 주면 서버 기본 50. */
        public Builder setLimit(Integer value) { limit = value; return this; }
        /** 건너뛸 건수(0 이상). {@code cursor} 와 1 이상을 함께 줄 수 없다. */
        public Builder setOffset(Integer value) { offset = value; return this; }
        /** 이전 응답의 {@code nextCursor} 를 그대로 준다. */
        public Builder setCursor(String value) { cursor = value; return this; }

        public EvidenceChangeQuery build() { return new EvidenceChangeQuery(this); }
    }
}
