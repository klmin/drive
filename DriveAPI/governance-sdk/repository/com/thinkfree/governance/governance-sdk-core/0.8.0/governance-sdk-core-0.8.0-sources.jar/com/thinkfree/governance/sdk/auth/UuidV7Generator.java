package com.thinkfree.governance.sdk.auth;

/** EventIn 멱등키에 사용할 UUIDv7 생성 포트다. */
public interface UuidV7Generator {
    String nextUuid();
}
