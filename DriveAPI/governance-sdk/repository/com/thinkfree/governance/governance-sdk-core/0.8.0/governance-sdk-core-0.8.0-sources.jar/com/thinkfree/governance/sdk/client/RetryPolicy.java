package com.thinkfree.governance.sdk.client;

import com.thinkfree.governance.sdk.transport.HttpResponse;

/** SDK 자동 retry 규칙의 확장 포트다. 기본 정책은 retry하지 않는다. */
public interface RetryPolicy {
    RetryDecision evaluate(RequestOperation operation, int attempt, HttpResponse response, Exception exception);

    static RetryPolicy noRetry() {
        return new RetryPolicy() {
            @Override
            public RetryDecision evaluate(RequestOperation operation, int attempt, HttpResponse response, Exception exception) {
                return RetryDecision.noRetry();
            }
        };
    }
}
