package com.thinkfree.governance.sdk.model;

/** EventIn의 직접 행위자 정보다. */
public final class Actor {
    private final String type;
    private final String id;
    private final String name;
    private final String email;
    private final String provider;
    private final String model;
    private final String modelVersion;

    private Actor(Builder builder) {
        this.type = required(builder.type, "type");
        this.id = builder.id;
        this.name = builder.name;
        this.email = builder.email;
        this.provider = builder.provider;
        this.model = builder.model;
        this.modelVersion = builder.modelVersion;
    }

    public static Builder newBuilder() { return new Builder(); }
    public String getType() { return type; }
    public String getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getProvider() { return provider; }
    public String getModel() { return model; }
    public String getModelVersion() { return modelVersion; }

    private static String required(String value, String name) {
        if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException(name + " must not be blank");
        return value;
    }

    public static final class Builder {
        private String type;
        private String id;
        private String name;
        private String email;
        private String provider;
        private String model;
        private String modelVersion;
        public Builder setType(String value) { type = value; return this; }
        public Builder setId(String value) { id = value; return this; }
        public Builder setName(String value) { name = value; return this; }
        public Builder setEmail(String value) { email = value; return this; }
        public Builder setProvider(String value) { provider = value; return this; }
        public Builder setModel(String value) { model = value; return this; }
        public Builder setModelVersion(String value) { modelVersion = value; return this; }
        public Actor build() { return new Actor(this); }
    }
}
