package com.thinkfree.governance.sdk.client;

import com.thinkfree.governance.sdk.auth.CanonicalQuery;
import com.thinkfree.governance.sdk.auth.SignedHeaders;
import com.thinkfree.governance.sdk.model.EventIn;
import com.thinkfree.governance.sdk.model.EventQuery;
import com.thinkfree.governance.sdk.model.EvidenceChangeQuery;
import com.thinkfree.governance.sdk.model.EvidenceGroupQuery;
import com.thinkfree.governance.sdk.model.EvidenceVersionQuery;
import com.thinkfree.governance.sdk.model.GetEventRequest;
import com.thinkfree.governance.sdk.model.GetIngestReceiptRequest;
import com.thinkfree.governance.sdk.model.IngestBatchRequest;
import com.thinkfree.governance.sdk.json.JsonCodec;
import com.thinkfree.governance.sdk.transport.HttpMethod;
import com.thinkfree.governance.sdk.transport.HttpRequest;
import com.thinkfree.governance.sdk.transport.HttpResponse;
import com.thinkfree.governance.sdk.transport.HttpTransport;

import java.io.IOException;
import java.net.URI;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/** 서버 계약에 맞는 raw body·HMAC·HTTP 호출을 조정하는 기본 client다. */
final class DefaultGovernanceClient implements GovernanceClient {
    private static final String CONTENT_TYPE = "Content-Type";
    private static final String ACCEPT = "Accept";
    private static final String JSON = "application/json";
    private static final String CSV = "text/csv";
    private static final String CONTENT_DISPOSITION = "Content-Disposition";
    private static final String RETRY_AFTER = "Retry-After";
    private static final String NEXT_CURSOR = "X-Gov-Next-Cursor";
    private static final byte[] EMPTY_BODY = new byte[0];

    private final GovernanceClientSettings settings;
    private final HttpTransport httpTransport;
    private final JsonCodec jsonCodec;

    DefaultGovernanceClient(GovernanceClientSettings settings) {
        if (settings == null) {
            throw new NullPointerException("settings must not be null");
        }
        this.settings = settings;
        this.httpTransport = requireConfigured(settings.getHttpTransport(), "httpTransport");
        this.jsonCodec = requireConfigured(settings.getJsonCodec(), "jsonCodec");
    }

    @Override
    public IngestResult ingestEvent(EventIn event) throws IOException, GovernanceApiException {
        if (event == null) {
            throw new NullPointerException("event must not be null");
        }
        byte[] rawBody = jsonCodec.write(event);
        RequestSizeGuard.check(rawBody, RequestSizeGuard.SINGLE_EVENT_MAX_BYTES, RequestOperation.INGEST_EVENT);
        HttpResponse response = execute(RequestOperation.INGEST_EVENT, HttpMethod.POST, "/events", "", rawBody);
        Map<String, Object> values = readObject(response);
        return new IngestResult(
            text(values, "eventId"),
            text(values, "status"),
            text(values, "receiptId"),
            text(values, "receivedAt"),
            text(values, "acceptedAt"));
    }

    @Override
    public BatchIngestResult ingestBatch(IngestBatchRequest request)
        throws IOException, GovernanceApiException {
        if (request == null) {
            throw new NullPointerException("request must not be null");
        }
        byte[] rawBody = jsonCodec.write(request);
        RequestSizeGuard.check(rawBody, RequestSizeGuard.BATCH_MAX_BYTES, RequestOperation.INGEST_BATCH);
        HttpResponse response = execute(RequestOperation.INGEST_BATCH, HttpMethod.POST, "/events:batch", "", rawBody);
        Map<String, Object> values = readObject(response);
        Object rawResults = values.get("results");
        if (!(rawResults instanceof List)) {
            throw new IOException("batch response results must be an array");
        }
        List<BatchItemResult> results = new ArrayList<BatchItemResult>();
        for (Object rawResult : (List<?>) rawResults) {
            if (!(rawResult instanceof Map)) {
                throw new IOException("batch response item must be an object");
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> item = (Map<String, Object>) rawResult;
            results.add(new BatchItemResult(
                text(item, "eventId"),
                text(item, "status"),
                text(item, "reason"),
                text(item, "receiptId"),
                text(item, "receivedAt"),
                text(item, "acceptedAt"),
                text(item, "message")));
        }
        return new BatchIngestResult(results);
    }

    @Override
    public IngestReceipt getIngestReceipt(GetIngestReceiptRequest request)
        throws IOException, GovernanceApiException {
        if (request == null) {
            throw new NullPointerException("request must not be null");
        }
        String receiptId = request.getReceiptId();
        if (receiptId.indexOf('/') >= 0 || receiptId.indexOf('?') >= 0 || receiptId.indexOf('#') >= 0) {
            throw new IllegalArgumentException("receiptId must be a single path segment");
        }
        String path = "/ingest-receipts/" + receiptId;
        HttpResponse response = execute(RequestOperation.GET_RECEIPT, HttpMethod.GET, path, "", EMPTY_BODY);
        Map<String, Object> values = readObject(response);
        return new IngestReceipt(
            text(values, "receiptId"),
            text(values, "eventId"),
            text(values, "status"),
            text(values, "receivedAt"),
            text(values, "acceptedAt"),
            text(values, "storedAt"),
            text(values, "segmentId"),
            longValue(values, "seqNo"),
            text(values, "recordHash"),
            text(values, "errorCode"));
    }

    @Override
    public EventListPage listEvents(EventQuery query) throws IOException, GovernanceApiException {
        if (query == null) {
            throw new NullPointerException("query must not be null");
        }
        // 서명 대상 문자열을 만들고 같은 문자열을 URL query로도 쓴다 — "서명한 조건"과 "보낸 조건"이 어긋날 여지를 없앤다.
        String canonicalQuery = CanonicalQuery.of(query.toCanonicalParameters());
        HttpResponse response =
            execute(RequestOperation.LIST_EVENTS, HttpMethod.GET, "/events", canonicalQuery, EMPTY_BODY);
        Map<String, Object> values = readObject(response);
        Object rawItems = values.get("items");
        if (!(rawItems instanceof List)) {
            throw new IOException("list response items must be an array");
        }
        List<EventSummary> items = new ArrayList<EventSummary>();
        for (Object rawItem : (List<?>) rawItems) {
            if (!(rawItem instanceof Map)) {
                throw new IOException("list response item must be an object");
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> item = (Map<String, Object>) rawItem;
            items.add(new EventSummary(item));
        }
        return new EventListPage(items, text(values, "nextCursor"), longValue(values, "totalCount"));
    }

    @Override
    public EventCsvExport exportEvents(EventQuery query) throws IOException, GovernanceApiException {
        if (query == null) {
            throw new NullPointerException("query must not be null");
        }
        // 목록 조회와 같은 쿼리 객체를 그대로 쓴다 — 서버가 받는 파라미터가 같기 때문이다. 두 벌로 나누면
        // 한쪽만 고쳐졌을 때 "화면이 본 것"과 "파일에 담긴 것"이 오류 없이 갈린다.
        String canonicalQuery = CanonicalQuery.of(query.toCanonicalParameters());
        // 경로가 text/csv 만 낸다 — Accept 를 JSON 으로 보내면 서버가 406 으로 끊는다.
        HttpResponse response = execute(
            RequestOperation.EXPORT_EVENTS, HttpMethod.GET, "/events:export", canonicalQuery, EMPTY_BODY, CSV);
        // 응답은 JSON 이 아니다 — 바이트를 그대로 넘긴다. 값을 고치면 서명·해시가 아니라 감사 원본이 바뀐다.
        return new EventCsvExport(
            response.getBody(),
            fileNameOf(header(response, CONTENT_DISPOSITION)),
            header(response, CONTENT_TYPE),
            // 다음 장이 있을 때만 서버가 붙인다. 없으면 null 이고 그것이 마지막 장이라는 뜻이다.
            header(response, NEXT_CURSOR));
    }

    @Override
    public EventCsvExport exportEventsInRange(EventQuery query) throws IOException, GovernanceApiException {
        if (query == null) {
            throw new NullPointerException("query must not be null");
        }
        // ⚠ **페이지 파라미터를 빼고 보낸다.** 이 경로는 전체를 주므로 limit·offset·cursor 를 받지 않고,
        // 붙여 보내면 "계약에 없는 이름" 이라 400 이다. 같은 EventQuery 로 세 경로를 다 부를 수 있게 한다.
        String canonicalQuery = CanonicalQuery.of(query.toCanonicalParametersWithoutPaging());
        HttpResponse response = execute(
            RequestOperation.EXPORT_EVENTS_IN_RANGE, HttpMethod.GET, "/events:export-range",
            canonicalQuery, EMPTY_BODY, CSV);
        return new EventCsvExport(
            response.getBody(),
            fileNameOf(header(response, CONTENT_DISPOSITION)),
            header(response, CONTENT_TYPE),
            // 전체를 준 응답이라 이어 받을 다음 장이 없다 — 서버도 이 헤더를 붙이지 않는다.
            header(response, NEXT_CURSOR));
    }

    @Override
    public EventDetail getEvent(GetEventRequest request) throws IOException, GovernanceApiException {
        if (request == null) {
            throw new NullPointerException("request must not be null");
        }
        // 상세 조회는 쿼리 파라미터를 받지 않는다(붙이면 서버가 400) — 서명 대상 query도 빈 문자열이다.
        String path = "/events/" + request.getEventId();
        HttpResponse response = execute(RequestOperation.GET_EVENT, HttpMethod.GET, path, "", EMPTY_BODY);
        Map<String, Object> values = readObject(response);
        Map<String, Object> observed = ResponseValues.object(values, "observed");
        Map<String, Object> chain = ResponseValues.object(values, "chain");
        if (observed == null || chain == null) {
            throw new IOException("detail response must contain observed and chain");
        }
        return new EventDetail(values, new EventObserved(observed), new EventChainInfo(chain));
    }

    @Override
    public EvidenceGroupPage listEvidenceGroups(EvidenceGroupQuery query)
        throws IOException, GovernanceApiException {
        if (query == null) {
            throw new NullPointerException("query must not be null");
        }
        String canonicalQuery = CanonicalQuery.of(query.toCanonicalParameters());
        HttpResponse response = execute(
            RequestOperation.LIST_EVIDENCE_GROUPS, HttpMethod.GET, "/evidence-groups", canonicalQuery, EMPTY_BODY);
        Map<String, Object> values = readObject(response);
        List<EvidenceGroup> items = new ArrayList<EvidenceGroup>();
        for (Map<String, Object> item : itemsOf(values)) {
            items.add(new EvidenceGroup(item));
        }
        return new EvidenceGroupPage(items, longValue(values, "totalCount"), text(values, "nextCursor"));
    }

    @Override
    public List<EvidenceVersion> listEvidenceVersions(EvidenceVersionQuery query)
        throws IOException, GovernanceApiException {
        if (query == null) {
            throw new NullPointerException("query must not be null");
        }
        String canonicalQuery = CanonicalQuery.of(query.toCanonicalParameters());
        String path = "/evidence-groups/" + encodeSegment(query.getGroupKey()) + "/versions";
        HttpResponse response =
            execute(RequestOperation.LIST_EVIDENCE_VERSIONS, HttpMethod.GET, path, canonicalQuery, EMPTY_BODY);
        Map<String, Object> values = readObject(response);
        List<EvidenceVersion> items = new ArrayList<EvidenceVersion>();
        for (Map<String, Object> item : itemsOf(values)) {
            items.add(new EvidenceVersion(item));
        }
        return Collections.unmodifiableList(items);
    }

    @Override
    public EvidenceChangePage listEvidenceChanges(EvidenceChangeQuery query)
        throws IOException, GovernanceApiException {
        if (query == null) {
            throw new NullPointerException("query must not be null");
        }
        String canonicalQuery = CanonicalQuery.of(query.toCanonicalParameters());
        String path = "/evidence-groups/" + encodeSegment(query.getGroupKey()) + "/changes";
        HttpResponse response =
            execute(RequestOperation.LIST_EVIDENCE_CHANGES, HttpMethod.GET, path, canonicalQuery, EMPTY_BODY);
        Map<String, Object> values = readObject(response);
        List<EvidenceChange> items = new ArrayList<EvidenceChange>();
        for (Map<String, Object> item : itemsOf(values)) {
            items.add(new EvidenceChange(item));
        }
        // ⚠ 없으면 false 로 읽지 않는다 — "일부만 왔다" 를 못 받은 것과 "다 왔다" 는 다른 사실이다.
        Object partial = values.get("partiallyLoaded");
        if (partial == null) {
            throw new IOException("change response must contain partiallyLoaded");
        }
        return new EvidenceChangePage(
            items,
            longValue(values, "totalCount"),
            Boolean.parseBoolean(String.valueOf(partial)),
            text(values, "nextCursor"));
    }

    @Override
    public List<TenantInfo> listTenants() throws IOException, GovernanceApiException {
        // 이 경로는 쿼리 파라미터를 하나도 받지 않는다(붙이면 서버가 400) — 서명 대상 query 도 빈 문자열이다.
        HttpResponse response =
            execute(RequestOperation.LIST_TENANTS, HttpMethod.GET, "/tenants", "", EMPTY_BODY);
        Map<String, Object> values = readObject(response);
        List<TenantInfo> items = new ArrayList<TenantInfo>();
        for (Map<String, Object> item : itemsOf(values)) {
            items.add(new TenantInfo(item));
        }
        return Collections.unmodifiableList(items);
    }

    @Override
    public void close() throws IOException {
        httpTransport.close();
    }

    /**
     * 서명 헤더를 붙여 요청 한 건을 보낸다.
     *
     * <p>서명에 넣는 {@code path} 는 {@code endpoint + operationPath} 의 raw path다 —
     * {@code /v1} 을 포함한, <b>서버가 보는 전체 경로</b>여야 한다.
     *
     * @param canonicalQuery 서명 대상 query 문자열. 없으면 빈 문자열이며 URL에도 query를 붙이지 않는다
     */
    private HttpResponse execute(
        RequestOperation operation,
        HttpMethod method,
        String operationPath,
        String canonicalQuery,
        byte[] rawBody) throws IOException, GovernanceApiException {
        return execute(operation, method, operationPath, canonicalQuery, rawBody, JSON);
    }

    /**
     * 서명 헤더를 붙여 요청 한 건을 보낸다.
     *
     * @param accept 이 경로가 내는 매체 유형. 경로마다 다르다 — CSV 내려받기는 {@code text/csv} 만 내므로
     *               JSON 으로 물으면 406 이다
     */
    private HttpResponse execute(
        RequestOperation operation,
        HttpMethod method,
        String operationPath,
        String canonicalQuery,
        byte[] rawBody,
        String accept) throws IOException, GovernanceApiException {
        String base = settings.getEndpoint().toString() + operationPath;
        URI uri = URI.create(canonicalQuery.isEmpty() ? base : base + "?" + canonicalQuery);
        Instant timestamp = settings.getClock().instant();
        String nonce = settings.getNonceGenerator().nextNonce();
        if (nonce == null || nonce.trim().isEmpty()) {
            throw new IllegalStateException("nonceGenerator returned a blank nonce");
        }
        SignedHeaders signedHeaders = settings.getHmacSigner().sign(
            method,
            uri.getRawPath(),
            uri.getRawQuery() == null ? "" : uri.getRawQuery(),
            rawBody,
            timestamp,
            nonce,
            settings.getCredentials());

        HttpRequest.Builder requestBuilder = HttpRequest.newBuilder()
            .setMethod(method)
            .setUri(uri)
            .setBody(rawBody)
            .putHeader(ACCEPT, accept);
        if (method == HttpMethod.POST) {
            requestBuilder.putHeader(CONTENT_TYPE, JSON);
        }
        for (Map.Entry<String, String> header : signedHeaders.asMap().entrySet()) {
            requestBuilder.putHeader(header.getKey(), header.getValue());
        }

        HttpResponse response = httpTransport.execute(requestBuilder.build());
        if (!isSuccess(operation, response.getStatusCode())) {
            throw toApiException(operation, response);
        }
        return response;
    }

    private Map<String, Object> readObject(HttpResponse response) throws IOException {
        Map<?, ?> values = jsonCodec.read(response.getBody(), Map.class);
        if (values == null) {
            throw new IOException("response body must be a JSON object");
        }
        @SuppressWarnings("unchecked")
        Map<String, Object> typedValues = (Map<String, Object>) values;
        return typedValues;
    }

    private GovernanceApiException toApiException(RequestOperation operation, HttpResponse response) {
        String errorCode = null;
        try {
            Map<String, Object> values = readObject(response);
            errorCode = text(values, "code");
        } catch (IOException ignored) {
            // 오류 body를 읽지 못해도 secret이나 raw body는 예외에 포함하지 않는다.
        }
        int statusCode = response.getStatusCode();
        boolean retryable = statusCode == 429 || statusCode == 503;
        return new GovernanceApiException(
            statusCode, errorCode, retryable, operation, retryAfterSeconds(response));
    }

    /**
     * {@code Retry-After} 를 초로 읽는다. 계약이 내는 것은 초뿐이므로 HTTP-date 형식은 다루지 않고
     * <b>못 읽으면 {@code null}</b> 이다 — 아무 값이나 지어내면 연동 서비스가 그 수만큼 잘못 기다린다.
     */
    private static Integer retryAfterSeconds(HttpResponse response) {
        String value = header(response, RETRY_AFTER);
        if (value == null) {
            return null;
        }
        try {
            int seconds = Integer.parseInt(value.trim());
            return seconds < 0 ? null : Integer.valueOf(seconds);
        } catch (NumberFormatException exception) {
            return null;
        }
    }

    /**
     * 응답 헤더 하나를 읽는다. <b>이름 대소문자를 가리지 않는다</b> — transport 구현마다 서버가 준 표기를
     * 그대로 두기도 하고(HttpURLConnection) 소문자로 내리기도 해서(HTTP/2) 한 표기로 찾으면 놓친다.
     */
    private static String header(HttpResponse response, String name) {
        for (Map.Entry<String, List<String>> entry : response.getHeaders().entrySet()) {
            if (entry.getKey() != null && entry.getKey().equalsIgnoreCase(name)) {
                List<String> values = entry.getValue();
                if (values != null && !values.isEmpty()) {
                    return values.get(0);
                }
            }
        }
        return null;
    }

    /**
     * {@code Content-Disposition} 에서 파일 이름을 꺼낸다
     * (예: {@code attachment; filename="audit-events_20260701-20260731_20260827-090000.csv"}).
     *
     * <p>서버가 이름을 ASCII 로만 만들기 때문에 {@code filename*}(RFC 5987)은 다루지 않는다.
     *
     * @return 파일 이름. 헤더가 없거나 이름이 없으면 {@code null} — 그때는 연동 서비스가 이름을 정한다
     */
    private static String fileNameOf(String contentDisposition) {
        if (contentDisposition == null) {
            return null;
        }
        for (String part : contentDisposition.split(";")) {
            String token = part.trim();
            if (token.regionMatches(true, 0, "filename=", 0, "filename=".length())) {
                String value = token.substring("filename=".length()).trim();
                if (value.length() >= 2 && value.charAt(0) == '"' && value.charAt(value.length() - 1) == '"') {
                    value = value.substring(1, value.length() - 1);
                }
                return value.isEmpty() ? null : value;
            }
        }
        return null;
    }

    /** 목록 응답의 {@code items} 배열을 객체 목록으로 읽는다. 배열이 아니면 그 지점에서 실패한다. */
    private static List<Map<String, Object>> itemsOf(Map<String, Object> values) throws IOException {
        Object rawItems = values.get("items");
        if (!(rawItems instanceof List)) {
            throw new IOException("list response items must be an array");
        }
        List<Map<String, Object>> items = new ArrayList<Map<String, Object>>();
        for (Object rawItem : (List<?>) rawItems) {
            if (!(rawItem instanceof Map)) {
                throw new IOException("list response item must be an object");
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> item = (Map<String, Object>) rawItem;
            items.add(item);
        }
        return items;
    }

    /**
     * 경로 세그먼트를 URL에 실을 수 있게 만든다.
     *
     * <p>{@code groupKey} 는 서버가 계산한 Base64 라 {@code +}·{@code /}·{@code =} 가 들어올 수 있다.
     * 쿼리 객체가 경로 경계를 깨는 글자는 이미 막지만, 남은 글자도 <b>인코딩한 문자열로 서명하고 같은 문자열을
     * URL에 쓴다</b> — 둘이 갈리면 401이 된다.
     */
    private static String encodeSegment(String value) {
        StringBuilder encoded = new StringBuilder(value.length() + 8);
        for (byte raw : value.getBytes(java.nio.charset.Charset.forName("UTF-8"))) {
            int octet = raw & 0xFF;
            if ((octet >= 'A' && octet <= 'Z') || (octet >= 'a' && octet <= 'z') || (octet >= '0' && octet <= '9')
                || octet == '-' || octet == '.' || octet == '_' || octet == '~') {
                encoded.append((char) octet);
            } else {
                encoded.append('%').append(String.format("%02X", Integer.valueOf(octet)));
            }
        }
        return encoded.toString();
    }

    private static boolean isSuccess(RequestOperation operation, int statusCode) {
        if (operation == RequestOperation.INGEST_EVENT) {
            return statusCode == 200 || statusCode == 202;
        }
        return statusCode == 200;
    }

    private static String text(Map<String, Object> values, String name) {
        return ResponseValues.text(values, name);
    }

    private static Long longValue(Map<String, Object> values, String name) {
        return ResponseValues.longValue(values, name);
    }

    private static <T> T requireConfigured(T value, String name) {
        if (value == null) {
            throw new IllegalStateException(name + " must be configured before creating GovernanceClient");
        }
        return value;
    }
}
