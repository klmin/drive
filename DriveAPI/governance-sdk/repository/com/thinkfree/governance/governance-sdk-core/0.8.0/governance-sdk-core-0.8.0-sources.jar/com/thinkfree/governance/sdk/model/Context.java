package com.thinkfree.governance.sdk.model;

/** 이벤트가 발생한 업무 채널과 상관관계 정보다. */
public final class Context {
    private final String channel;
    private final String correlationId;
    private final String sessionId;
    private final String requestId;
    private final String clientIp;
    private Context(Builder builder) {
        channel = builder.channel;
        correlationId = builder.correlationId;
        sessionId = builder.sessionId;
        requestId = builder.requestId;
        clientIp = builder.clientIp;
    }
    public static Builder newBuilder() { return new Builder(); }
    public String getChannel() { return channel; }
    public String getCorrelationId() { return correlationId; }
    public String getSessionId() { return sessionId; }
    public String getRequestId() { return requestId; }
    public String getClientIp() { return clientIp; }
    public static final class Builder {
        private String channel;
        private String correlationId;
        private String sessionId;
        private String requestId;
        private String clientIp;
        public Builder setChannel(String value) { channel = value; return this; }
        public Builder setCorrelationId(String value) { correlationId = value; return this; }
        public Builder setSessionId(String value) { sessionId = value; return this; }
        public Builder setRequestId(String value) { requestId = value; return this; }
        public Builder setClientIp(String value) { clientIp = value; return this; }
        public Context build() { return new Context(this); }
    }
}
