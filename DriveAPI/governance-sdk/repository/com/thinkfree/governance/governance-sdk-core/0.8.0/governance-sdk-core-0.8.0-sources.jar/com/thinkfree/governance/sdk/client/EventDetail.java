package com.thinkfree.governance.sdk.client;

import java.util.Map;

/**
 * 증적 한 건의 전체다. 신고값(reported)과 관측값(observed)을 섞지 않고 따로 담는다.
 *
 * <p>{@link #getReported()} 는 서버가 envelope를 복호화한 <b>연동 서비스 원문</b>으로 인입 때 보낸 EventIn과 같은
 * 구조다. SDK가 EventIn 모델로 다시 조립하지 않고 읽은 구조를 그대로 노출한다 — 명시적 {@code null} 이나
 * 계약에 아직 없는 값까지 원문대로 보이게 하려는 것이다.
 */
public final class EventDetail {
    private final Map<String, Object> values;
    private final EventObserved observed;
    private final EventChainInfo chain;

    EventDetail(Map<String, Object> values, EventObserved observed, EventChainInfo chain) {
        this.values = ResponseValues.copyOf(values);
        this.observed = observed;
        this.chain = chain;
    }

    public String getEventId() { return ResponseValues.text(values, "eventId"); }

    /**
     * 복호화한 연동 서비스 원문(EventIn 구조)을 구조 그대로 돌려준다.
     *
     * @return 인입 때 보낸 EventIn과 같은 모양의 map(수정 불가)
     */
    public Map<String, Object> getReported() { return ResponseValues.object(values, "reported"); }

    /** 서버가 관측·확정한 값. */
    public EventObserved getObserved() { return observed; }

    /** 해시 체인 위치. */
    public EventChainInfo getChain() { return chain; }

    /**
     * 상세 응답 원문 전부를 돌려준다.
     *
     * @return 계약 필드 이름 → 값(수정 불가)
     */
    public Map<String, Object> asMap() { return values; }
}
