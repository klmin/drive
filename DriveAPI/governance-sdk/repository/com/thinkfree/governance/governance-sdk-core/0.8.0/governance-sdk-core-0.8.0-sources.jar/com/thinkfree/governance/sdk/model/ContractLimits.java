package com.thinkfree.governance.sdk.model;

/**
 * 서버 인입 계약이 정한 크기·개수·길이 상한이다.
 *
 * <p><b>SDK는 이 값으로 필드를 미리 거부하지 않는다.</b> 상한은 계약 값이라 서버가 넓힐 수 있고, 그때 낡은
 * SDK가 정상 값을 거부하면 요청이 서버에 도달조차 하지 않아 서버 로그에도 남지 않는다 — 원인을 찾을 방법이
 * 사라진다. 판단은 서버가 하고, 서버는 400에 사유를 붙여 준다.
 *
 * <p>값을 공개하는 이유는 <b>쓰는 쪽이 스스로 자르고 싶을 때</b>다. 예를 들어 문서 이름을 저장 컬럼 길이에
 * 맞춰 미리 줄이려면 {@link #PERSON_FIELD_MAX_CHARS} 같은 값이 필요하다. 단일 원천은 서버 저장소의
 * {@code IngestContractLimits.kt} 와 {@code openapi/governance-ingest.yaml} 이며, 서버가 값을 바꾸면 여기도
 * 같은 작업에서 맞춘다.
 *
 * <p>조회 쿼리의 페이지 상한은 {@link EventQuery#MAX_LIMIT} 에 있다({@code eventType} 개수에는 상한이 없다).
 */
public final class ContractLimits {
    /** 단건·배치 raw 요청 본문 전체의 최대 바이트 수. 넘으면 서버는 413이다. */
    public static final int REQUEST_MAX_BYTES = 8 * 1024 * 1024;

    /** EventIn 한 건을 서버가 재직렬화했을 때 허용하는 최대 바이트 수. */
    public static final int EVENT_MAX_BYTES = 256 * 1024;

    /** {@code contentChange[].content} 하위를 제외한 일반 문자열 값 하나의 최대 UTF-8 바이트 수. */
    public static final int STRING_FIELD_MAX_BYTES = 8 * 1024;

    /** 사람 식별정보(이름·이메일)의 최대 문자 수. 이메일 주소 표준 최대 길이와 같다. */
    public static final int PERSON_FIELD_MAX_CHARS = 320;

    /** 분류 코드({@code scope.type}·{@code object.version}·{@code context.channel})의 최대 문자 수. */
    public static final int TYPE_CODE_MAX_CHARS = 64;

    /** 업무 식별자({@code actor.id}·{@code scope.id}·{@code object.id})와 이벤트 타입의 최대 문자 수. */
    public static final int IDENTIFIER_MAX_CHARS = 255;

    /** 원천 표기({@code origin.system}·{@code origin.component})의 최대 문자 수. */
    public static final int ORIGIN_FIELD_MAX_CHARS = 128;

    /** 주소 값({@code context.clientIp})의 최대 문자 수. */
    public static final int IP_FIELD_MAX_CHARS = 64;

    /** 조회용 프로젝션의 표시·필터 분류의 최대 문자 수. 서버가 자유 JSON에서 뽑아 저장 시점에 자른다. */
    public static final int EVENT_CATEGORY_MAX_CHARS = 128;

    /** {@code sourceMetadata} 객체에서 허용하는 최대 중첩 깊이. */
    public static final int SOURCE_METADATA_MAX_DEPTH = 32;

    /** 배치 요청 한 건에 허용하는 최대 EventIn 항목 수. */
    public static final int BATCH_MAX_ITEMS = 1000;

    private ContractLimits() {
    }
}
