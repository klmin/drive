package com.thinkfree.governance.sdk.client;

import java.util.Map;

/**
 * 증적의 해시 체인 위치다. 정본 무결성 확인에 쓴다.
 *
 * <p>{@link #getContentHash()} 는 이 이벤트 <b>내용</b>의 해시이고, {@link #getRecordHash()} 는 내용 해시와
 * 위치·직전 해시를 묶은 <b>체인 검증용 최종</b> 해시다. {@link #getPrevHash()} 는 직전 이벤트의
 * {@code recordHash} 이며 세그먼트의 첫 이벤트는 0으로 채운 값이다.
 */
public final class EventChainInfo {
    private final Map<String, Object> values;

    EventChainInfo(Map<String, Object> values) {
        this.values = ResponseValues.copyOf(values);
    }

    public String getSegmentId() { return text("segmentId"); }
    public Long getSeqNo() { return ResponseValues.longValue(values, "seqNo"); }
    /** 이 이벤트 내용의 해시(소문자 64자리 16진). */
    public String getContentHash() { return text("contentHash"); }
    /** 직전 이벤트의 {@code recordHash}. */
    public String getPrevHash() { return text("prevHash"); }
    /** 체인 검증용 최종 해시. */
    public String getRecordHash() { return text("recordHash"); }
    public String getEnvelopeVersion() { return text("envelopeVersion"); }
    public String getCanonicalizationVersion() { return text("canonicalizationVersion"); }

    /**
     * 체인 정보 원문 전부를 돌려준다.
     *
     * @return 계약 필드 이름 → 값(수정 불가)
     */
    public Map<String, Object> asMap() { return values; }

    private String text(String name) { return ResponseValues.text(values, name); }
}
