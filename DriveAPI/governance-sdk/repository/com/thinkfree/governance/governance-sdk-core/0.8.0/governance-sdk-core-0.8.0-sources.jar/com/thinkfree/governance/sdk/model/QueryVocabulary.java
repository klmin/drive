package com.thinkfree.governance.sdk.model;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * 값이 고정된 조회 필터의 허용 값이다. 오타로 400을 만나지 않도록 상수로 내보낸다.
 *
 * <p><b>SDK는 이 목록으로 값을 거부하지 않는다.</b> 값 목록의 단일 원천은 서버 계약
 * ({@code openapi/governance-ingest.yaml} 의 {@code Query*} {@code enum})이고, 서버가 허용 값을 늘렸을 때
 * 낡은 SDK가 정상 값을 막으면 안 되기 때문이다. 허용 값 밖의 값은 서버가 400 + 사유 메시지로 알려준다.
 */
public final class QueryVocabulary {
    /** 수행자 유형. */
    public static final String ACTOR_TYPE_HUMAN = "HUMAN";
    public static final String ACTOR_TYPE_AI = "AI";
    public static final String ACTOR_TYPE_SYSTEM = "SYSTEM";
    public static final String ACTOR_TYPE_UNKNOWN = "UNKNOWN";

    /** 결과 상태. */
    public static final String OUTCOME_STATUS_SUCCESS = "SUCCESS";
    public static final String OUTCOME_STATUS_FAIL = "FAIL";

    /** 대상 유형. */
    public static final String OBJECT_TYPE_FILE = "FILE";
    public static final String OBJECT_TYPE_FOLDER = "FOLDER";
    public static final String OBJECT_TYPE_USER = "USER";
    public static final String OBJECT_TYPE_SETTING = "SETTING";

    /** 그룹 조회의 축({@code groupBy}). 문서 증적 화면은 {@code objectId}, 로그인 증적 화면은 {@code actorId} 다. */
    public static final String GROUP_BY_OBJECT_ID = "objectId";
    public static final String GROUP_BY_ACTOR_ID = "actorId";
    public static final String GROUP_BY_SCOPE_ID = "scopeId";
    public static final String GROUP_BY_CORRELATION_ID = "correlationId";

    /** 대상이 저장된 곳. */
    public static final String OBJECT_STORAGE_TFD = "TFD";
    public static final String OBJECT_STORAGE_LOCAL = "LOCAL";
    public static final String OBJECT_STORAGE_USER_STORAGE = "USER_STORAGE";

    /** {@code actorType} 허용 값 전체. */
    public static final Set<String> ACTOR_TYPES = setOf(
        ACTOR_TYPE_HUMAN, ACTOR_TYPE_AI, ACTOR_TYPE_SYSTEM, ACTOR_TYPE_UNKNOWN);
    /** {@code outcomeStatus} 허용 값 전체. */
    public static final Set<String> OUTCOME_STATUSES = setOf(
        OUTCOME_STATUS_SUCCESS, OUTCOME_STATUS_FAIL);
    /** {@code objectType} 허용 값 전체. */
    public static final Set<String> OBJECT_TYPES = setOf(
        OBJECT_TYPE_FILE, OBJECT_TYPE_FOLDER, OBJECT_TYPE_USER, OBJECT_TYPE_SETTING);
    /**
     * {@code groupBy} 허용 값 전체. 네 값만 받는다 — 아무 컬럼으로나 묶게 하면 인덱스 없는 축으로 전체 스캔이
     * 열린다.
     */
    public static final Set<String> GROUP_BY_AXES = setOf(
        GROUP_BY_OBJECT_ID, GROUP_BY_ACTOR_ID, GROUP_BY_SCOPE_ID, GROUP_BY_CORRELATION_ID);
    /** {@code objectStorage} 허용 값 전체. */
    public static final Set<String> OBJECT_STORAGES = setOf(
        OBJECT_STORAGE_TFD, OBJECT_STORAGE_LOCAL, OBJECT_STORAGE_USER_STORAGE);

    private QueryVocabulary() {
    }

    private static Set<String> setOf(String... values) {
        return Collections.unmodifiableSet(new LinkedHashSet<String>(Arrays.asList(values)));
    }
}
