package com.thinkfree.governance.sdk.transport;

import java.net.URI;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/** transport가 실행할 immutable HTTP 요청이다. */
public final class HttpRequest {
    private final HttpMethod method;
    private final URI uri;
    private final Map<String, String> headers;
    private final byte[] body;

    private HttpRequest(Builder builder) {
        this.method = Objects.requireNonNull(builder.method, "method");
        this.uri = Objects.requireNonNull(builder.uri, "uri");
        this.headers = Collections.unmodifiableMap(new LinkedHashMap<String, String>(builder.headers));
        this.body = builder.body == null ? new byte[0] : Arrays.copyOf(builder.body, builder.body.length);
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public HttpMethod getMethod() {
        return method;
    }

    public URI getUri() {
        return uri;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public byte[] getBody() {
        return Arrays.copyOf(body, body.length);
    }

    /** HTTP 요청 builder다. */
    public static final class Builder {
        private HttpMethod method;
        private URI uri;
        private final Map<String, String> headers = new LinkedHashMap<String, String>();
        private byte[] body;

        public Builder setMethod(HttpMethod method) {
            this.method = method;
            return this;
        }

        public Builder setUri(URI uri) {
            this.uri = uri;
            return this;
        }

        public Builder putHeader(String name, String value) {
            headers.put(Objects.requireNonNull(name, "name"), Objects.requireNonNull(value, "value"));
            return this;
        }

        public Builder setBody(byte[] body) {
            this.body = body == null ? null : Arrays.copyOf(body, body.length);
            return this;
        }

        public HttpRequest build() {
            return new HttpRequest(this);
        }
    }
}
