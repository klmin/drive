package com.thinkfree.governance.sdk.model;

/**
 * 콘텐츠 변경 항목이다. EventIn의 `contentChange[]` 배열 항목으로 직렬화된다.
 *
 * `producedAt`은 이 항목의 콘텐츠가 만들어진 시각이며 **항목마다 따로** 갖는다(이벤트 전체의
 * `occurredAt`과 다른 값일 수 있다). 값을 모르면 이벤트의 `occurredAt`을 그대로 넣는다.
 * `content`는 실제 증적 원문인 임의 JSON 값이고 null일 수 없다.
 */
public final class ContentChangeItem {
    private final String producedAt;
    private final String itemType;
    private final String itemStatus;
    private final String actionType;
    private final String targetType;
    private final String targetRange;
    private final String targetId;
    private final String mediaType;
    private final String contentEncoding;
    private final Object content;
    private final String name;
    private final Actor producedBy;
    private ContentChangeItem(Builder builder) {
        producedAt = required(builder.producedAt, "producedAt");
        itemType = required(builder.itemType, "itemType");
        itemStatus = builder.itemStatus;
        actionType = builder.actionType;
        targetType = builder.targetType;
        targetRange = builder.targetRange;
        targetId = builder.targetId;
        mediaType = required(builder.mediaType, "mediaType");
        contentEncoding = required(builder.contentEncoding, "contentEncoding");
        if (builder.content == null) throw new IllegalArgumentException("content must not be null");
        content = builder.content;
        name = builder.name;
        producedBy = builder.producedBy;
    }
    public static Builder newBuilder() { return new Builder(); }
    public String getProducedAt() { return producedAt; }
    public String getItemType() { return itemType; }
    public String getItemStatus() { return itemStatus; }
    public String getActionType() { return actionType; }
    public String getTargetType() { return targetType; }
    public String getTargetRange() { return targetRange; }
    /**
     * 같은 위치(문단·셀)를 가리키는 <b>연동 서비스의 식별자</b>다.
     *
     * <p>주면 서버가 <b>같은 위치끼리 묶어</b> 보여 준다({@code GET /v1/evidence-groups/{groupKey}/changes}) —
     * 자동 저장이 한 문단을 열 번 건드렸어도 한 줄로 모이고 원문은 "최초 before + 최종 after"가 된다.
     * 안 주면 그 항목은 묶이지 않고 위치 칸이 빈다.
     *
     * <p>{@link #getTargetRange()}(문단12 같은 사람이 읽는 표기)와 <b>다른 값</b>이다 — 표기는 바뀌어도
     * 식별자는 그대로여야 같은 위치로 묶인다.
     */
    public String getTargetId() { return targetId; }
    public String getMediaType() { return mediaType; }
    public String getContentEncoding() { return contentEncoding; }
    public Object getContent() { return content; }
    public String getName() { return name; }
    public Actor getProducedBy() { return producedBy; }
    private static String required(String value, String name) {
        if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException(name + " must not be blank");
        return value;
    }
    public static final class Builder {
        private String producedAt;
        private String itemType;
        private String itemStatus;
        private String actionType;
        private String targetType;
        private String targetRange;
        private String targetId;
        private String mediaType;
        private String contentEncoding;
        private Object content;
        private String name;
        private Actor producedBy;
        public Builder setProducedAt(String value) { producedAt = value; return this; }
        public Builder setItemType(String value) { itemType = value; return this; }
        public Builder setItemStatus(String value) { itemStatus = value; return this; }
        public Builder setActionType(String value) { actionType = value; return this; }
        public Builder setTargetType(String value) { targetType = value; return this; }
        public Builder setTargetRange(String value) { targetRange = value; return this; }
        /** 같은 위치끼리 묶이게 하는 식별자를 지정한다(선택 — 없으면 그 항목은 안 묶인다). */
        public Builder setTargetId(String value) { targetId = value; return this; }
        public Builder setMediaType(String value) { mediaType = value; return this; }
        public Builder setContentEncoding(String value) { contentEncoding = value; return this; }
        public Builder setContent(Object value) { content = value; return this; }
        public Builder setName(String value) { name = value; return this; }
        public Builder setProducedBy(Actor value) { producedBy = value; return this; }
        public ContentChangeItem build() { return new ContentChangeItem(this); }
    }
}
