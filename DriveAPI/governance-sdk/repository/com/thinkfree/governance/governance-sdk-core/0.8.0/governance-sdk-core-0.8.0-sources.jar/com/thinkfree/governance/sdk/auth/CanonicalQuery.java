package com.thinkfree.governance.sdk.auth;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * 조회 요청의 검색 파라미터를 서명 대상 문자열({@code canonicalQuery})로 만든다.
 *
 * <p>{@link HmacSigner#sign} 은 이 문자열을 <b>완성된 상태로</b> 받는다. 파라미터 목록을 문자열로 바꾸는
 * 규칙이 연동 서비스마다 다시 구현되면 한 글자 차이로 원인 표시 없는 401이 나므로, SDK가 규칙을 한 번만 갖는다.
 *
 * <p>규칙(서버 {@code CanonicalQuery.kt}·{@code http/gov-sign.js} 와 같아야 한다):
 * <ol>
 *   <li>각 (이름, 값)을 RFC 3986으로 퍼센트 인코딩한다 — {@code A-Za-z0-9-._~} 만 그대로 두고 나머지
 *       UTF-8 바이트는 {@code %XX}(대문자 16진)로, 공백은 {@code +} 가 아니라 {@code %20} 으로 바꾼다.</li>
 *   <li>인코딩된 이름 오름차순으로 정렬하고, 이름이 같으면 인코딩된 값 기준으로 정렬한다.</li>
 *   <li>{@code name=value} 를 {@code &} 로 잇는다(값이 비면 {@code name=}). 파라미터가 없으면 빈 문자열.</li>
 * </ol>
 *
 * <p>서버는 받은 query 문자열 원문이 아니라 <b>파싱한 파라미터</b>를 이 규칙으로 다시 만들어 서명을 검증한다.
 * 그래서 URL에 붙이는 순서는 자유지만, SDK 조회 클라이언트는 헷갈릴 여지를 없애려고 여기서 만든 문자열을
 * URL query에도 그대로 사용한다.
 */
public final class CanonicalQuery {
    private static final String UNRESERVED =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~";
    private static final Charset UTF_8 = Charset.forName("UTF-8");
    private static final char[] UPPER_HEX = "0123456789ABCDEF".toCharArray();

    private CanonicalQuery() {
    }

    /**
     * 파라미터 목록을 서명 대상 문자열로 만든다.
     *
     * @param parameters 이름 → 값 목록. 값이 여러 개인 파라미터({@code eventType})도 그대로 받는다.
     *                   값 목록이 {@code null} 이거나 그 안의 값이 {@code null} 인 항목은 보내지 않은 것으로 보고 건너뛴다
     * @return 서명 대상 문자열. 파라미터가 없으면 빈 문자열
     * @throws NullPointerException parameters 또는 파라미터 이름이 null인 경우
     */
    public static String of(Map<String, List<String>> parameters) {
        if (parameters == null) {
            throw new NullPointerException("parameters must not be null");
        }
        List<String[]> pairs = new ArrayList<String[]>();
        for (Map.Entry<String, List<String>> entry : parameters.entrySet()) {
            if (entry.getKey() == null) {
                throw new NullPointerException("parameter name must not be null");
            }
            if (entry.getValue() == null) {
                continue;
            }
            for (String value : entry.getValue()) {
                if (value == null) {
                    continue;
                }
                pairs.add(new String[] {encode(entry.getKey()), encode(value)});
            }
        }
        Collections.sort(pairs, PAIR_ORDER);
        StringBuilder result = new StringBuilder();
        for (String[] pair : pairs) {
            if (result.length() > 0) {
                result.append('&');
            }
            result.append(pair[0]).append('=').append(pair[1]);
        }
        return result.toString();
    }

    /** 인코딩된 이름 오름차순, 이름이 같으면 인코딩된 값 오름차순. 인코딩 결과는 ASCII라 문자 순서가 바이트 순서다. */
    private static final Comparator<String[]> PAIR_ORDER = new Comparator<String[]>() {
        @Override
        public int compare(String[] left, String[] right) {
            int byName = left[0].compareTo(right[0]);
            return byName != 0 ? byName : left[1].compareTo(right[1]);
        }
    };

    private static String encode(String value) {
        byte[] bytes = value.getBytes(UTF_8);
        StringBuilder builder = new StringBuilder(bytes.length);
        for (byte item : bytes) {
            int unsigned = item & 0xFF;
            char character = (char) unsigned;
            if (unsigned < 0x80 && UNRESERVED.indexOf(character) >= 0) {
                builder.append(character);
            } else {
                builder.append('%').append(UPPER_HEX[unsigned >> 4]).append(UPPER_HEX[unsigned & 0x0F]);
            }
        }
        return builder.toString();
    }
}
