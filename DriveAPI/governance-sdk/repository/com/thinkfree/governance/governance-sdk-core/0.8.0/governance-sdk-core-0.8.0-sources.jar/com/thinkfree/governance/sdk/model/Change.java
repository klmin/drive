package com.thinkfree.governance.sdk.model;

/**
 * 변경 전후의 임의 JSON 값과 요약이다.
 *
 * <p><b>"값이 원래 없었다"와 "값을 안 알려줬다"는 증적에서 다른 진술이다.</b> 권한을 새로 만든 이벤트는
 * 이전 값이 없었다는 사실 자체가 내용이고, 이전 값을 모르는 이벤트는 아무 말도 하지 않은 것이다. 그래서
 * 두 가지를 나눠 표현한다.
 *
 * <ul>
 *   <li>{@link Builder#setBefore(Object)} 에 값 — 그 값을 보낸다.</li>
 *   <li>{@code setBefore(null)} 또는 아무것도 부르지 않음 — <b>필드 자체를 보내지 않는다</b>(침묵).</li>
 *   <li>{@link Builder#setBeforeExplicitNull()} — {@code "before": null} 을 보낸다(값이 없었다는 진술).</li>
 * </ul>
 *
 * 값 setter와 명시적 null setter는 서로를 지운다 — 마지막에 부른 것이 이긴다.
 */
public final class Change {
    private final Object before;
    private final Object after;
    private final boolean beforeExplicitNull;
    private final boolean afterExplicitNull;
    private final String summary;

    private Change(Builder builder) {
        before = builder.before;
        after = builder.after;
        beforeExplicitNull = builder.beforeExplicitNull;
        afterExplicitNull = builder.afterExplicitNull;
        summary = builder.summary;
    }

    public static Builder newBuilder() { return new Builder(); }
    public Object getBefore() { return before; }
    public Object getAfter() { return after; }
    public String getSummary() { return summary; }

    /** {@code before} 를 명시적 null로 보낼지. false면 값이 없을 때 필드를 아예 보내지 않는다. */
    public boolean isBeforeExplicitNull() { return beforeExplicitNull; }

    /** {@code after} 를 명시적 null로 보낼지. false면 값이 없을 때 필드를 아예 보내지 않는다. */
    public boolean isAfterExplicitNull() { return afterExplicitNull; }

    /** 변경 내용 builder다. */
    public static final class Builder {
        private Object before;
        private Object after;
        private boolean beforeExplicitNull;
        private boolean afterExplicitNull;
        private String summary;

        /** 변경 전 값을 넣는다. {@code null} 은 "안 보냄"이라 필드가 실리지 않는다. */
        public Builder setBefore(Object value) { before = value; beforeExplicitNull = false; return this; }

        /** 변경 후 값을 넣는다. {@code null} 은 "안 보냄"이라 필드가 실리지 않는다. */
        public Builder setAfter(Object value) { after = value; afterExplicitNull = false; return this; }

        /** 변경 전 값이 <b>원래 없었다</b>고 진술한다 — 본문에 {@code "before": null} 이 실린다. */
        public Builder setBeforeExplicitNull() { before = null; beforeExplicitNull = true; return this; }

        /** 변경 후 값이 <b>원래 없었다</b>고 진술한다 — 본문에 {@code "after": null} 이 실린다. */
        public Builder setAfterExplicitNull() { after = null; afterExplicitNull = true; return this; }

        /** 연동 서비스가 쓴 변경 설명. 서버가 전후 값을 이어 붙여 만들지 않는다. */
        public Builder setSummary(String value) { summary = value; return this; }

        public Change build() { return new Change(this); }
    }
}
