package com.thinkfree.governance.sdk.client;

/** 서버 오류를 secret과 raw body 없이 전달하는 SDK 예외다. */
public class GovernanceApiException extends Exception {
    private final int httpStatus;
    private final String errorCode;
    private final boolean retryable;
    private final RequestOperation operation;
    private final Integer retryAfterSeconds;

    public GovernanceApiException(int httpStatus, String errorCode, boolean retryable, RequestOperation operation) {
        this(httpStatus, errorCode, retryable, operation, null);
    }

    /**
     * @param retryAfterSeconds 서버가 {@code Retry-After} 로 알려준 대기 초. 안 왔으면 {@code null}
     */
    public GovernanceApiException(
        int httpStatus,
        String errorCode,
        boolean retryable,
        RequestOperation operation,
        Integer retryAfterSeconds) {
        super("Governance API request failed: " + operation + " (HTTP " + httpStatus + ")");
        this.httpStatus = httpStatus;
        this.errorCode = errorCode;
        this.retryable = retryable;
        this.operation = operation;
        this.retryAfterSeconds = retryAfterSeconds;
    }

    public int getHttpStatus() { return httpStatus; }
    public String getErrorCode() { return errorCode; }
    public boolean isRetryable() { return retryable; }
    public RequestOperation getOperation() { return operation; }

    /**
     * 다시 시도하기까지 기다릴 초.
     *
     * <p>CSV 내려받기가 동시 실행 상한에 걸리면({@code 429} {@code EXPORT_BUSY}) 서버가 이 값을 준다.
     * <b>{@code null} 은 "바로 다시 보내도 된다"가 아니라 "서버가 말해 주지 않았다"</b> 는 뜻이다 —
     * 그때는 연동 서비스의 backoff 를 쓴다.
     *
     * @return 대기 초. 서버가 안 알려줬으면 {@code null}
     */
    public Integer getRetryAfterSeconds() { return retryAfterSeconds; }
}
