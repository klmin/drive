package com.thinkfree.governance.sdk.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** 배치 인입 요청 body의 래퍼다. */
public final class IngestBatchRequest {
    private final List<EventIn> events;
    private IngestBatchRequest(Builder builder) {
        if (builder.events.isEmpty()) throw new IllegalArgumentException("events must not be empty");
        events = Collections.unmodifiableList(new ArrayList<EventIn>(builder.events));
    }
    public static Builder newBuilder() { return new Builder(); }
    public List<EventIn> getEvents() { return events; }
    public static final class Builder {
        private final List<EventIn> events = new ArrayList<EventIn>();
        public Builder addEvent(EventIn value) { events.add(value); return this; }
        public Builder addAllEvents(List<EventIn> values) { events.addAll(values); return this; }
        public IngestBatchRequest build() { return new IngestBatchRequest(this); }
    }
}
