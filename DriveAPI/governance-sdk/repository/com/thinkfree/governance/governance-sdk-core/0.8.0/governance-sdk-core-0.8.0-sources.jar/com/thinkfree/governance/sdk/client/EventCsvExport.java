package com.thinkfree.governance.sdk.client;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.Arrays;

/**
 * 증적 목록 CSV 내려받기({@code GET /v1/events:export})의 결과다. 받은 바이트를 <b>수정하지 않고</b> 들고 있다.
 *
 * <p>⚠ <b>{@code GET /v1/events:export} 는 한 페이지만 준다.</b> {@code limit}·{@code offset}·{@code cursor}
 * 까지 목록 조회와 같으므로 최대 200행이다. 조건에 맞는 전체가 필요하면 둘 중 하나를 쓴다.
 * <ul>
 *   <li>{@link #getNextCursor()} 를 다음 요청의 {@code cursor} 로 넘기며 한 장씩 이어 부른다.
 *       <b>그 값이 {@code null} 이면 마지막 장이다.</b></li>
 *   <li>기간이 92일 이내라면 {@link GovernanceClient#exportEventsInRange(com.thinkfree.governance.sdk.model.EventQuery)}
 *       로 한 번에 받는다.</li>
 * </ul>
 *
 * <p>⚠ <b>파일을 그대로 저장할 것이 아니라 값을 읽을 것이라면 아래 둘을 알아야 한다.</b>
 * <ul>
 *   <li>선두에 UTF-8 BOM({@code EF BB BF})이 있다(엑셀에서 한글이 깨지지 않게 하기 위한 것). 값을 파싱한다면
 *       {@link #getContentWithoutBom()} 을 쓴다.</li>
 *   <li>서버가 <b>수식 주입을 막으려고</b> {@code =}·{@code +}·{@code -}·{@code @} 로 시작하는 값 앞에
 *       작은따옴표 하나를 붙인다. 엑셀은 안 보여주지만 <b>프로그램으로 읽으면 한 글자가 더 있다.</b>
 *       원문 그대로가 필요하면 상세 조회({@link GovernanceClient#getEvent(String)})를 쓴다.</li>
 * </ul>
 *
 * <p>줄 끝은 CRLF, 따옴표는 RFC 4180, 열은 44개이고 순서가 계약이다.
 */
public final class EventCsvExport {
    private static final byte[] BOM = {(byte) 0xEF, (byte) 0xBB, (byte) 0xBF};
    private static final Charset UTF_8 = Charset.forName("UTF-8");

    private final byte[] content;
    private final String fileName;
    private final String contentType;
    private final String nextCursor;

    EventCsvExport(byte[] content, String fileName, String contentType, String nextCursor) {
        this.content = content == null ? new byte[0] : Arrays.copyOf(content, content.length);
        this.fileName = fileName;
        this.contentType = contentType;
        this.nextCursor = nextCursor;
    }

    /** 받은 응답 본문 그대로(BOM 포함). 파일로 저장할 때 쓰는 값이다. */
    public byte[] getContent() {
        return Arrays.copyOf(content, content.length);
    }

    /** BOM 을 뺀 본문. 값을 파싱할 때 쓴다 — BOM 을 안 떼면 첫 열 이름이 {@code schemaVersion} 이 아니게 된다. */
    public byte[] getContentWithoutBom() {
        if (hasBom()) {
            return Arrays.copyOfRange(content, BOM.length, content.length);
        }
        return Arrays.copyOf(content, content.length);
    }

    /** BOM 을 뺀 본문을 UTF-8 문자열로 읽는다. */
    public String getText() {
        return new String(getContentWithoutBom(), UTF_8);
    }

    /** 선두에 UTF-8 BOM 이 있는지. */
    public boolean hasBom() {
        return content.length >= BOM.length
            && content[0] == BOM[0] && content[1] == BOM[1] && content[2] == BOM[2];
    }

    /**
     * 서버가 {@code Content-Disposition} 에 담아 준 파일 이름
     * (예: {@code audit-events_20260701-20260731_20260827-090000.csv}).
     *
     * @return 파일 이름. 헤더가 없거나 이름을 못 읽으면 {@code null} — 이때는 연동 서비스가 이름을 정한다
     */
    public String getFileName() {
        return fileName;
    }

    /** 응답의 {@code Content-Type}(예: {@code text/csv;charset=UTF-8}). 헤더가 없으면 {@code null}. */
    public String getContentType() {
        return contentType;
    }

    /**
     * 다음 페이지의 커서(서버 응답 헤더 {@code X-Gov-Next-Cursor}).
     *
     * <p>이 값을 다음 요청의 {@code cursor} 로 그대로 넘기면 다음 장이 온다 — <b>해석하지 않는다.</b>
     * 목록 조회의 {@code nextCursor} 와 같은 문자열이므로, 목록을 곁들여 부르지 않아도 된다.
     *
     * @return 다음 페이지 커서. <b>{@code null} 이면 마지막 장이다</b>(기간 전체 내려받기는 늘 {@code null})
     */
    public String getNextCursor() {
        return nextCursor;
    }

    /**
     * 이어 받을 다음 장이 있는지.
     *
     * @return {@link #getNextCursor()} 가 있으면 {@code true}
     */
    public boolean hasNextPage() {
        return nextCursor != null && !nextCursor.isEmpty();
    }

    /**
     * 받은 바이트를 그대로 흘려 쓴다(BOM 포함). stream 은 닫지 않는다.
     *
     * @param output 쓸 대상
     * @throws IOException 쓰기 실패
     */
    public void writeTo(OutputStream output) throws IOException {
        if (output == null) {
            throw new NullPointerException("output must not be null");
        }
        output.write(content);
    }
}
