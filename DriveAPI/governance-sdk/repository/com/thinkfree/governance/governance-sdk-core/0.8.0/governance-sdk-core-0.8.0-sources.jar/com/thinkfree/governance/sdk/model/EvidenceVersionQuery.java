package com.thinkfree.governance.sdk.model;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 한 대상의 버전 타임라인 조회({@code GET /v1/evidence-groups/{groupKey}/versions})다.
 *
 * <p>버전마다 이벤트 수·구간·마지막 수행자·누적 변경이 온다. <b>버전을 안 보낸 이벤트들도 한 그룹으로</b> 오며
 * 그때 {@code version} 이 비어 있다(로컬 파일처럼 버전을 안 보내는 연동이 있다).
 *
 * <p><b>목록의 필터를 물려받지 않는다.</b> 상세는 필터와 무관하게 그 대상의 <b>모든</b> 버전을 보여 준다 —
 * 받는 것은 {@code groupBy} 와 {@code objectType} 둘뿐이다.
 *
 * <p>{@code objectType} 은 대상을 다시 거르는 조건이 아니라 <b>경로가 못 실은 부분을 채운다</b> — 그룹의 실제
 * 키가 (대상 유형, 대상 식별자)인데 경로에는 {@code groupKey} 하나만 실리기 때문이다. 안 주면 같은 식별자를
 * 쓰는 다른 유형의 이벤트가 섞여 목록 줄의 이벤트 수와 타임라인 합이 안 맞는다.
 *
 * <p>페이지네이션이 없다 — 한 대상의 버전 수는 화면에 다 보여 줄 만큼이다.
 */
public final class EvidenceVersionQuery {
    private static final String GROUP_BY = "groupBy";
    private static final String OBJECT_TYPE = "objectType";

    private final String groupKey;
    private final Map<String, String> filters;

    private EvidenceVersionQuery(Builder builder) {
        groupKey = QueryValues.requirePathSegment(builder.groupKey, "groupKey");
        Map<String, String> values = new LinkedHashMap<String, String>();
        for (Map.Entry<String, String> filter : builder.filters.entrySet()) {
            values.put(filter.getKey(), QueryValues.requireNotBlank(filter.getValue(), filter.getKey()));
        }
        QueryValues.requireNotBlank(values.get(GROUP_BY), GROUP_BY);
        filters = Collections.unmodifiableMap(values);
    }

    public static Builder newBuilder() { return new Builder(); }

    /** 그룹 목록이 돌려준 {@code groupKey}. 연동 서비스가 만들지 않는다. */
    public String getGroupKey() { return groupKey; }
    public String getGroupBy() { return filters.get(GROUP_BY); }
    public String getObjectType() { return filters.get(OBJECT_TYPE); }

    /**
     * 이 쿼리를 서명·URL에 쓸 파라미터 목록으로 내보낸다({@code groupKey} 는 경로라 여기 없다).
     *
     * @return 계약 이름 → 값 목록(수정 불가)
     */
    public Map<String, List<String>> toCanonicalParameters() {
        Map<String, List<String>> parameters = new LinkedHashMap<String, List<String>>();
        for (Map.Entry<String, String> filter : filters.entrySet()) {
            parameters.put(filter.getKey(), Collections.singletonList(filter.getValue()));
        }
        return Collections.unmodifiableMap(parameters);
    }

    /** 버전 타임라인 쿼리 builder다. */
    public static final class Builder {
        private String groupKey;
        private final Map<String, String> filters = new LinkedHashMap<String, String>();

        private Builder put(String name, String value) {
            if (value == null) {
                filters.remove(name);
            } else {
                filters.put(name, value);
            }
            return this;
        }

        /** 그룹 목록이 돌려준 {@code groupKey}(필수). */
        public Builder setGroupKey(String value) { groupKey = value; return this; }
        /** 목록을 만들 때 쓴 것과 같은 축(필수). */
        public Builder setGroupBy(String value) { return put(GROUP_BY, value); }
        /** 그룹의 대상 유형. 경로가 못 싣는 그룹 키의 일부라 목록과 같은 값을 준다. */
        public Builder setObjectType(String value) { return put(OBJECT_TYPE, value); }

        public EvidenceVersionQuery build() { return new EvidenceVersionQuery(this); }
    }
}
