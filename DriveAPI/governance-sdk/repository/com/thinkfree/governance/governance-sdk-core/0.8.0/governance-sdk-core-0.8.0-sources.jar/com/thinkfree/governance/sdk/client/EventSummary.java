package com.thinkfree.governance.sdk.client;

import java.util.List;
import java.util.Map;

/**
 * 목록 조회의 한 줄이다. 저장 시점에 평문으로 채운 조회용 프로젝션에서 읽으므로 복호화가 없다.
 *
 * <p>{@code sourceMetadata} 와 {@code contentChange[]} 를 뺀 EventIn 값 전부를 담는다. 두 값은 상세 조회
 * ({@link GovernanceClient#getEvent}) 의 {@code reported} 에서 원문 그대로 볼 수 있다.
 *
 * <p><b>연동 서비스가 보내지 않은 값은 응답에 필드 자체가 없다</b> — getter는 그때 {@code null} 을 돌려준다.
 * 시각은 계약 문자열(RFC 3339)을 그대로 돌려준다. {@link #getOccurredAt()} 는 계약상 필수가 아니라
 * <b>없을 수 있다</b>(발생 시각이 필수가 되기 전에 저장된 이벤트). 서버는 받은 시각으로 대신 채우지 않는다.
 *
 * <p>{@link #getChange()}·{@link #getTargets()} 는 <b>연동 서비스가 보낸 원문 JSON 구조 그대로</b>다 — SDK가
 * 문자열로 문자열로 변환해 넣거나 항목을 펼치지 않는다. 계약이 늘어 SDK가 아직 모르는 필드가 생겼을 때는
 * {@link #asMap()} 으로 읽는다.
 */
public final class EventSummary {
    private final Map<String, Object> values;

    EventSummary(Map<String, Object> values) {
        this.values = ResponseValues.copyOf(values);
    }

    public String getEventId() { return text("eventId"); }
    /** 이벤트 발생 시각(reported). 목록 정렬·기간 필터의 기준이며 항상 UTC 표기다. 없을 수 있다. */
    public String getOccurredAt() { return text("occurredAt"); }
    /** 서버 수신 시각(observed). 서버가 채우므로 항상 있다. */
    public String getReceivedAt() { return text("receivedAt"); }
    public String getSchemaVersion() { return text("schemaVersion"); }
    public String getEventType() { return text("eventType"); }
    public String getSourceEventType() { return text("sourceEventType"); }
    public String getEventCategory() { return text("eventCategory"); }
    public String getActorType() { return text("actorType"); }
    public String getActorId() { return text("actorId"); }
    public String getActorName() { return text("actorName"); }
    public String getActorEmail() { return text("actorEmail"); }
    public String getActorProvider() { return text("actorProvider"); }
    public String getActorModel() { return text("actorModel"); }
    public String getActorModelVersion() { return text("actorModelVersion"); }
    public String getOriginSystem() { return text("originSystem"); }
    public String getOriginComponent() { return text("originComponent"); }
    public String getOriginInstanceId() { return text("originInstanceId"); }
    /** 서버가 확인한 인증 경로(observed). 서명 방식과 다른 값이다. */
    public String getIngestAuthMethod() { return text("ingestAuthMethod"); }
    public String getScopeType() { return text("scopeType"); }
    /** 고객사 내부 업무 범위 식별자. 거버넌스 테넌트와 다른 값이다. */
    public String getScopeId() { return text("scopeId"); }
    public String getScopeName() { return text("scopeName"); }
    public String getChannel() { return text("channel"); }
    public String getOutcomeStatus() { return text("outcomeStatus"); }
    public String getOutcomeCode() { return text("outcomeCode"); }
    public String getOutcomeMessage() { return text("outcomeMessage"); }
    public String getObjectType() { return text("objectType"); }
    public String getObjectId() { return text("objectId"); }
    public String getObjectName() { return text("objectName"); }
    public String getObjectPath() { return text("objectPath"); }
    public String getObjectVersion() { return text("objectVersion"); }
    public String getObjectStorage() { return text("objectStorage"); }
    public String getCorrelationId() { return text("correlationId"); }
    public String getSessionId() { return text("sessionId"); }
    public String getRequestId() { return text("requestId"); }
    /** 연동 서비스가 신고한 클라이언트 주소(reported). 서버가 관측한 {@link #getObservedIp()} 와 다른 값이다. */
    public String getClientIp() { return text("clientIp"); }
    /** 서버가 관측한 요청 출발 주소(observed). */
    public String getObservedIp() { return text("observedIp"); }

    /**
     * 이 이벤트의 변경 항목({@code contentChange[]}) 수.
     *
     * <p><b>{@code null} 은 0이 아니라 "집계하지 않은 이벤트"이다</b> — 개수는 이 기능이 생긴 뒤 저장된 이벤트에만 있다.
     * 0으로 대신 읽으면 항목이 있는 옛 이벤트를 "변경 없음"으로 잘못 결론짓는다.
     *
     * <p>변경 내역을 그릴 때 <b>0인 이벤트는 상세를 부를 필요가 없다</b>(항목이 없어 복호화해도 얻을 것이 없다).
     *
     * @return 변경 항목 수. 집계하지 않은 이벤트면 {@code null}
     */
    public Integer getContentChangeCount() {
        Long value = ResponseValues.longValue(values, "contentChangeCount");
        return value == null ? null : Integer.valueOf(value.intValue());
    }

    /**
     * 속성 변경 내용을 연동 서비스가 보낸 구조 그대로 돌려준다.
     *
     * @return {@code before}·{@code after}·{@code summary} 를 담은 map. 값은 문자열·숫자뿐 아니라 객체·배열도
     *         올 수 있다. 연동 서비스가 보내지 않았으면 {@code null}
     */
    public Map<String, Object> getChange() { return ResponseValues.object(values, "change"); }

    /**
     * 이벤트의 추가 대상을 받은 배열 그대로 돌려준다.
     *
     * @return 항목마다 {@code type}·{@code selection}·{@code entity}·{@code accounts} 구조가 보존된 목록.
     *         연동 서비스가 보내지 않았으면 {@code null}
     */
    public List<Object> getTargets() { return ResponseValues.array(values, "targets"); }

    /**
     * 응답 한 줄의 원문 값 전부를 돌려준다.
     *
     * @return 계약 필드 이름 → 값(수정 불가). 서버 계약이 늘어 SDK getter가 아직 없는 필드를 읽을 때 사용한다
     */
    public Map<String, Object> asMap() { return values; }

    private String text(String name) { return ResponseValues.text(values, name); }
}
