package com.thinkfree.governance.sdk.transport;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** transport가 반환하는 immutable HTTP 응답이다. */
public final class HttpResponse {
    private final int statusCode;
    private final Map<String, List<String>> headers;
    private final byte[] body;

    public HttpResponse(int statusCode, Map<String, List<String>> headers, byte[] body) {
        this.statusCode = statusCode;
        this.headers = Collections.unmodifiableMap(new LinkedHashMap<String, List<String>>(headers));
        this.body = body == null ? new byte[0] : Arrays.copyOf(body, body.length);
    }

    public int getStatusCode() {
        return statusCode;
    }

    public Map<String, List<String>> getHeaders() {
        return headers;
    }

    public byte[] getBody() {
        return Arrays.copyOf(body, body.length);
    }
}
