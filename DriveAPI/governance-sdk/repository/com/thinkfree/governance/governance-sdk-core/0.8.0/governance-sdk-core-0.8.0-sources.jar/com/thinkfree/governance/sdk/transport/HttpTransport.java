package com.thinkfree.governance.sdk.transport;

import java.io.Closeable;
import java.io.IOException;

/** HTTP 라이브러리별 구현을 주입하는 outbound transport 포트다. */
public interface HttpTransport extends Closeable {
    HttpResponse execute(HttpRequest request) throws IOException;
}
