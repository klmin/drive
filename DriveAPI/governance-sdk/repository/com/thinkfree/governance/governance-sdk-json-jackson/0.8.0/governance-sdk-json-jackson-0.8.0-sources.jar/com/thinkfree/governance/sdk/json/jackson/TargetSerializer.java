package com.thinkfree.governance.sdk.json.jackson;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.thinkfree.governance.sdk.model.Account;
import com.thinkfree.governance.sdk.model.Target;

import java.io.IOException;

/** SDK Target 모델을 Governance EventIn의 중첩 target 계약으로 직렬화한다. */
final class TargetSerializer extends JsonSerializer<Target> {
    /**
     * Target의 entity 식별자를 `entity` 객체로 묶고 계정 목록을 직렬화한다.
     *
     * @param target 직렬화할 SDK Target
     * @param generator JSON 출력기
     * @param provider Jackson serializer provider
     * @throws IOException JSON 출력에 실패한 경우
     */
    @Override
    public void serialize(Target target, JsonGenerator generator, SerializerProvider provider) throws IOException {
        generator.writeStartObject();
        // selection=ANYONE 이면 type 이 없다 — 대상을 특정하는 값이 하나도 없는 것이 사실이라, 빈 값을
        // 만들어 싣지 않는다(서버도 그때 type 을 받으면 400 이다).
        if (target.getType() != null) {
            generator.writeStringField("type", target.getType());
        }
        generator.writeStringField("selection", target.getSelection());
        // shareScope·permission 은 임의 JSON 값이다 — 문자열이면 문자열로, Map·List 면 그 구조로 나간다.
        // writeStringField 로 쓰면 Map 이 toString() 되어 `{permissions=[VIEW]}` 같은 Java 표기가 증적에 남는다.
        if (target.getShareScope() != null) {
            generator.writeFieldName("shareScope");
            provider.defaultSerializeValue(target.getShareScope(), generator);
        }
        if (target.getPermission() != null) {
            generator.writeFieldName("permission");
            provider.defaultSerializeValue(target.getPermission(), generator);
        }

        if (target.getEntityId() != null || target.getEntityName() != null) {
            generator.writeObjectFieldStart("entity");
            if (target.getEntityId() != null) {
                generator.writeStringField("id", target.getEntityId());
            }
            if (target.getEntityName() != null) {
                generator.writeStringField("name", target.getEntityName());
            }
            generator.writeEndObject();
        }

        if (!target.getAccounts().isEmpty()) {
            generator.writeArrayFieldStart("accounts");
            for (Account account : target.getAccounts()) {
                provider.defaultSerializeValue(account, generator);
            }
            generator.writeEndArray();
        }
        generator.writeEndObject();
    }
}
