package com.thinkfree.governance.sdk.json.jackson;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.thinkfree.governance.sdk.json.JsonCodec;
import com.thinkfree.governance.sdk.model.Change;
import com.thinkfree.governance.sdk.model.EventIn;
import com.thinkfree.governance.sdk.model.Target;

import java.io.IOException;

/** Jackson을 사용하는 선택형 JSON codec이다. */
public final class JacksonJsonCodec implements JsonCodec {
    private final ObjectMapper objectMapper;

    /** 기본 Jackson 설정으로 codec을 생성한다. */
    public JacksonJsonCodec() {
        this(new ObjectMapper());
    }

    /**
     * 외부에서 구성한 ObjectMapper로 codec을 생성한다.
     *
     * @param objectMapper 사용할 ObjectMapper
     * @throws NullPointerException objectMapper가 null인 경우
     */
    public JacksonJsonCodec(ObjectMapper objectMapper) {
        if (objectMapper == null) {
            throw new NullPointerException("objectMapper must not be null");
        }
        SimpleModule governanceModule = new SimpleModule("governance-sdk");
        governanceModule.addSerializer(Target.class, new TargetSerializer());
        // change는 전용 직렬화기를 쓴다 — 연동 서비스가 일부러 지정한 null을 살려야 하는 유일한 자리다.
        governanceModule.addSerializer(Change.class, new ChangeSerializer());
        this.objectMapper = objectMapper.copy()
            .registerModule(governanceModule)
            // 빈 컨테이너를 연동 서비스의 진술로 바꾸지 않도록 EventIn의 세 자리에만 NON_EMPTY를 건다.
            .addMixIn(EventIn.class, EventInMixin.class)
            .setSerializationInclusion(JsonInclude.Include.NON_NULL)
            .configure(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS, true);
    }

    /**
     * 값을 JSON UTF-8 바이트로 직렬화한다.
     *
     * @param value 직렬화할 값
     * @return JSON UTF-8 바이트
     * @throws IOException 직렬화에 실패한 경우
     */
    @Override
    public byte[] write(Object value) throws IOException {
        return objectMapper.writeValueAsBytes(value);
    }

    /**
     * JSON UTF-8 바이트를 지정 타입으로 역직렬화한다.
     *
     * @param body JSON UTF-8 바이트
     * @param type 결과 타입
     * @param <T> 결과 타입
     * @return 역직렬화한 값
     * @throws IOException 역직렬화에 실패한 경우
     */
    @Override
    public <T> T read(byte[] body, Class<T> type) throws IOException {
        return objectMapper.readValue(body, type);
    }
}
