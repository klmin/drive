package com.thinkfree.governance.sdk.json.jackson;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.thinkfree.governance.sdk.model.ContentChangeItem;
import com.thinkfree.governance.sdk.model.Target;

import java.util.List;
import java.util.Map;

/**
 * EventIn의 컨테이너 세 개를 <b>비었으면 아예 보내지 않도록</b> 표시하는 Jackson mix-in이다.
 *
 * <p>연동 서비스가 대상·콘텐츠 항목·소스 메타데이터를 하나도 넣지 않았는데 {@code targets: []}·
 * {@code contentChange: []}·{@code sourceMetadata: {}} 가 실려 나가면, 서버가 그 원문을 그대로 증적으로
 * 저장하므로 증적에 <b>"공유 대상이 없었다"</b>고 적힌다 — 연동 서비스는 그런 말을 한 적이 없다.
 * SDK가 만든 빈 상자를 연동 서비스의 진술로 바꾸지 않는다.
 *
 * <p>mix-in을 쓰는 이유는 두 가지다. {@code EventIn} 은 core에 있어 Jackson 애너테이션을 붙일 수 없고
 * (core는 Jackson에 의존하지 않는다), 전역 직렬화 설정을 {@code NON_EMPTY} 로 바꾸면 연동 서비스가 일부러 넣은
 * 빈 문자열까지 사라져 같은 잘못을 반대 방향으로 저지른다. 그래서 <b>이 세 자리에만</b> 건다.
 */
abstract class EventInMixin {
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    abstract List<Target> getTargets();

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    abstract List<ContentChangeItem> getContentChange();

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    abstract Map<String, Object> getSourceMetadata();
}
