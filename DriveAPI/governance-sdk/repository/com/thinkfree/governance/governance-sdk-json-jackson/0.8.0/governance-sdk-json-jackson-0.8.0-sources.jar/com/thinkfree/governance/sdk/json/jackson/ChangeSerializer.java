package com.thinkfree.governance.sdk.json.jackson;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.thinkfree.governance.sdk.model.Change;

import java.io.IOException;

/**
 * SDK Change 모델을 Governance EventIn의 change 계약으로 직렬화한다.
 *
 * <p>전용 직렬화기를 두는 이유는 <b>침묵과 진술을 구분해 보내야</b> 하기 때문이다. codec의 기본 설정은
 * {@code NON_NULL} 이라 null인 필드를 통째로 생략하는데, 그러면 "이전 값이 원래 없었다"는 진술
 * ({@code "before": null})을 보낼 수 없다. 전역 설정을 바꾸면 모든 필드에 null이 흘러 반대 잘못을 저지르므로,
 * <b>change 안에서만</b> 연동 서비스가 일부러 지정한 null을 살린다
 * ({@link Change#isBeforeExplicitNull()}·{@link Change#isAfterExplicitNull()}).
 */
final class ChangeSerializer extends JsonSerializer<Change> {
    /**
     * 값이 있으면 값을, 명시적 null로 지정했으면 null을 쓰고, 둘 다 아니면 필드를 쓰지 않는다.
     *
     * @param change 직렬화할 SDK Change
     * @param generator JSON 출력기
     * @param provider Jackson serializer provider
     * @throws IOException JSON 출력에 실패한 경우
     */
    @Override
    public void serialize(Change change, JsonGenerator generator, SerializerProvider provider) throws IOException {
        generator.writeStartObject();
        writeValue(generator, provider, "before", change.getBefore(), change.isBeforeExplicitNull());
        writeValue(generator, provider, "after", change.getAfter(), change.isAfterExplicitNull());
        if (change.getSummary() != null) {
            generator.writeStringField("summary", change.getSummary());
        }
        generator.writeEndObject();
    }

    private static void writeValue(
        JsonGenerator generator,
        SerializerProvider provider,
        String name,
        Object value,
        boolean explicitNull) throws IOException {
        if (value != null) {
            generator.writeFieldName(name);
            provider.defaultSerializeValue(value, generator);
        } else if (explicitNull) {
            generator.writeNullField(name);
        }
    }
}
